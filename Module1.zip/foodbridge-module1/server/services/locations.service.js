/**
 * Feature 1.2 (Member 2)
 * Bangladesh Division > District > Upazila hierarchy.
 * Data: github.com/nuhil/bangladesh-geocode (MIT), with city corporations added.
 */
import { readFileSync } from 'node:fs';

export const LOCATIONS = JSON.parse(readFileSync(new URL('../data/bd-locations.json', import.meta.url), 'utf8'));

const index = new Map();
for (const div of LOCATIONS) {
  for (const dist of div.districts) index.set(`${div.name}|${dist.name}`, new Set(dist.upazilas.map((u) => u.name)));
}

/** True when the district belongs to the division and the upazila (if given) belongs to the district. */
export function isValidAddress({ division, district, upazila }) {
  const upazilas = index.get(`${division}|${district}`);
  if (!upazilas) return false;
  return !upazila || upazilas.has(upazila);
}

export function districtCenter(division, district) {
  const d = LOCATIONS.find((v) => v.name === division)?.districts.find((x) => x.name === district);
  return d ? { lat: d.lat, lng: d.lng } : null;
}
