/**
 * Feature 1.1 (Member 1)
 * Delivers one-time codes. SMS is printed to the terminal during development;
 * plug a Bangladeshi SMS gateway into sendSms() for production.
 * Email is sent through SMTP when configured, otherwise printed as well.
 */
import nodemailer from 'nodemailer';
import { env } from '../config/env.js';

let transporter;
const mailer = () => {
  const { host, port, user, pass } = env.smtp;
  if (!host) return null;
  transporter ??= nodemailer.createTransport({ host, port, secure: port === 465, auth: user ? { user, pass } : undefined });
  return transporter;
};

const box = (lines) => {
  const width = Math.max(...lines.map((l) => l.length)) + 2;
  console.log(`\n┌${'─'.repeat(width)}┐\n${lines.map((l) => `│ ${l.padEnd(width - 1)}│`).join('\n')}\n└${'─'.repeat(width)}┘\n`);
};

export async function sendSms(phone, message) {
  // Production: call your SMS gateway's HTTP API here (for example with fetch).
  if (process.env.NODE_ENV !== 'test') box([`SMS to ${phone}`, message]);
}

export async function sendEmail(to, subject, text) {
  const t = mailer();
  if (!t) {
    if (process.env.NODE_ENV !== 'test') box([`Email to ${to}`, subject, text]);
    return;
  }
  await t.sendMail({ from: env.smtp.from, to, subject, text });
}

const PURPOSE = {
  register: 'verify your FoodBridge account',
  login: 'sign in to FoodBridge',
  reset: 'reset your FoodBridge password',
};

export async function deliverOtp({ channel, target, purpose, code }) {
  const text = `Your code to ${PURPOSE[purpose]} is ${code}. It expires in 5 minutes. Never share it with anyone.`;
  if (channel === 'sms') return sendSms(target, text);
  return sendEmail(target, `FoodBridge code: ${code}`, text);
}
