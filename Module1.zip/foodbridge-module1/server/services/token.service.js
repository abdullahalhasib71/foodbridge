/**
 * Feature 1.1 (Member 1)
 * Short-lived JWT access tokens (15 minutes) plus rotating refresh tokens (7 days)
 * kept in an httpOnly cookie, so JavaScript in the browser never sees them.
 */
import { createHash, randomBytes, randomUUID } from 'node:crypto';
import jwt from 'jsonwebtoken';
import RefreshToken from '../models/RefreshToken.js';
import { ACCESS_TTL, REFRESH_TTL_DAYS, env } from '../config/env.js';
import { HttpError } from './http.js';

export const REFRESH_COOKIE = 'fb_refresh';
const sha256 = (s) => createHash('sha256').update(s).digest('hex');

export const signAccessToken = (user) =>
  jwt.sign({ sub: String(user._id), role: user.role, tv: user.tokenVersion ?? 0 }, env.accessSecret, { expiresIn: ACCESS_TTL });

export const verifyAccessToken = (token) => jwt.verify(token, env.accessSecret);

async function issueRefreshToken(userId, family, userAgent) {
  const raw = randomBytes(48).toString('base64url');
  await RefreshToken.create({
    user: userId,
    tokenHash: sha256(`${raw}.${env.refreshSecret}`),
    family,
    userAgent: userAgent?.slice(0, 200),
    expiresAt: new Date(Date.now() + REFRESH_TTL_DAYS * 86_400_000),
  });
  return raw;
}

const cookieOptions = () => ({
  httpOnly: true,
  secure: env.production,
  sameSite: 'strict',
  path: '/api/auth',
  maxAge: REFRESH_TTL_DAYS * 86_400_000,
});

/** Start a new session: returns the JSON body and sets the refresh cookie. */
export async function startSession(res, user, req) {
  const refresh = await issueRefreshToken(user._id, randomUUID(), req.headers['user-agent']);
  res.cookie(REFRESH_COOKIE, refresh, cookieOptions());
  return { accessToken: signAccessToken(user), user };
}

/** Exchange a refresh token for a new pair. Re-use of a rotated token revokes the whole family. */
export async function rotateSession(req, res, loadUser) {
  const raw = req.cookies?.[REFRESH_COOKIE];
  if (!raw) throw new HttpError(401, 'Sign in to continue.');
  const doc = await RefreshToken.findOne({ tokenHash: sha256(`${raw}.${env.refreshSecret}`) });
  if (!doc || doc.expiresAt < new Date()) {
    clearSession(res);
    throw new HttpError(401, 'Your session has expired. Sign in again.');
  }
  if (doc.revokedAt || doc.replacedAt) {
    await RefreshToken.updateMany({ family: doc.family, revokedAt: null }, { $set: { revokedAt: new Date() } });
    clearSession(res);
    throw new HttpError(401, 'For your security, please sign in again.');
  }
  const user = await loadUser(doc.user);
  if (!user || user.status !== 'active') {
    clearSession(res);
    throw new HttpError(401, 'This account cannot sign in.');
  }
  doc.replacedAt = new Date();
  await doc.save();
  const next = await issueRefreshToken(user._id, doc.family, req.headers['user-agent']);
  res.cookie(REFRESH_COOKIE, next, cookieOptions());
  return { accessToken: signAccessToken(user), user };
}

export async function endSession(req, res) {
  const raw = req.cookies?.[REFRESH_COOKIE];
  if (raw) {
    const doc = await RefreshToken.findOne({ tokenHash: sha256(`${raw}.${env.refreshSecret}`) });
    if (doc) await RefreshToken.updateMany({ family: doc.family, revokedAt: null }, { $set: { revokedAt: new Date() } });
  }
  clearSession(res);
}

/** Sign the user out everywhere (password change, suspension). */
export async function revokeAllSessions(userId) {
  await RefreshToken.updateMany({ user: userId, revokedAt: null }, { $set: { revokedAt: new Date() } });
}

export const clearSession = (res) => res.clearCookie(REFRESH_COOKIE, { ...cookieOptions(), maxAge: undefined });
