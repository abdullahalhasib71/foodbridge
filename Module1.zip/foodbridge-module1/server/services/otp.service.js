/**
 * Feature 1.1 (Member 1)
 * Issue and check one-time codes, with expiry, attempt limits and resend cooldowns.
 */
import { createHmac, randomInt, timingSafeEqual } from 'node:crypto';
import Otp from '../models/Otp.js';
import { OTP, env } from '../config/env.js';
import { HttpError } from './http.js';
import { deliverOtp } from './notify.service.js';

export const hashCode = (code, target) => createHmac('sha256', env.refreshSecret).update(`${target}:${code}`).digest('hex');

export function generateCode() {
  return String(randomInt(0, 10 ** OTP.length)).padStart(OTP.length, '0');
}

export async function issueOtp({ channel, target, purpose }) {
  const now = Date.now();
  const latest = await Otp.findOne({ target, purpose }).sort({ createdAt: -1 });
  if (latest && now - latest.createdAt.getTime() < OTP.resendSeconds * 1000) {
    const wait = Math.ceil((OTP.resendSeconds * 1000 - (now - latest.createdAt.getTime())) / 1000);
    throw new HttpError(429, `Please wait ${wait} seconds before asking for a new code.`, { retryAfter: [String(wait)] });
  }
  const sentLastHour = await Otp.countDocuments({ target, purpose, createdAt: { $gte: new Date(now - 3_600_000) } });
  if (sentLastHour >= OTP.maxPerHour) throw new HttpError(429, 'Too many codes requested. Try again in an hour.');

  const code = generateCode();
  await Otp.create({ target, channel, purpose, codeHash: hashCode(code, target), expiresAt: new Date(now + OTP.ttlSeconds * 1000) });
  await deliverOtp({ channel, target, purpose, code });
  return { code, expiresIn: OTP.ttlSeconds, resendIn: OTP.resendSeconds };
}

/** Throws unless `code` is the latest unexpired code for target+purpose. Consumes it on success. */
export async function verifyOtp({ target, purpose, code }) {
  const otp = await Otp.findOne({ target, purpose }).sort({ createdAt: -1 });
  if (!otp || otp.expiresAt < new Date()) throw new HttpError(400, 'This code has expired. Ask for a new one.', { code: ['Code expired'] });
  if (otp.attempts >= OTP.maxAttempts) throw new HttpError(429, 'Too many wrong codes. Ask for a new one.', { code: ['Too many attempts'] });

  const a = Buffer.from(otp.codeHash, 'hex');
  const b = Buffer.from(hashCode(String(code), target), 'hex');
  if (a.length !== b.length || !timingSafeEqual(a, b)) {
    otp.attempts += 1;
    await otp.save();
    const left = OTP.maxAttempts - otp.attempts;
    throw new HttpError(400, left > 0 ? `That code is not correct. ${left} attempt${left === 1 ? '' : 's'} left.` : 'Too many wrong codes. Ask for a new one.', { code: ['Incorrect code'] });
  }
  await Otp.deleteMany({ target, purpose });
}
