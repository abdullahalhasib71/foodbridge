/**
 * Feature 1.3 (Member 3)
 * Business rules for surplus food posts: the safe time window, the food safety
 * checklist, allowed status changes, automatic expiry and privacy of addresses.
 */
import Donation from '../models/Donation.js';
import { CHECKLIST, COOKED, SAFE_HOURS, toPoint } from '../models/shared.js';
import { HttpError, sameId } from './http.js';

const MIN_REMAINING_MS = 15 * 60_000; // a post must have at least 15 safe minutes left

/** Safe-until time, capped by the category's maximum safe window. */
export function computeSafeUntil(category, cookedAt, hours) {
  const max = SAFE_HOURS[category];
  if (!max) throw new HttpError(400, 'Unknown food category.');
  const h = Math.min(hours ?? max, max);
  return new Date(new Date(cookedAt).getTime() + h * 3_600_000);
}

/** Checks the rules every create or edit must pass. Returns the computed safeUntil. */
export function checkFoodRules(input, user, now = Date.now()) {
  const cookedAt = new Date(input.cookedAt);
  if (Number.isNaN(cookedAt.getTime())) throw new HttpError(400, 'Enter when the food was cooked or prepared.', { cookedAt: ['Required'] });
  if (cookedAt.getTime() > now + 10 * 60_000) throw new HttpError(400, 'Cooking time cannot be in the future.', { cookedAt: ['Cannot be in the future'] });

  const safeUntil = computeSafeUntil(input.category, cookedAt, input.safeHours);
  if (safeUntil.getTime() - now < MIN_REMAINING_MS) {
    throw new HttpError(400, `This food is past (or within 15 minutes of) its safe window of ${SAFE_HOURS[input.category]} hours, so it cannot be posted.`, { cookedAt: ['Too old to share safely'] });
  }
  if (COOKED.includes(input.category) && !CHECKLIST.every((c) => input.checklist?.includes(c))) {
    throw new HttpError(400, 'Confirm every item on the food safety checklist before posting cooked food.', { checklist: ['All three items are required for cooked food'] });
  }
  if (user.role === 'operator' && !input.onBehalf) {
    throw new HttpError(400, 'Add the caller’s name and phone number when posting on someone’s behalf.', { onBehalf: ['Required for hotline operators'] });
  }
  return safeUntil;
}

/** Statuses Module 1 can move between. Module 2 adds claim, pickup and delivery. */
export const TRANSITIONS = {
  available: ['cancelled', 'expired', 'claimed', 'assigned'],
  claimed: ['available', 'assigned', 'picked_up', 'cancelled', 'expired'],
  assigned: ['available', 'claimed', 'picked_up', 'cancelled', 'expired'],
  picked_up: ['delivered'],
  delivered: [],
  expired: [],
  cancelled: [],
};
export const canTransition = (from, to) => TRANSITIONS[from]?.includes(to) ?? false;

export function transition(donation, to, by, note) {
  if (!canTransition(donation.status, to)) throw new HttpError(409, `This donation is ${donation.status.replace('_', ' ')} and cannot become ${to.replace('_', ' ')}.`);
  donation.status = to;
  donation.history.push({ action: to, by, note, at: new Date() });
}

/** Marks every open donation past its safe window as expired. Used by the scheduler and on reads. */
export async function expireStale(now = new Date()) {
  const res = await Donation.updateMany(
    { status: { $in: ['available', 'claimed', 'assigned'] }, safeUntil: { $lt: now } },
    { $set: { status: 'expired' }, $push: { history: { action: 'expired', at: now, note: 'Safe time window ended' } } },
  );
  return res.modifiedCount ?? 0;
}

export async function createDonation(input, user, { photos = [], event } = {}) {
  const safeUntil = checkFoodRules(input, user);
  return Donation.create({
    donor: user._id,
    onBehalf: user.role === 'operator' ? input.onBehalf : undefined,
    event,
    title: input.title,
    category: input.category,
    servings: input.servings,
    foodType: input.foodType,
    notes: input.notes,
    photos,
    address: input.address,
    location: input.location.type ? input.location : toPoint(input.location),
    cookedAt: input.cookedAt,
    safeUntil,
    checklist: input.checklist,
    history: [{ action: 'created', by: user._id, note: event ? 'Posted from a registered event' : undefined }],
  });
}

export const canManage = (donation, user) => user && (user.role === 'admin' || sameId(donation.donor, user));

/**
 * Shape a donation for a viewer. People who did not post it see an approximate
 * location (about 1 km), no street details and no phone numbers.
 */
export function present(donation, user) {
  const d = donation.toJSON();
  const owner = canManage(donation, user);
  if (!owner) {
    d.location = { type: 'Point', coordinates: d.location.coordinates.map((c) => Math.round(c * 100) / 100) };
    if (d.address) delete d.address.details;
    if (d.donor?.phone) delete d.donor.phone;
    if (d.onBehalf) delete d.onBehalf.phone;
    d.history = d.history.map(({ action, at }) => ({ action, at }));
  }
  d.photoUrls = (d.photos ?? []).map((p) => `/media/photos/${p}`);
  d.approximate = !owner;
  d.canManage = Boolean(owner);
  return d;
}
