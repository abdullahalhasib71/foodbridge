export class HttpError extends Error {
  constructor(status, message, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

/** Wrap async handlers so rejected promises reach the error middleware. */
export const ah = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

/** Validate req.body / req.query / req.params with a zod schema; parsed data lands on req.data. */
export const validate = (schema, source = 'body') => (req, _res, next) => {
  const result = schema.safeParse(req[source]);
  if (!result.success) {
    return next(new HttpError(400, 'Please check the highlighted fields.', result.error.flatten().fieldErrors));
  }
  req.data = result.data;
  next();
};

export const sameId = (a, b) => Boolean(a && b) && String(a._id ?? a) === String(b._id ?? b);
