/**
 * Create (or reset) an administrator account.
 *   npm run create-admin -- --phone 01700000000 --password "Secret123" --name "Your Name"
 */
import { parseArgs } from 'node:util';
import bcrypt from 'bcryptjs';
import { connectDB, disconnectDB } from '../config/db.js';
import User from '../models/User.js';

const { values } = parseArgs({ options: { phone: { type: 'string' }, password: { type: 'string' }, name: { type: 'string', default: 'FoodBridge Admin' } } });

if (!/^01[3-9]\d{8}$/.test(values.phone ?? '') || !values.password || values.password.length < 8) {
  console.error('Usage: npm run create-admin -- --phone 017XXXXXXXX --password "AtLeast8Chars1" [--name "Name"]');
  process.exit(1);
}

await connectDB();
const password = await bcrypt.hash(values.password, 12);
let user = await User.findOne({ phone: values.phone }).select('+tokenVersion');
if (user) {
  Object.assign(user, { name: values.name, role: 'admin', status: 'active', password, phoneVerified: true });
  user.verification.status = 'not_required';
  user.tokenVersion += 1; // sign out any old sessions of this account
  await user.save();
} else {
  user = await User.create({ name: values.name, phone: values.phone, role: 'admin', password, phoneVerified: true, verification: { status: 'not_required' } });
}
console.log(`Administrator ready: ${user.name} (${user.phone})`);
await disconnectDB();
