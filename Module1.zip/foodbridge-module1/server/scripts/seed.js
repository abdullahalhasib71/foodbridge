/**
 * Demo data around Dhaka. Run with: npm run seed
 * WARNING: this ERASES existing FoodBridge data in the configured database.
 */
import { writeFile } from 'node:fs/promises';
import path from 'node:path';
import bcrypt from 'bcryptjs';
import { connectDB, disconnectDB } from '../config/db.js';
import User from '../models/User.js';
import Donation from '../models/Donation.js';
import Event from '../models/Event.js';
import Otp from '../models/Otp.js';
import RefreshToken from '../models/RefreshToken.js';
import { toPoint } from '../models/shared.js';
import { DIRS } from '../middleware/upload.js';
import { computeSafeUntil } from '../services/donation.service.js';

export const DEMO_PASSWORD = 'Password123';
const H = 3_600_000;
const ago = (ms) => new Date(Date.now() - ms);

const place = {
  khilgaon: { lat: 23.7516, lng: 90.4255, upazila: 'Dhaka South City Corporation', area: 'Khilgaon' },
  dhanmondi: { lat: 23.7461, lng: 90.3742, upazila: 'Dhaka South City Corporation', area: 'Dhanmondi' },
  mirpur: { lat: 23.8069, lng: 90.3687, upazila: 'Dhaka North City Corporation', area: 'Mirpur 10' },
  mohammadpur: { lat: 23.7662, lng: 90.3589, upazila: 'Dhaka North City Corporation', area: 'Mohammadpur' },
  banani: { lat: 23.7937, lng: 90.4066, upazila: 'Dhaka North City Corporation', area: 'Banani' },
  uttara: { lat: 23.8759, lng: 90.3795, upazila: 'Dhaka North City Corporation', area: 'Uttara Sector 7' },
  savar: { lat: 23.877, lng: 90.3209, upazila: 'Savar', area: 'Birulia' },
};
const addr = (p, details) => ({ division: 'Dhaka', district: 'Dhaka', upazila: p.upazila, area: p.area, details });
const loc = (p) => toPoint(p);

// Tiny placeholder files so the admin review screen has something to open.
const SAMPLE_PDF = `%PDF-1.4
1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj
2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj
3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 420 200]/Contents 4 0 R/Resources<</Font<</F1 5 0 R>>>>>>endobj
4 0 obj<</Length 88>>stream
BT /F1 18 Tf 30 120 Td (SAMPLE DOCUMENT - FoodBridge demo) Tj 0 -30 Td (Not a real ID) Tj ET
endstream endobj
5 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj
trailer<</Root 1 0 R>>
%%EOF`;

async function sampleDoc(name) {
  await writeFile(path.join(DIRS.documents, name), SAMPLE_PDF);
  return { type: 'nid', originalName: 'sample-nid.pdf', storedName: name, mimeType: 'application/pdf', size: SAMPLE_PDF.length };
}

async function run() {
  await connectDB();
  for (const m of [User, Donation, Event, Otp, RefreshToken]) await m.deleteMany({});
  if (process.env.MONGO_AUTO_INDEX !== 'false') for (const m of [User, Donation, Event, Otp, RefreshToken]) await m.syncIndexes();

  const password = await bcrypt.hash(DEMO_PASSWORD, 12);
  const mk = (data) =>
    User.create({ password, phoneVerified: true, verification: { status: ['partner', 'volunteer'].includes(data.role) ? 'approved' : 'not_required' }, ...data });

  const admin = await mk({ name: 'FoodBridge Admin', phone: '01700000000', email: 'admin@foodbridge.local', role: 'admin' });
  const operator = await mk({ name: 'Hotline Desk', phone: '01700000001', role: 'operator', createdBy: admin._id });

  const shapla = await mk({ name: 'Shapla Community Center', phone: '01711000001', email: 'shapla@example.com', role: 'donor', address: addr(place.khilgaon, 'Road 5, Block C'), location: loc(place.khilgaon) });
  const kacchi = await mk({ name: 'Kacchi Ghor Restaurant', phone: '01711000002', role: 'donor', address: addr(place.dhanmondi, 'Satmasjid Road'), location: loc(place.dhanmondi) });

  await mk({ name: 'Farhana Akter', orgName: 'Hope Food Bank', phone: '01811000001', role: 'partner', capacity: 300, address: addr(place.mirpur), location: loc(place.mirpur) });
  await mk({
    name: 'Sajid Hasan', orgName: 'Tongi Youth Kitchen', phone: '01811000003', role: 'partner', capacity: 80,
    address: addr(place.uttara, 'House 12, Road 3'), location: loc(place.uttara),
    verification: { status: 'pending', submittedAt: ago(5 * H), documents: [{ ...(await sampleDoc('demo-org.pdf')), type: 'org_registration', originalName: 'ngo-registration.pdf' }] },
  });

  const tanvir = await mk({ name: 'Tanvir Ahmed', phone: '01911000001', role: 'volunteer', address: addr(place.dhanmondi), location: loc(place.dhanmondi) });
  await mk({
    name: 'Rakib Hossain', phone: '01911000003', role: 'volunteer',
    address: addr(place.mohammadpur, 'Block D'), location: loc(place.mohammadpur),
    verification: { status: 'pending', submittedAt: ago(2 * H), documents: [{ ...(await sampleDoc('demo-nid.pdf')), originalName: 'nid-front.pdf' }] },
  });
  await mk({ name: 'Nadia Islam', phone: '01911000004', role: 'volunteer', verification: { status: 'not_submitted' } });

  const food = (donor, p, f) => {
    const cookedAt = f.cookedAt ?? ago(H);
    return {
      donor: donor._id, address: addr(p, f.details), location: loc(p), cookedAt,
      safeUntil: computeSafeUntil(f.category, cookedAt, f.safeHours), checklist: ['covered', 'fresh', 'hygienic'],
      history: [{ action: 'created', by: donor._id, at: cookedAt }], ...f,
    };
  };
  await Donation.insertMany([
    food(shapla, place.khilgaon, { title: 'Wedding kacchi biryani with borhani', category: 'biryani', servings: 120, foodType: 'nonveg', cookedAt: ago(0.5 * H), details: 'Hall 2, ground floor', notes: 'Packed in foil trays. Please bring bags.' }),
    food(kacchi, place.dhanmondi, { title: 'Chicken polao and egg curry', category: 'biryani', servings: 35, foodType: 'nonveg', cookedAt: ago(2.6 * H), details: 'Back kitchen door' }),
    food(shapla, place.savar, { title: 'Rice, dal and mixed vegetables', category: 'rice_curry', servings: 60, foodType: 'veg', cookedAt: ago(1.2 * H) }),
    food(operator, place.banani, { title: 'Bakery bread and buns', category: 'bakery', servings: 40, foodType: 'veg', cookedAt: ago(6 * H), onBehalf: { name: 'Banani Bake House', phone: '01611000009' } }),
    food(kacchi, place.dhanmondi, { title: 'Bananas and guava', category: 'fruits', servings: 25, foodType: 'veg', cookedAt: ago(3 * H) }),
    food(kacchi, place.dhanmondi, { title: 'Leftover khichuri', category: 'rice_curry', servings: 20, cookedAt: ago(9 * H), status: 'expired' }),
  ]);

  const tomorrow = new Date(Date.now() + 24 * H);
  tomorrow.setHours(19, 0, 0, 0);
  await Event.create({
    host: shapla._id, name: 'Rahman-Chowdhury wedding reception', type: 'wedding', venue: 'Shapla Community Center',
    address: addr(place.khilgaon, 'Road 5, Block C'), location: loc(place.khilgaon), startsAt: tomorrow,
    expectedEnd: new Date(tomorrow.getTime() + 4 * H), guests: 600, expectedSurplus: 100, volunteerSlots: 3, volunteers: [tanvir._id],
  });
  // An event already in progress, so "Food is ready" can be demonstrated straight away.
  await Event.create({
    host: shapla._id, name: 'Milad mahfil for Abdul Karim', type: 'milad', venue: 'Shapla Community Center',
    address: addr(place.khilgaon), location: loc(place.khilgaon), startsAt: ago(H), expectedEnd: new Date(Date.now() + 2 * H),
    guests: 150, expectedSurplus: 40, volunteerSlots: 2,
  });

  console.log(`\nSeed complete. Every demo account uses the password: ${DEMO_PASSWORD}`);
  console.table([
    ['Admin', '01700000000'], ['Hotline operator', '01700000001'], ['Donor (community center)', '01711000001'],
    ['Donor (restaurant)', '01711000002'], ['Organization (verified)', '01811000001'], ['Organization (waiting for review)', '01811000003'],
    ['Volunteer (verified)', '01911000001'], ['Volunteer (waiting for review)', '01911000003'], ['Volunteer (no documents yet)', '01911000004'],
  ].map(([account, phone]) => ({ account, phone })));
  await disconnectDB();
}

if (process.argv[1]?.endsWith('seed.js')) {
  run().catch(async (err) => {
    console.error(err);
    await disconnectDB();
    process.exit(1);
  });
}
