/** Feature 1.3 (Member 3): /api/donations */
import { Router } from 'express';
import { z } from 'zod';
import * as c from '../controllers/donation.controller.js';
import { optionalAuth, requireAuth, requireRole, requireVerified } from '../middleware/auth.js';
import { parsePayload, uploadPhotos } from '../middleware/upload.js';
import { CATEGORIES } from '../models/shared.js';
import { ah, validate } from '../services/http.js';
import { donationCreate, donationUpdate, objectId } from '../validators/schemas.js';

const router = Router();
const idParam = validate(z.object({ id: objectId }).passthrough(), 'params');
const poster = [requireAuth, requireRole('donor', 'operator', 'admin'), requireVerified];

router.get(
  '/',
  optionalAuth,
  validate(
    z.object({
      status: z.enum(['available', 'expired', 'cancelled']).default('available'),
      category: z.enum(CATEGORIES).optional(),
      district: z.string().trim().max(40).optional(),
      q: z.string().trim().max(60).optional(),
      page: z.coerce.number().int().min(1).max(100).default(1),
    }),
    'query',
  ),
  ah(c.list),
);
router.get('/mine', requireAuth, ah(c.mine));
router.get('/:id', optionalAuth, idParam, ah(c.getOne));
router.post('/', ...poster, uploadPhotos, parsePayload, validate(donationCreate), ah(c.create));
router.patch('/:id', ...poster, idParam, uploadPhotos, parsePayload, validate(donationUpdate), ah(c.update));
router.post('/:id/cancel', requireAuth, idParam, validate(z.object({ reason: z.string().trim().max(200).optional() })), ah(c.cancel));

export default router;
