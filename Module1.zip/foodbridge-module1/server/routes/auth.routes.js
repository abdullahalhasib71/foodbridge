/** Feature 1.1 (Member 1): /api/auth */
import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import * as c from '../controllers/auth.controller.js';
import { requireAuth } from '../middleware/auth.js';
import { ah, validate } from '../services/http.js';
import { optionalEmail, otpCode, otpTarget, password, phone } from '../validators/schemas.js';

const router = Router();
const limiter = (limit, minutes) =>
  rateLimit({ windowMs: minutes * 60_000, limit, skip: () => process.env.NODE_ENV === 'test', standardHeaders: 'draft-7', legacyHeaders: false, message: { error: `Too many attempts. Wait ${minutes} minutes and try again.` } });

const registerSchema = z
  .object({
    role: z.enum(['donor', 'partner', 'volunteer']),
    name: z.string().trim().min(2, 'Enter your full name').max(80),
    orgName: z.string().trim().max(120).optional(),
    phone,
    email: optionalEmail,
    password,
    channel: z.enum(['sms', 'email']).default('sms'),
    code: otpCode,
    language: z.enum(['bn', 'en']).optional(),
  })
  .refine((v) => v.role !== 'partner' || (v.orgName && v.orgName.length >= 2), { path: ['orgName'], message: 'Enter your organization’s name' });

const withCode = (extra = {}) => otpTarget.and(z.object({ code: otpCode, ...extra }));

router.post('/otp', limiter(10, 15), validate(otpTarget.and(z.object({ purpose: z.enum(['register', 'login', 'reset']) }))), ah(c.requestOtp));
router.post('/register', limiter(20, 15), validate(registerSchema), ah(c.register));
router.post('/login', limiter(20, 15), validate(z.object({ identifier: z.string().trim().min(3, 'Enter your phone number or email'), password: z.string().min(1, 'Enter your password') })), ah(c.login));
router.post('/login/otp', limiter(20, 15), validate(withCode()), ah(c.loginWithOtp));
router.post('/password/reset', limiter(10, 15), validate(withCode({ password })), ah(c.resetPassword));
router.patch('/password', requireAuth, validate(z.object({ currentPassword: z.string().min(1, 'Enter your current password'), newPassword: password })), ah(c.changePassword));
router.post('/refresh', limiter(120, 15), ah(c.refresh));
router.post('/logout', ah(c.logout));
router.get('/me', requireAuth, c.me);

export default router;
