/** Feature 1.2 (Member 2): /api/profile, /api/locations, /api/documents */
import { Router } from 'express';
import { z } from 'zod';
import * as c from '../controllers/profile.controller.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { uploadDocuments } from '../middleware/upload.js';
import { ah, validate } from '../services/http.js';
import { address, latLng, objectId, optionalEmail } from '../validators/schemas.js';

const router = Router();

const profileSchema = z.object({
  name: z.string().trim().min(2, 'Enter your full name').max(80).optional(),
  email: optionalEmail.or(z.literal('')),
  orgName: z.string().trim().min(2).max(120).optional(),
  capacity: z.coerce.number().int().min(1).max(5000).optional(),
  address: address.optional(),
  location: latLng.optional(),
  language: z.enum(['bn', 'en']).optional(),
});

const ids = (...names) => validate(z.object(Object.fromEntries(names.map((n) => [n, objectId]))).passthrough(), 'params');

router.get('/locations', c.getLocations);

router.get('/profile', requireAuth, c.getProfile);
router.patch('/profile', requireAuth, validate(profileSchema), ah(c.updateProfile));
router.post('/profile/documents', requireAuth, requireRole('partner', 'volunteer'), uploadDocuments, ah(c.uploadDocuments));
router.delete('/profile/documents/:docId', requireAuth, ids('docId'), ah(c.deleteDocument));
router.post('/profile/verification/submit', requireAuth, requireRole('partner', 'volunteer'), ah(c.submitVerification));
router.get('/documents/:userId/:docId', requireAuth, ids('userId', 'docId'), ah(c.downloadDocument));

export default router;
