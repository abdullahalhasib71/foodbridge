/** Feature 1.4 (Member 1): /api/events */
import { Router } from 'express';
import { z } from 'zod';
import * as c from '../controllers/event.controller.js';
import { requireAuth, requireRole, requireVerified } from '../middleware/auth.js';
import { parsePayload, uploadPhotos } from '../middleware/upload.js';
import { ah, validate } from '../services/http.js';
import { eventBody, food, objectId } from '../validators/schemas.js';

const router = Router();
router.use(requireAuth);
const idParam = validate(z.object({ id: objectId }).passthrough(), 'params');
const host = [requireRole('donor', 'operator', 'admin'), requireVerified];

router.get('/', validate(z.object({ scope: z.enum(['upcoming', 'mine', 'joined']).default('upcoming') }), 'query'), ah(c.list));
router.get('/:id', idParam, ah(c.getOne));
router.post('/', ...host, validate(eventBody), ah(c.create));
router.put('/:id', ...host, idParam, validate(eventBody), ah(c.update));
router.post('/:id/volunteers', requireRole('volunteer'), requireVerified, idParam, ah(c.join));
router.delete('/:id/volunteers', requireRole('volunteer'), idParam, ah(c.leave));
router.post('/:id/convert', ...host, idParam, uploadPhotos, parsePayload, validate(food), ah(c.convert));
router.post('/:id/cancel', idParam, ah(c.cancel));

export default router;
