/** Feature 1.2 (Member 2): /api/admin */
import { Router } from 'express';
import { z } from 'zod';
import * as c from '../controllers/admin.controller.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { ah, validate } from '../services/http.js';
import { objectId, optionalEmail, password, phone } from '../validators/schemas.js';

const router = Router();
router.use(requireAuth, requireRole('admin'));

const idParam = validate(z.object({ id: objectId }).passthrough(), 'params');

router.get('/stats', ah(c.stats));
router.get('/verifications', validate(z.object({ status: z.enum(['pending', 'approved', 'rejected', 'not_submitted']).optional() }), 'query'), ah(c.listVerifications));
router.post('/verifications/:id/approve', idParam, validate(z.object({ note: z.string().trim().max(500).optional() })), ah(c.approve));
router.post('/verifications/:id/reject', idParam, validate(z.object({ reason: z.string().trim().min(5, 'Tell the applicant what to fix').max(500) })), ah(c.reject));
router.get('/users', validate(z.object({ role: z.enum(['donor', 'partner', 'volunteer', 'operator', 'admin']).optional(), status: z.enum(['active', 'suspended']).optional(), q: z.string().trim().max(60).optional() }), 'query'), ah(c.listUsers));
router.patch('/users/:id/status', idParam, validate(z.object({ status: z.enum(['active', 'suspended']) })), ah(c.setStatus));
router.post('/operators', validate(z.object({ name: z.string().trim().min(2).max(80), phone, email: optionalEmail, password })), ah(c.createOperator));

export default router;
