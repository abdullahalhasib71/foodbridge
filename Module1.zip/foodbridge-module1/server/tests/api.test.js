/**
 * End-to-end API tests for Module 1. They need a throwaway database:
 *   TEST_MONGODB_URI=mongodb://127.0.0.1:27017/foodbridge_test npm test
 * Without TEST_MONGODB_URI these tests are skipped.
 */
import { after, before, describe, test } from 'node:test';
import assert from 'node:assert/strict';
import { readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';

const uri = process.env.TEST_MONGODB_URI;
process.env.NODE_ENV = 'test';
process.env.SHOW_DEV_OTP = 'true';
process.env.JWT_ACCESS_SECRET ??= 'test-access-secret';
process.env.JWT_REFRESH_SECRET ??= 'test-refresh-secret';

describe('Module 1 API', { skip: !uri && 'set TEST_MONGODB_URI to run API tests' }, () => {
  let request, app, mongoose, User, Otp, Donation, Event, DIRS, runJobs;
  const H = 3_600_000;

  before(async () => {
    ({ default: request } = await import('supertest'));
    ({ default: app } = await import('../app.js'));
    ({ default: mongoose } = await import('mongoose'));
    const { connectDB } = await import('../config/db.js');
    await connectDB(uri);
    await mongoose.connection.db.dropDatabase();
    ({ default: User } = await import('../models/User.js'));
    ({ default: Otp } = await import('../models/Otp.js'));
    ({ default: Donation } = await import('../models/Donation.js'));
    ({ default: Event } = await import('../models/Event.js'));
    ({ DIRS } = await import('../middleware/upload.js'));
    ({ runJobs } = await import('../jobs/scheduler.js'));
  });
  after(async () => {
    await mongoose.connection.db.dropDatabase();
    await mongoose.disconnect();
  });

  const agentFor = () => request.agent(app);
  const bearer = (t) => ({ Authorization: `Bearer ${t}` });
  const LOC = { lat: 23.7516, lng: 90.4255 };
  const ADDR = { division: 'Dhaka', district: 'Dhaka', upazila: 'Dhaka South City Corporation', area: 'Khilgaon', details: 'Road 5' };

  async function signUp(role, phone, extra = {}) {
    const agent = agentFor();
    const otp = await agent.post('/api/auth/otp').send({ purpose: 'register', channel: 'sms', phone }).expect(200);
    assert.match(otp.body.devCode, /^\d{6}$/);
    const res = await agent
      .post('/api/auth/register')
      .send({ role, name: `Test ${role}`, phone, password: 'Pass1234', code: otp.body.devCode, channel: 'sms', ...extra })
      .expect(201);
    return { agent, token: res.body.accessToken, user: res.body.user };
  }

  let donor, volunteer, admin;

  test('register with phone OTP, then refresh, logout', async () => {
    donor = await signUp('donor', '01711000001');
    assert.equal(donor.user.role, 'donor');
    assert.equal(donor.user.isVerified, true);
    assert.equal(donor.user.password, undefined);

    const r = await donor.agent.post('/api/auth/refresh').expect(200);
    assert.ok(r.body.accessToken);
    await donor.agent.get('/api/auth/me').set(bearer(r.body.accessToken)).expect(200);
    donor.token = r.body.accessToken;
  });

  test('a wrong code is rejected and counted; duplicate phone is refused', async () => {
    const a = agentFor();
    await a.post('/api/auth/otp').send({ purpose: 'register', channel: 'sms', phone: '01711000009' }).expect(200);
    const bad = await a.post('/api/auth/register').send({ role: 'donor', name: 'X Y', phone: '01711000009', password: 'Pass1234', code: '000000' });
    assert.equal(bad.status, 400);
    await a.post('/api/auth/otp').send({ purpose: 'register', channel: 'sms', phone: '01711000009' }).expect(429); // resend cooldown
    await a.post('/api/auth/otp').send({ purpose: 'register', channel: 'sms', phone: '01711000001' }).expect(409);
  });

  test('refresh token rotation detects reuse', async () => {
    const s = await signUp('donor', '01711000002');
    const first = s.agent.jar.getCookie('fb_refresh', { path: '/api/auth', domain: '127.0.0.1', secure: false, script: false });
    await s.agent.post('/api/auth/refresh').expect(200);
    // Replaying the old cookie revokes the whole family.
    const replay = await request(app).post('/api/auth/refresh').set('Cookie', `fb_refresh=${first?.value}`);
    assert.equal(replay.status, 401);
    await s.agent.post('/api/auth/refresh').expect(401);
  });

  test('password login, lockout after 5 failures, OTP login, password reset', async () => {
    await request(app).post('/api/auth/login').send({ identifier: '01711000001', password: 'Pass1234' }).expect(200);
    for (let i = 0; i < 5; i++) await request(app).post('/api/auth/login').send({ identifier: '01711000001', password: 'wrong123' }).expect(401);
    await request(app).post('/api/auth/login').send({ identifier: '01711000001', password: 'Pass1234' }).expect(423);

    const o = await request(app).post('/api/auth/otp').send({ purpose: 'login', channel: 'sms', phone: '01711000001' }).expect(200);
    await request(app).post('/api/auth/login/otp').send({ channel: 'sms', phone: '01711000001', code: o.body.devCode }).expect(200);

    const r = await request(app).post('/api/auth/otp').send({ purpose: 'reset', channel: 'sms', phone: '01711000001' }).expect(200);
    await request(app).post('/api/auth/password/reset').send({ channel: 'sms', phone: '01711000001', code: r.body.devCode, password: 'NewPass123' }).expect(200);
    await User.updateOne({ phone: '01711000001' }, { $unset: { lockedUntil: 1 } });
    await request(app).post('/api/auth/login').send({ identifier: '01711000001', password: 'NewPass123' }).expect(200);
    // The old access token was invalidated by the reset.
    await request(app).get('/api/auth/me').set(bearer(donor.token)).expect(401);
    const fresh = await request(app).post('/api/auth/login').send({ identifier: '01711000001', password: 'NewPass123' });
    donor.token = fresh.body.accessToken;

    // Unknown numbers get the same answer for reset (no account enumeration).
    const ghost = await request(app).post('/api/auth/otp').send({ purpose: 'reset', channel: 'sms', phone: '01799999999' }).expect(200);
    assert.equal(ghost.body.devCode, undefined);
  });

  test('roles: volunteers cannot post food; operators cannot self-register', async () => {
    volunteer = await signUp('volunteer', '01911000001');
    assert.equal(volunteer.user.isVerified, false);
    assert.equal(volunteer.user.verification.status, 'not_submitted');
    await request(app).post('/api/donations').set(bearer(volunteer.token)).send({}).expect(403);
    const a = agentFor();
    const o = await a.post('/api/auth/otp').send({ purpose: 'register', channel: 'sms', phone: '01911000002' });
    await a.post('/api/auth/register').send({ role: 'operator', name: 'Op', phone: '01911000002', password: 'Pass1234', code: o.body.devCode }).expect(400);
  });

  test('profile, documents, submission and admin approval', async () => {
    await request(app).patch('/api/profile').set(bearer(volunteer.token)).send({ address: { ...ADDR, upazila: 'Kaliakair' } }).expect(400);
    await request(app).patch('/api/profile').set(bearer(volunteer.token)).send({ address: ADDR, location: LOC, email: 'tanvir@example.com' }).expect(200);

    const pdf = path.join(os.tmpdir(), 'fb-id.pdf');
    const fake = path.join(os.tmpdir(), 'fb-fake.pdf');
    await writeFile(pdf, '%PDF-1.4\n%test\n');
    await writeFile(fake, 'MZ this is not a pdf');
    await request(app).post('/api/profile/documents').set(bearer(volunteer.token)).field('type', 'nid').attach('documents', fake, { contentType: 'application/pdf' }).expect(400);
    const up = await request(app).post('/api/profile/documents').set(bearer(volunteer.token)).field('type', 'nid').attach('documents', pdf).expect(201);
    const doc = up.body.user.verification.documents[0];
    assert.equal(doc.storedName, undefined, 'stored file name is never exposed');

    await request(app).post('/api/profile/verification/submit').set(bearer(volunteer.token)).expect(200);
    await request(app).delete(`/api/profile/documents/${doc._id}`).set(bearer(volunteer.token)).expect(409);

    // Make an admin directly in the database (like npm run create-admin).
    const adminSignup = await signUp('donor', '01700000000');
    await User.updateOne({ _id: adminSignup.user._id }, { role: 'admin', 'verification.status': 'not_required' });
    const login = await request(app).post('/api/auth/login').send({ identifier: '01700000000', password: 'Pass1234' });
    admin = { token: login.body.accessToken, id: adminSignup.user._id };

    await request(app).get(`/api/documents/${volunteer.user._id}/${doc._id}`).set(bearer(donor.token)).expect(403);
    const file = await request(app).get(`/api/documents/${volunteer.user._id}/${doc._id}`).set(bearer(admin.token)).expect(200);
    assert.equal(file.headers['content-type'], 'application/pdf');

    const queue = await request(app).get('/api/admin/verifications').set(bearer(admin.token)).expect(200);
    assert.equal(queue.body.items.length, 1);
    await request(app).post(`/api/admin/verifications/${volunteer.user._id}/reject`).set(bearer(admin.token)).send({ reason: 'x' }).expect(400);
    await request(app).post(`/api/admin/verifications/${volunteer.user._id}/approve`).set(bearer(admin.token)).send({}).expect(200);
    const me = await request(app).get('/api/auth/me').set(bearer(volunteer.token)).expect(200);
    assert.equal(me.body.user.isVerified, true);
    assert.ok(me.body.user.verification.documents[0].purgedAt, 'documents deleted after approval');
    const stored = (await User.findById(volunteer.user._id)).verification.documents[0].storedName;
    assert.equal((await readdir(DIRS.documents)).includes(stored), false, 'file removed from disk');
  });

  let donationId;
  test('post food with a photo, edit it, privacy for strangers, cancel', async () => {
    const png = path.join(os.tmpdir(), 'fb.png');
    await writeFile(png, Buffer.from('89504e470d0a1a0a0000000d4948445200000001000000010806000000', 'hex'));
    const payload = { title: 'Wedding biryani', category: 'biryani', servings: 80, foodType: 'nonveg', cookedAt: new Date(Date.now() - H).toISOString(), checklist: ['covered', 'fresh', 'hygienic'], address: ADDR, location: LOC };

    const noCheck = await request(app).post('/api/donations').set(bearer(donor.token)).field('payload', JSON.stringify({ ...payload, checklist: [] }));
    assert.equal(noCheck.status, 400);
    assert.ok(noCheck.body.details.checklist);

    const res = await request(app).post('/api/donations').set(bearer(donor.token)).field('payload', JSON.stringify(payload)).attach('photos', png).expect(201);
    donationId = res.body.donation._id;
    assert.equal(res.body.donation.photos.length, 1);
    assert.equal(new Date(res.body.donation.safeUntil) - new Date(payload.cookedAt), 4 * H);
    await request(app).get(res.body.donation.photoUrls[0]).expect(200);

    const stranger = await request(app).get(`/api/donations/${donationId}`).expect(200);
    assert.equal(stranger.body.donation.address.details, undefined);
    assert.equal(stranger.body.donation.approximate, true);

    await request(app).patch(`/api/donations/${donationId}`).set(bearer(volunteer.token)).field('payload', JSON.stringify(payload)).expect(403);
    const edit = await request(app)
      .patch(`/api/donations/${donationId}`)
      .set(bearer(donor.token))
      .field('payload', JSON.stringify({ ...payload, servings: 100, keepPhotos: [] }))
      .expect(200);
    assert.equal(edit.body.donation.servings, 100);
    assert.equal(edit.body.donation.photos.length, 0);
    assert.equal(edit.body.donation.history.at(-1).action, 'edited');

    const list = await request(app).get('/api/donations?category=biryani').expect(200);
    assert.equal(list.body.total, 1);

    await request(app).post(`/api/donations/${donationId}/cancel`).set(bearer(donor.token)).send({ reason: 'Guests took it home' }).expect(200);
    await request(app).post(`/api/donations/${donationId}/cancel`).set(bearer(donor.token)).send({}).expect(409);
  });

  test('hotline operator posts for a caller; scheduler expires old food', async () => {
    const op = await request(app)
      .post('/api/admin/operators')
      .set(bearer(admin.token))
      .send({ name: 'Hotline Desk', phone: '01700000001', password: 'Pass1234' })
      .expect(201);
    assert.equal(op.body.user.role, 'operator');
    const login = await request(app).post('/api/auth/login').send({ identifier: '01700000001', password: 'Pass1234' }).expect(200);
    const base = { title: 'Bread', category: 'bakery', servings: 30, cookedAt: new Date(Date.now() - H).toISOString(), address: ADDR, location: LOC };
    await request(app).post('/api/donations').set(bearer(login.body.accessToken)).field('payload', JSON.stringify(base)).expect(400);
    const ok = await request(app)
      .post('/api/donations')
      .set(bearer(login.body.accessToken))
      .field('payload', JSON.stringify({ ...base, onBehalf: { name: 'Banani Bake House', phone: '01611000009' } }))
      .expect(201);
    assert.equal(ok.body.donation.onBehalf.name, 'Banani Bake House');

    await Donation.updateOne({ _id: ok.body.donation._id }, { safeUntil: new Date(Date.now() - 60_000) });
    const r = await runJobs();
    assert.equal(r.expired, 1);
    assert.equal((await Donation.findById(ok.body.donation._id)).status, 'expired');
  });

  test('events: register, volunteer slots, convert to a donation once', async () => {
    const starts = new Date(Date.now() - H);
    const body = { name: 'Rahman wedding', type: 'wedding', venue: 'Shapla Community Center', address: ADDR, location: LOC, startsAt: starts.toISOString(), expectedEnd: new Date(Date.now() + 3 * H).toISOString(), guests: 500, volunteerSlots: 1 };
    await request(app).post('/api/events').set(bearer(volunteer.token)).send(body).expect(403);
    const ev = await request(app).post('/api/events').set(bearer(donor.token)).send(body).expect(201);
    const id = ev.body.event._id;

    await request(app).post(`/api/events/${id}/volunteers`).set(bearer(volunteer.token)).expect(200);
    const second = await signUp('volunteer', '01911000005');
    await User.updateOne({ _id: second.user._id }, { 'verification.status': 'approved' });
    await request(app).post(`/api/events/${id}/volunteers`).set(bearer(second.token)).expect(409); // slots full

    const hostView = await request(app).get(`/api/events/${id}`).set(bearer(donor.token)).expect(200);
    assert.equal(hostView.body.event.volunteers.length, 1);
    const otherView = await request(app).get(`/api/events/${id}`).set(bearer(second.token)).expect(200);
    assert.equal(otherView.body.event.volunteers, undefined);

    const food = { title: 'Wedding leftovers', category: 'biryani', servings: 90, cookedAt: new Date(Date.now() - H).toISOString(), checklist: ['covered', 'fresh', 'hygienic'] };
    const conv = await request(app).post(`/api/events/${id}/convert`).set(bearer(donor.token)).field('payload', JSON.stringify(food)).expect(201);
    assert.equal(conv.body.donation.event, id);
    assert.equal(conv.body.donation.address.area, 'Khilgaon');
    await request(app).post(`/api/events/${id}/convert`).set(bearer(donor.token)).field('payload', JSON.stringify(food)).expect(409);
    assert.equal((await Event.findById(id)).status, 'converted');
  });

  test('admin can suspend an account, which ends its sessions', async () => {
    await request(app).patch(`/api/admin/users/${volunteer.user._id}/status`).set(bearer(admin.token)).send({ status: 'suspended' }).expect(200);
    await request(app).get('/api/auth/me').set(bearer(volunteer.token)).expect(401);
    await volunteer.agent.post('/api/auth/refresh').expect(401);
    await request(app).post('/api/auth/login').send({ identifier: '01911000001', password: 'Pass1234' }).expect(403);
    assert.equal(await Otp.countDocuments({ target: '01911000001' }), 0);
  });
});
