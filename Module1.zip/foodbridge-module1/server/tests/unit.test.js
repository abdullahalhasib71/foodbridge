import { test } from 'node:test';
import assert from 'node:assert/strict';
process.env.JWT_ACCESS_SECRET ??= 'test-access';
process.env.JWT_REFRESH_SECRET ??= 'test-refresh';

const { canTransition, checkFoodRules, computeSafeUntil, transition } = await import('../services/donation.service.js');
const { generateCode, hashCode } = await import('../services/otp.service.js');
const { isValidAddress } = await import('../services/locations.service.js');
const { address, password, phone } = await import('../validators/schemas.js');

const donor = { role: 'donor' };
const operator = { role: 'operator' };
const now = new Date('2026-10-10T12:00:00Z').getTime();
const H = 3_600_000;

test('cooked food is capped at 4 hours even if the donor asks for more', () => {
  const cooked = new Date('2026-10-10T12:00:00Z');
  assert.equal(computeSafeUntil('biryani', cooked, 10).toISOString(), '2026-10-10T16:00:00.000Z');
  assert.equal(computeSafeUntil('rice_curry', cooked, 2).toISOString(), '2026-10-10T14:00:00.000Z');
  assert.equal(computeSafeUntil('packaged', cooked).toISOString(), '2026-10-13T12:00:00.000Z');
});

test('food rules: checklist, age and hotline caller', () => {
  const base = { category: 'biryani', cookedAt: new Date(now - H), checklist: ['covered', 'fresh', 'hygienic'] };
  assert.ok(checkFoodRules(base, donor, now) instanceof Date);
  assert.throws(() => checkFoodRules({ ...base, checklist: ['covered'] }, donor, now), { status: 400 });
  assert.throws(() => checkFoodRules({ ...base, cookedAt: new Date(now - 3.9 * H) }, donor, now), /safe window/);
  assert.throws(() => checkFoodRules({ ...base, cookedAt: new Date(now + H) }, donor, now), /future/);
  assert.throws(() => checkFoodRules(base, operator, now), /behalf/);
  assert.ok(checkFoodRules({ ...base, onBehalf: { name: 'Caller', phone: '01711111111' } }, operator, now));
  assert.ok(checkFoodRules({ category: 'packaged', cookedAt: new Date(now - H) }, donor, now), 'packaged food needs no checklist');
});

test('status transitions', () => {
  assert.ok(canTransition('available', 'cancelled'));
  assert.ok(canTransition('available', 'expired'));
  assert.equal(canTransition('expired', 'available'), false);
  assert.equal(canTransition('cancelled', 'available'), false);
  const d = { status: 'available', history: [] };
  transition(d, 'cancelled', 'u1', 'Guests stayed late');
  assert.equal(d.status, 'cancelled');
  assert.equal(d.history.at(-1).action, 'cancelled');
  assert.throws(() => transition(d, 'expired', 'u1'), { status: 409 });
});

test('OTP codes are 6 digits and stored only as a keyed hash', () => {
  for (let i = 0; i < 50; i++) assert.match(generateCode(), /^\d{6}$/);
  const h = hashCode('123456', '01711000001');
  assert.equal(h.length, 64);
  assert.notEqual(h, hashCode('123456', '01711000002'), 'same code for another number hashes differently');
});

test('Bangladeshi phone numbers are normalised and validated', () => {
  assert.equal(phone.parse('+8801712-345678'), '01712345678');
  assert.equal(phone.parse('017 1234 5678'), '01712345678');
  assert.equal(phone.safeParse('01212345678').success, false);
  assert.equal(phone.safeParse('0171234567').success, false);
});

test('passwords need 8+ characters with a letter and a number', () => {
  assert.equal(password.safeParse('password').success, false);
  assert.equal(password.safeParse('12345678').success, false);
  assert.equal(password.safeParse('Pass1234').success, true);
});

test('address hierarchy must be consistent', () => {
  assert.ok(isValidAddress({ division: 'Dhaka', district: 'Dhaka', upazila: 'Savar' }));
  assert.ok(isValidAddress({ division: 'Dhaka', district: 'Dhaka', upazila: 'Dhaka North City Corporation' }));
  assert.equal(isValidAddress({ division: 'Dhaka', district: 'Dhaka', upazila: 'Kotwali' }), false);
  assert.equal(isValidAddress({ division: 'Sylhet', district: 'Dhaka' }), false);
  const r = address.safeParse({ division: 'Dhaka', district: 'Gazipur', upazila: 'Savar', area: 'Birulia' });
  assert.equal(r.success, false);
  assert.deepEqual(r.error.flatten().fieldErrors.upazila, ['This upazila does not belong to the chosen district']);
});
