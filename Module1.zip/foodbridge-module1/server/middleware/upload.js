/**
 * Feature 1.2 (Member 2) and Feature 1.3 (Member 3)
 * File uploads with Multer. The browser's claimed file type is not trusted:
 * every file's first bytes are checked to confirm it is really a JPEG, PNG, WebP or PDF.
 */
import { randomUUID } from 'node:crypto';
import { open, unlink } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import multer from 'multer';
import { HttpError } from '../services/http.js';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'storage');
export const DIRS = { documents: path.join(root, 'documents'), photos: path.join(root, 'photos') };

const EXT = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp', 'application/pdf': '.pdf' };

const SIGNATURES = [
  ['image/jpeg', (b) => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff],
  ['image/png', (b) => b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))],
  ['image/webp', (b) => b.subarray(0, 4).toString() === 'RIFF' && b.subarray(8, 12).toString() === 'WEBP'],
  ['application/pdf', (b) => b.subarray(0, 5).toString() === '%PDF-'],
];

async function sniff(file) {
  const fh = await open(file.path, 'r');
  try {
    const { buffer } = await fh.read(Buffer.alloc(12), 0, 12, 0);
    return SIGNATURES.find(([, test]) => test(buffer))?.[0];
  } finally {
    await fh.close();
  }
}

function makeUploader({ dir, field, maxCount, maxMb, types }) {
  const upload = multer({
    storage: multer.diskStorage({
      destination: dir,
      filename: (_req, file, cb) => cb(null, `${randomUUID()}${EXT[file.mimetype] ?? ''}`),
    }),
    limits: { fileSize: maxMb * 1024 * 1024, files: maxCount },
    fileFilter: (_req, file, cb) =>
      types.includes(file.mimetype) ? cb(null, true) : cb(new HttpError(400, `Only ${types.map((t) => EXT[t].slice(1).toUpperCase()).join(', ')} files are allowed.`)),
  }).array(field, maxCount);

  return (req, res, next) =>
    upload(req, res, async (err) => {
      if (err) {
        if (err.code === 'LIMIT_FILE_SIZE') return next(new HttpError(400, `Each file must be ${maxMb} MB or smaller.`));
        if (err.code === 'LIMIT_FILE_COUNT' || err.code === 'LIMIT_UNEXPECTED_FILE') return next(new HttpError(400, `You can upload at most ${maxCount} files at a time.`));
        return next(err);
      }
      try {
        for (const f of req.files ?? []) {
          const real = await sniff(f);
          if (!real || !types.includes(real)) {
            await removeFiles(req.files);
            return next(new HttpError(400, `"${f.originalname}" is not a valid file of an allowed type.`));
          }
          f.mimetype = real;
        }
        next();
      } catch (e) {
        next(e);
      }
    });
}

export const removeFiles = (files = []) => Promise.all(files.map((f) => unlink(f.path ?? f).catch(() => {})));

export const uploadDocuments = makeUploader({ dir: DIRS.documents, field: 'documents', maxCount: 3, maxMb: 5, types: ['image/jpeg', 'image/png', 'application/pdf'] });
export const uploadPhotos = makeUploader({ dir: DIRS.photos, field: 'photos', maxCount: 3, maxMb: 3, types: ['image/jpeg', 'image/png', 'image/webp'] });

/** Multipart forms send structured data as one JSON field called "payload". */
export const parsePayload = (req, _res, next) => {
  if (typeof req.body?.payload !== 'string') return next();
  try {
    req.body = JSON.parse(req.body.payload);
    next();
  } catch {
    next(new HttpError(400, 'The form data could not be read.'));
  }
};
