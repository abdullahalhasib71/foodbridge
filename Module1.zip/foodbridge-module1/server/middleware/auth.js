/**
 * Feature 1.1 (Member 1)
 * Role-based access control.
 *   requireAuth          any signed-in, active user
 *   requireRole(...)     only the listed roles
 *   requireVerified      organizations and volunteers must be approved by an admin
 */
import User from '../models/User.js';
import { HttpError, ah } from '../services/http.js';
import { verifyAccessToken } from '../services/token.service.js';

async function userFromRequest(req) {
  const header = req.headers.authorization ?? '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return null;
  let payload;
  try {
    payload = verifyAccessToken(token);
  } catch {
    throw new HttpError(401, 'Your session has expired. Sign in again.', { reason: ['token_expired'] });
  }
  const user = await User.findById(payload.sub).select('+tokenVersion');
  if (!user || user.tokenVersion !== payload.tv) throw new HttpError(401, 'Please sign in again.', { reason: ['token_revoked'] });
  if (user.status === 'suspended') throw new HttpError(403, 'This account is suspended. Contact an administrator.');
  return user;
}

export const requireAuth = ah(async (req, _res, next) => {
  req.user = await userFromRequest(req);
  if (!req.user) throw new HttpError(401, 'Sign in to continue.');
  next();
});

/** Attaches req.user when a valid token is present, but never blocks the request. */
export const optionalAuth = ah(async (req, _res, next) => {
  try {
    req.user = await userFromRequest(req);
  } catch {
    req.user = null;
  }
  next();
});

export const requireRole = (...roles) => (req, _res, next) =>
  roles.includes(req.user?.role) ? next() : next(new HttpError(403, 'Your account type cannot do this.'));

export const requireVerified = (req, _res, next) =>
  req.user?.isVerified
    ? next()
    : next(new HttpError(403, 'Your account is waiting for verification by an administrator. Upload your documents from your profile.'));
