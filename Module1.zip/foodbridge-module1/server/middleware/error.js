import { removeFiles } from './upload.js';

export const notFound = (_req, res) => res.status(404).json({ error: 'This API route does not exist.' });

// eslint-disable-next-line no-unused-vars
export async function errorHandler(err, req, res, _next) {
  // A request that failed after files were uploaded should not leave orphan files behind.
  if (req.files?.length) await removeFiles(req.files);

  let status = err.status ?? 500;
  let message = err.message;
  if (err.code === 11000) {
    status = 409;
    const field = Object.keys(err.keyPattern ?? {})[0];
    message = field === 'phone' ? 'An account with this phone number already exists.' : field === 'email' ? 'This email address is already in use.' : 'This record already exists.';
  } else if (err.name === 'ValidationError') status = 400;
  else if (err.name === 'CastError') [status, message] = [404, 'Not found.'];

  if (status >= 500) {
    console.error(err);
    message = 'Something went wrong on the server. Try again in a moment.';
  }
  res.status(status).json({ error: message, details: err.details });
}
