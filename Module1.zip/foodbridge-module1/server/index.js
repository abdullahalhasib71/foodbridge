import app from './app.js';
import { connectDB } from './config/db.js';
import { env } from './config/env.js';
import { startScheduler } from './jobs/scheduler.js';

try {
  env.accessSecret; // fail fast if secrets are missing
  env.refreshSecret;
  await connectDB();
  startScheduler();
  app.listen(env.port, () => {
    console.log(`\nFoodBridge Module 1 API ready on http://localhost:${env.port}/api/health`);
    if (env.showDevOtp) console.log('Development mode: one-time codes are printed here and shown on screen.\n');
  });
} catch (err) {
  console.error(`\nCould not start the server: ${err.message}\n`);
  process.exit(1);
}
