/**
 * Feature 1.3 (Member 3) and Feature 1.4 (Member 1)
 * Background jobs, run every minute with node-cron:
 *   - expire food posts whose safe window has ended
 *   - close events that ended more than 12 hours ago without posting food
 */
import cron from 'node-cron';
import Event from '../models/Event.js';
import { expireStale } from '../services/donation.service.js';

export async function runJobs(now = new Date()) {
  const expired = await expireStale(now);
  const closed = await Event.updateMany(
    { status: 'upcoming', expectedEnd: { $lt: new Date(now.getTime() - 12 * 3_600_000) } },
    { $set: { status: 'closed' } },
  );
  return { expired, closedEvents: closed.modifiedCount ?? 0 };
}

export function startScheduler() {
  const task = cron.schedule('* * * * *', async () => {
    try {
      const r = await runJobs();
      if (r.expired || r.closedEvents) console.log(`[jobs] expired ${r.expired} donation(s), closed ${r.closedEvents} event(s)`);
    } catch (err) {
      console.error('[jobs] failed:', err.message);
    }
  });
  return task;
}
