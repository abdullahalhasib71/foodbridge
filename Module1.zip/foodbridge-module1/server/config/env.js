// Central place for configuration. Everything else imports from here,
// so a missing setting fails loudly in one place.
const bool = (v, fallback) => (v == null || v === '' ? fallback : ['1', 'true', 'yes'].includes(String(v).toLowerCase()));

export const env = {
  get mongoUri() { return process.env.MONGODB_URI; },
  get accessSecret() { return required('JWT_ACCESS_SECRET'); },
  get refreshSecret() { return required('JWT_REFRESH_SECRET'); },
  get port() { return Number(process.env.PORT) || 5000; },
  get production() { return process.env.NODE_ENV === 'production'; },
  get clientUrl() { return process.env.CLIENT_URL || 'http://localhost:5173'; },
  get showDevOtp() { return !this.production && bool(process.env.SHOW_DEV_OTP, true); },
  get deleteDocsOnApproval() { return bool(process.env.DELETE_DOCS_ON_APPROVAL, true); },
  get smtp() {
    return {
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT) || 587,
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
      from: process.env.MAIL_FROM || 'FoodBridge <no-reply@foodbridge.local>',
    };
  },
};

function required(name) {
  const v = process.env[name];
  if (!v) throw new Error(`${name} is not set. Copy .env.example to .env and fill it in.`);
  return v;
}

export const ACCESS_TTL = '15m';
export const REFRESH_TTL_DAYS = 7;
export const OTP = { length: 6, ttlSeconds: 300, maxAttempts: 5, resendSeconds: 60, maxPerHour: 5 };
export const LOGIN_LOCK = { maxFailures: 5, minutes: 15 };
