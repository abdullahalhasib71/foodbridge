import mongoose from 'mongoose';
import { env } from './env.js';

export async function connectDB(uri = env.mongoUri) {
  if (!uri) throw new Error('MONGODB_URI is not set. Copy .env.example to .env and fill it in.');
  if (mongoose.connection.readyState === 1) return mongoose.connection;
  // MONGO_AUTO_INDEX=false skips index builds (only needed for MongoDB-compatible test servers).
  await mongoose.connect(uri, { serverSelectionTimeoutMS: 8000, autoIndex: process.env.MONGO_AUTO_INDEX !== 'false' });
  return mongoose.connection;
}

export const disconnectDB = () => mongoose.disconnect();
