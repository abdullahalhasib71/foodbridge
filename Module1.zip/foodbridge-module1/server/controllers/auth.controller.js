/**
 * Feature 1.1 (Member 1): Multi-Role Registration and Authentication
 */
import bcrypt from 'bcryptjs';
import User, { NEEDS_VERIFICATION } from '../models/User.js';
import { LOGIN_LOCK, env } from '../config/env.js';
import { HttpError } from '../services/http.js';
import { issueOtp, verifyOtp } from '../services/otp.service.js';
import { endSession, revokeAllSessions, rotateSession, startSession } from '../services/token.service.js';

const targetOf = (d) => (d.channel === 'sms' ? d.phone : d.email);
const findByTarget = (d) => User.findOne(d.channel === 'sms' ? { phone: d.phone } : { email: d.email });

// POST /api/auth/otp  { purpose, channel, phone | email }
export async function requestOtp(req, res) {
  const { purpose } = req.data;
  const target = targetOf(req.data);
  const existing = await findByTarget(req.data);

  if (purpose === 'register' && req.data.channel === 'sms' && existing) {
    throw new HttpError(409, 'An account with this phone number already exists. Sign in instead.', { phone: ['Already registered'] });
  }
  if (purpose === 'register' && req.data.channel === 'email' && existing) {
    throw new HttpError(409, 'This email address is already in use.', { email: ['Already registered'] });
  }
  if (purpose === 'login' && !existing) {
    throw new HttpError(404, 'No account uses this number or email. Create an account first.');
  }
  if (purpose === 'reset' && !existing) {
    // Do not reveal whether an account exists: answer exactly as if a code was sent.
    return res.json({ sent: true, channel: req.data.channel, expiresIn: 300, resendIn: 60 });
  }

  const { code, expiresIn, resendIn } = await issueOtp({ channel: req.data.channel, target, purpose });
  res.json({ sent: true, channel: req.data.channel, expiresIn, resendIn, ...(env.showDevOtp && { devCode: code }) });
}

// POST /api/auth/register
export async function register(req, res) {
  const { code, channel, password, ...data } = req.data;
  if (await User.exists({ phone: data.phone })) throw new HttpError(409, 'An account with this phone number already exists. Sign in instead.', { phone: ['Already registered'] });
  if (data.email && (await User.exists({ email: data.email }))) throw new HttpError(409, 'This email address is already in use.', { email: ['Already registered'] });

  const target = channel === 'sms' ? data.phone : data.email;
  if (!target) throw new HttpError(400, 'Add an email address to receive the code by email.', { email: ['Required to verify by email'] });
  await verifyOtp({ target, purpose: 'register', code });

  const user = await User.create({
    ...data,
    password: await bcrypt.hash(password, 12),
    phoneVerified: channel === 'sms',
    emailVerified: channel === 'email',
    verification: { status: NEEDS_VERIFICATION.includes(data.role) ? 'not_submitted' : 'not_required' },
    lastLoginAt: new Date(),
  });
  res.status(201).json(await startSession(res, user, req));
}

// POST /api/auth/login  { identifier, password }
export async function login(req, res) {
  const { identifier, password } = req.data;
  const query = identifier.includes('@') ? { email: identifier.toLowerCase() } : { phone: identifier.replace(/^(\+?88)/, '') };
  const user = await User.findOne(query).select('+password +failedLogins +lockedUntil');
  const fail = () => new HttpError(401, 'Phone number, email or password is incorrect.');
  if (!user) throw fail();

  if (user.lockedUntil && user.lockedUntil > new Date()) {
    const mins = Math.ceil((user.lockedUntil - Date.now()) / 60_000);
    throw new HttpError(423, `Too many failed attempts. Try again in ${mins} minute${mins === 1 ? '' : 's'}, or sign in with a one-time code.`);
  }
  if (!(await bcrypt.compare(password, user.password))) {
    user.failedLogins = (user.failedLogins ?? 0) + 1;
    if (user.failedLogins >= LOGIN_LOCK.maxFailures) {
      user.lockedUntil = new Date(Date.now() + LOGIN_LOCK.minutes * 60_000);
      user.failedLogins = 0;
    }
    await user.save();
    throw fail();
  }
  if (user.status === 'suspended') throw new HttpError(403, 'This account is suspended. Contact an administrator.');

  user.failedLogins = 0;
  user.lockedUntil = undefined;
  user.lastLoginAt = new Date();
  await user.save();
  res.json(await startSession(res, user, req));
}

// POST /api/auth/login/otp  { channel, phone | email, code }
export async function loginWithOtp(req, res) {
  const user = await findByTarget(req.data);
  if (!user) throw new HttpError(404, 'No account uses this number or email.');
  await verifyOtp({ target: targetOf(req.data), purpose: 'login', code: req.data.code });
  if (user.status === 'suspended') throw new HttpError(403, 'This account is suspended. Contact an administrator.');
  if (req.data.channel === 'sms') user.phoneVerified = true;
  else user.emailVerified = true;
  user.lastLoginAt = new Date();
  await user.save();
  res.json(await startSession(res, user, req));
}

// POST /api/auth/password/reset  { channel, phone | email, code, password }
export async function resetPassword(req, res) {
  const user = await findByTarget(req.data);
  if (!user) throw new HttpError(400, 'This code has expired. Ask for a new one.', { code: ['Code expired'] });
  await verifyOtp({ target: targetOf(req.data), purpose: 'reset', code: req.data.code });
  user.password = await bcrypt.hash(req.data.password, 12);
  user.tokenVersion += 1;
  user.lockedUntil = undefined;
  await user.save();
  await revokeAllSessions(user._id);
  res.json({ ok: true });
}

// PATCH /api/auth/password  { currentPassword, newPassword }
export async function changePassword(req, res) {
  const user = await User.findById(req.user._id).select('+password +tokenVersion');
  if (!(await bcrypt.compare(req.data.currentPassword, user.password))) {
    throw new HttpError(400, 'Your current password is not correct.', { currentPassword: ['Incorrect password'] });
  }
  user.password = await bcrypt.hash(req.data.newPassword, 12);
  user.tokenVersion += 1;
  await user.save();
  await revokeAllSessions(user._id);
  // Keep this device signed in with a fresh session.
  res.json(await startSession(res, user, req));
}

export const refresh = async (req, res) => res.json(await rotateSession(req, res, (id) => User.findById(id).select('+tokenVersion')));

export async function logout(req, res) {
  await endSession(req, res);
  res.json({ ok: true });
}

export const me = (req, res) => res.json({ user: req.user });
