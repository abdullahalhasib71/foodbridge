/**
 * Feature 1.4 (Member 1): Event Pre-Registration
 */
import Event from '../models/Event.js';
import { toPoint } from '../models/shared.js';
import { HttpError, sameId } from '../services/http.js';
import { createDonation, present } from '../services/donation.service.js';

async function load(id) {
  const e = await Event.findById(id);
  if (!e) throw new HttpError(404, 'Event not found.');
  return e;
}

/** Hosts and admins see who signed up; everyone else sees counts only. */
function shape(e, user) {
  const j = e.toJSON();
  const isHost = Boolean(user) && (sameId(e.host, user) || user.role === 'admin');
  j.joined = Boolean(user) && e.volunteers.some((v) => sameId(v, user));
  j.isHost = isHost;
  j.volunteerCount = e.volunteers.length;
  if (!isHost) {
    delete j.volunteers;
    if (j.address) delete j.address.details;
  }
  return j;
}

const PEOPLE = [{ path: 'host', select: 'name orgName' }, { path: 'volunteers', select: 'name phone' }];
/** Works for both queries and documents. */
const populate = (q) => q.populate(PEOPLE);

// GET /api/events?scope=upcoming|mine|joined
export async function list(req, res) {
  const { scope } = req.data;
  const u = req.user;
  const since = new Date(Date.now() - 6 * 3_600_000);
  const filter = {
    upcoming: { status: 'upcoming', expectedEnd: { $gte: since } },
    mine: { host: u._id },
    joined: { volunteers: u._id },
  }[scope];
  const items = await populate(Event.find(filter).sort(scope === 'mine' ? { startsAt: -1 } : { startsAt: 1 }).limit(100));
  res.json({ items: items.map((e) => shape(e, u)) });
}

export async function getOne(req, res) {
  const e = await populate(Event.findById(req.params.id));
  if (!e) throw new HttpError(404, 'Event not found.');
  res.json({ event: shape(e, req.user) });
}

export async function create(req, res) {
  const e = await Event.create({ ...req.data, location: toPoint(req.data.location), host: req.user._id });
  await populate(e);
  res.status(201).json({ event: shape(e, req.user) });
}

export async function update(req, res) {
  const e = await load(req.params.id);
  if (!sameId(e.host, req.user) && req.user.role !== 'admin') throw new HttpError(403, 'Only the host can edit this event.');
  if (e.status !== 'upcoming') throw new HttpError(409, 'Only upcoming events can be edited.');
  if (req.data.volunteerSlots < e.volunteers.length) throw new HttpError(400, `${e.volunteers.length} volunteers have already signed up, so slots cannot be fewer.`, { volunteerSlots: ['Too few'] });
  Object.assign(e, { ...req.data, location: toPoint(req.data.location) });
  await e.save();
  await populate(e);
  res.json({ event: shape(e, req.user) });
}

// POST /api/events/:id/volunteers  (join)   DELETE (leave)
export async function join(req, res) {
  const e = await load(req.params.id);
  if (e.status !== 'upcoming' || e.expectedEnd < new Date()) throw new HttpError(409, 'This event is no longer open for sign-ups.');
  // Atomic: only adds the volunteer if the last slot (index slots-1) is still empty.
  const updated = await Event.findOneAndUpdate(
    { _id: e._id, status: 'upcoming', volunteerSlots: e.volunteerSlots, volunteers: { $ne: req.user._id }, [`volunteers.${e.volunteerSlots - 1}`]: { $exists: false } },
    { $push: { volunteers: req.user._id } },
    { new: true },
  );
  if (!updated) {
    if (e.volunteers.some((v) => sameId(v, req.user))) throw new HttpError(409, 'You have already signed up for this event.');
    throw new HttpError(409, 'All volunteer slots for this event are taken.');
  }
  await populate(updated);
  res.json({ event: shape(updated, req.user) });
}

export async function leave(req, res) {
  const e = await load(req.params.id);
  if (e.status !== 'upcoming') throw new HttpError(409, 'This event is no longer open.');
  const updated = await Event.findByIdAndUpdate(e._id, { $pull: { volunteers: req.user._id } }, { new: true });
  await populate(updated);
  res.json({ event: shape(updated, req.user) });
}

// POST /api/events/:id/convert  (multipart: payload JSON food fields + photos[])
export async function convert(req, res) {
  const e = await load(req.params.id);
  if (!sameId(e.host, req.user)) throw new HttpError(403, 'Only the event host can post its food.');
  if (e.status !== 'upcoming') throw new HttpError(409, 'Food from this event was already posted, or the event is closed.');
  if (Date.now() < e.startsAt.getTime()) throw new HttpError(409, 'You can post the food once the event has started.');

  const donation = await createDonation(
    { ...req.data, address: e.address.toObject(), location: e.location.toObject() },
    req.user,
    { photos: (req.files ?? []).map((f) => f.filename), event: e._id },
  );
  // Guard against a double click converting twice.
  const claimed = await Event.findOneAndUpdate({ _id: e._id, status: 'upcoming' }, { $set: { status: 'converted', donation: donation._id } });
  if (!claimed) {
    await donation.deleteOne();
    throw new HttpError(409, 'Food from this event was already posted.');
  }
  await donation.populate('donor', 'name orgName role phone');
  res.status(201).json({ donation: present(donation, req.user) });
}

export async function cancel(req, res) {
  const e = await load(req.params.id);
  if (!sameId(e.host, req.user) && req.user.role !== 'admin') throw new HttpError(403, 'Only the host can cancel this event.');
  if (e.status !== 'upcoming') throw new HttpError(409, 'Only upcoming events can be cancelled.');
  e.status = 'cancelled';
  await e.save();
  res.json({ ok: true });
}
