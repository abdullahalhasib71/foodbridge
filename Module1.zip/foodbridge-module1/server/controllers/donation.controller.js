/**
 * Feature 1.3 (Member 3): Surplus Food Donation Posting
 */
import path from 'node:path';
import Donation from '../models/Donation.js';
import { DIRS, removeFiles } from '../middleware/upload.js';
import { toPoint } from '../models/shared.js';
import { HttpError } from '../services/http.js';
import { canManage, checkFoodRules, createDonation, expireStale, present, transition } from '../services/donation.service.js';

const PEOPLE = 'name orgName role phone';
const withPeople = (q) => q.populate('donor', PEOPLE);

async function load(id) {
  const d = await withPeople(Donation.findById(id));
  if (!d) throw new HttpError(404, 'Donation not found.');
  return d;
}

// GET /api/donations?status=&category=&district=&q=&page=
export async function list(req, res) {
  await expireStale();
  const { status, category, district, q, page } = req.data;
  const filter = { status };
  if (category) filter.category = category;
  if (district) filter['address.district'] = district;
  if (q) filter.title = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
  const limit = 24;
  const [items, total] = await Promise.all([
    withPeople(Donation.find(filter).sort(status === 'available' ? { safeUntil: 1 } : { createdAt: -1 }).skip((page - 1) * limit).limit(limit)),
    Donation.countDocuments(filter),
  ]);
  res.json({ items: items.map((d) => present(d, req.user)), total, page, pages: Math.max(1, Math.ceil(total / limit)) });
}

// GET /api/donations/mine
export async function mine(req, res) {
  await expireStale();
  const items = await withPeople(Donation.find({ donor: req.user._id }).sort({ createdAt: -1 }).limit(100));
  res.json({ items: items.map((d) => present(d, req.user)) });
}

export async function getOne(req, res) {
  await expireStale();
  res.json({ donation: present(await load(req.params.id), req.user) });
}

// POST /api/donations  (multipart: payload JSON + photos[])
export async function create(req, res) {
  const photos = (req.files ?? []).map((f) => f.filename);
  const donation = await createDonation(req.data, req.user, { photos });
  await donation.populate('donor', PEOPLE);
  res.status(201).json({ donation: present(donation, req.user) });
}

// PATCH /api/donations/:id  (multipart: payload JSON incl. keepPhotos + new photos[])
export async function update(req, res) {
  await expireStale();
  const d = await load(req.params.id);
  if (!canManage(d, req.user)) throw new HttpError(403, 'Only the person who posted this food can edit it.');
  if (d.status !== 'available') throw new HttpError(409, `This donation is ${d.status.replace('_', ' ')} and can no longer be edited.`);

  const input = req.data;
  // Hotline posts keep their caller; the original poster's role decides the rules.
  const onBehalf = input.onBehalf ?? (d.onBehalf?.name ? { name: d.onBehalf.name, phone: d.onBehalf.phone } : undefined);
  const safeUntil = checkFoodRules({ ...input, onBehalf }, d.donor);

  const keep = d.photos.filter((p) => input.keepPhotos.includes(p));
  const added = (req.files ?? []).map((f) => f.filename);
  if (keep.length + added.length > 3) throw new HttpError(400, 'A donation can have at most 3 photos.');
  const dropped = d.photos.filter((p) => !keep.includes(p));

  const changed = ['title', 'category', 'servings', 'foodType', 'notes'].filter((k) => String(d[k] ?? '') !== String(input[k] ?? ''));
  Object.assign(d, {
    title: input.title,
    category: input.category,
    servings: input.servings,
    foodType: input.foodType,
    notes: input.notes,
    cookedAt: input.cookedAt,
    safeUntil,
    checklist: input.checklist,
    address: input.address,
    location: toPoint(input.location),
    photos: [...keep, ...added],
  });
  if (d.donor.role === 'operator') d.onBehalf = onBehalf;
  d.history.push({ action: 'edited', by: req.user._id, note: changed.length ? `Changed: ${changed.join(', ')}` : undefined });
  await d.save();
  await removeFiles(dropped.map((p) => path.join(DIRS.photos, p)));
  res.json({ donation: present(d, req.user) });
}

// POST /api/donations/:id/cancel  { reason? }
export async function cancel(req, res) {
  await expireStale();
  const d = await load(req.params.id);
  if (!canManage(d, req.user)) throw new HttpError(403, 'Only the person who posted this food can cancel it.');
  transition(d, 'cancelled', req.user._id, req.data.reason);
  d.cancelReason = req.data.reason;
  await d.save();
  res.json({ donation: present(d, req.user) });
}
