/**
 * Feature 1.2 (Member 2): admin review of identity documents,
 * plus account management (suspend, restore, create hotline operators).
 */
import { unlink } from 'node:fs/promises';
import path from 'node:path';
import bcrypt from 'bcryptjs';
import User from '../models/User.js';
import Donation from '../models/Donation.js';
import Event from '../models/Event.js';
import { DIRS } from '../middleware/upload.js';
import { env } from '../config/env.js';
import { HttpError, sameId } from '../services/http.js';
import { revokeAllSessions } from '../services/token.service.js';

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

export async function stats(_req, res) {
  const [roles, pending, donations, events] = await Promise.all([
    User.aggregate([{ $group: { _id: '$role', n: { $sum: 1 } } }]),
    User.countDocuments({ 'verification.status': 'pending' }),
    Donation.aggregate([{ $group: { _id: '$status', n: { $sum: 1 } } }]),
    Event.countDocuments({ status: 'upcoming' }),
  ]);
  const toMap = (rows) => Object.fromEntries(rows.map((r) => [r._id, r.n]));
  res.json({ roles: toMap(roles), pendingVerifications: pending, donations: toMap(donations), upcomingEvents: events });
}

// GET /api/admin/verifications?status=pending
export async function listVerifications(req, res) {
  const status = req.data.status ?? 'pending';
  const items = await User.find({ role: { $in: ['partner', 'volunteer'] }, 'verification.status': status })
    .sort({ 'verification.submittedAt': 1, createdAt: 1 })
    .limit(100);
  res.json({ items });
}

async function loadReviewable(id) {
  const user = await User.findById(id).select('+tokenVersion');
  if (!user || !['partner', 'volunteer'].includes(user.role)) throw new HttpError(404, 'Account not found.');
  if (user.verification.status !== 'pending') throw new HttpError(409, 'This account is not waiting for review.');
  return user;
}

// POST /api/admin/verifications/:id/approve
export async function approve(req, res) {
  const user = await loadReviewable(req.params.id);
  user.verification.status = 'approved';
  user.verification.reviewedAt = new Date();
  user.verification.reviewedBy = req.user._id;
  user.verification.note = req.data.note;
  if (env.deleteDocsOnApproval) {
    // Privacy: identity documents are not kept once they have served their purpose.
    for (const d of user.verification.documents) {
      if (d.purgedAt) continue;
      await unlink(path.join(DIRS.documents, d.storedName)).catch(() => {});
      d.purgedAt = new Date();
    }
  }
  await user.save();
  res.json({ user });
}

// POST /api/admin/verifications/:id/reject  { reason }
export async function reject(req, res) {
  const user = await loadReviewable(req.params.id);
  user.verification.status = 'rejected';
  user.verification.reviewedAt = new Date();
  user.verification.reviewedBy = req.user._id;
  user.verification.note = req.data.reason;
  await user.save();
  res.json({ user });
}

// GET /api/admin/users?role=&status=&q=
export async function listUsers(req, res) {
  const { role, status, q } = req.data;
  const filter = {};
  if (role) filter.role = role;
  if (status) filter.status = status;
  if (q) {
    const rx = new RegExp(escapeRegex(q), 'i');
    filter.$or = [{ name: rx }, { phone: rx }, { email: rx }, { orgName: rx }];
  }
  const items = await User.find(filter).sort({ createdAt: -1 }).limit(200);
  res.json({ items });
}

// PATCH /api/admin/users/:id/status  { status }
export async function setStatus(req, res) {
  const user = await User.findById(req.params.id).select('+tokenVersion');
  if (!user) throw new HttpError(404, 'Account not found.');
  if (user.role === 'admin' || sameId(user, req.user)) throw new HttpError(400, 'Administrator accounts cannot be suspended here.');
  user.status = req.data.status;
  if (user.status === 'suspended') {
    user.tokenVersion += 1; // signs them out immediately
    await revokeAllSessions(user._id);
  }
  await user.save();
  res.json({ user });
}

// POST /api/admin/operators  { name, phone, email?, password }
export async function createOperator(req, res) {
  const { password, ...data } = req.data;
  if (await User.exists({ phone: data.phone })) throw new HttpError(409, 'An account with this phone number already exists.', { phone: ['Already registered'] });
  const user = await User.create({
    ...data,
    role: 'operator',
    password: await bcrypt.hash(password, 12),
    phoneVerified: true,
    verification: { status: 'not_required' },
    createdBy: req.user._id,
  });
  res.status(201).json({ user });
}
