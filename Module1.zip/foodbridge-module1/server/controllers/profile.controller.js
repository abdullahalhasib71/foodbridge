/**
 * Feature 1.2 (Member 2): Profile and Identity Verification Management
 */
import { unlink } from 'node:fs/promises';
import path from 'node:path';
import User, { DOC_TYPES, NEEDS_VERIFICATION } from '../models/User.js';
import { toPoint } from '../models/shared.js';
import { DIRS, removeFiles } from '../middleware/upload.js';
import { HttpError, sameId } from '../services/http.js';
import { LOCATIONS } from '../services/locations.service.js';

const EDITABLE_STATUSES = ['not_submitted', 'rejected'];

export const getLocations = (_req, res) => {
  res.set('Cache-Control', 'public, max-age=86400');
  res.json({ divisions: LOCATIONS });
};

export const getProfile = (req, res) => res.json({ user: req.user });

// PATCH /api/profile
export async function updateProfile(req, res) {
  const { location, email, ...rest } = req.data;
  const u = req.user;
  if (email !== undefined && email !== u.email) {
    if (email && (await User.exists({ email, _id: { $ne: u._id } }))) throw new HttpError(409, 'This email address is already in use.', { email: ['Already in use'] });
    u.email = email || undefined;
    u.emailVerified = false;
  }
  if (rest.orgName !== undefined && u.role !== 'partner') delete rest.orgName;
  if (rest.capacity !== undefined && u.role !== 'partner') delete rest.capacity;
  Object.assign(u, rest);
  if (location) u.location = toPoint(location);
  await u.save();
  res.json({ user: u });
}

// POST /api/profile/documents  (multipart: type, documents[])
export async function uploadDocuments(req, res) {
  const u = req.user;
  const files = req.files ?? [];
  try {
    if (!NEEDS_VERIFICATION.includes(u.role)) throw new HttpError(400, 'Your account type does not need identity documents.');
    if (!EDITABLE_STATUSES.includes(u.verification.status)) {
      throw new HttpError(409, u.verification.status === 'pending' ? 'Your documents are being reviewed. You can change them if the review asks for changes.' : 'Your account is already verified.');
    }
    if (!files.length) throw new HttpError(400, 'Choose at least one file to upload.');
    const type = req.body.type;
    if (!DOC_TYPES[u.role].includes(type)) throw new HttpError(400, 'Choose what kind of document this is.', { type: ['Choose a document type'] });
    if (u.verification.documents.filter((d) => !d.purgedAt).length + files.length > 5) throw new HttpError(400, 'You can keep at most 5 documents. Remove one first.');
  } catch (err) {
    await removeFiles(files);
    throw err;
  }
  for (const f of files) {
    u.verification.documents.push({ type: req.body.type, originalName: f.originalname.slice(0, 120), storedName: f.filename, mimeType: f.mimetype, size: f.size });
  }
  await u.save();
  res.status(201).json({ user: u });
}

// DELETE /api/profile/documents/:docId
export async function deleteDocument(req, res) {
  const u = req.user;
  if (!EDITABLE_STATUSES.includes(u.verification.status)) throw new HttpError(409, 'Documents cannot be removed while they are under review.');
  const doc = u.verification.documents.id(req.params.docId);
  if (!doc) throw new HttpError(404, 'Document not found.');
  await unlink(path.join(DIRS.documents, doc.storedName)).catch(() => {});
  doc.deleteOne();
  await u.save();
  res.json({ user: u });
}

// POST /api/profile/verification/submit
export async function submitVerification(req, res) {
  const u = req.user;
  if (!NEEDS_VERIFICATION.includes(u.role)) throw new HttpError(400, 'Your account type does not need verification.');
  if (!EDITABLE_STATUSES.includes(u.verification.status)) throw new HttpError(409, 'Your verification has already been submitted.');
  const missing = [];
  if (!u.verification.documents.some((d) => !d.purgedAt)) missing.push('at least one document');
  if (!u.address?.upazila) missing.push('your address');
  if (!u.location) missing.push('your location on the map');
  if (u.role === 'partner' && !u.orgName) missing.push('your organization name');
  if (missing.length) throw new HttpError(400, `Before submitting, add ${missing.join(', ')}.`);
  u.verification.status = 'pending';
  u.verification.submittedAt = new Date();
  u.verification.note = undefined;
  await u.save();
  res.json({ user: u });
}

// GET /api/documents/:userId/:docId  (owner or admin only)
export async function downloadDocument(req, res) {
  if (!sameId(req.params.userId, req.user) && req.user.role !== 'admin') throw new HttpError(403, 'You cannot view this document.');
  const owner = sameId(req.params.userId, req.user) ? req.user : await User.findById(req.params.userId);
  const doc = owner?.verification?.documents.id(req.params.docId);
  if (!doc) throw new HttpError(404, 'Document not found.');
  if (doc.purgedAt) throw new HttpError(410, 'This document was deleted after the account was verified.');
  res.set({
    'Content-Type': doc.mimeType,
    'Content-Disposition': `inline; filename="${encodeURIComponent(doc.originalName)}"`,
    'Cache-Control': 'private, no-store',
    'X-Content-Type-Options': 'nosniff',
  });
  res.sendFile(path.join(DIRS.documents, doc.storedName), (err) => {
    if (err && !res.headersSent) res.status(404).json({ error: 'The file is missing on the server.' });
  });
}
