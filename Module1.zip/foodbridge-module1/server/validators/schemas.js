/** Request validation rules shared by the routes (zod). */
import { z } from 'zod';
import { CATEGORIES } from '../models/shared.js';
import { EVENT_TYPES } from '../models/Event.js';
import { isValidAddress } from '../services/locations.service.js';

export const phone = z
  .string()
  .trim()
  .transform((v) => v.replace(/[\s-]/g, '').replace(/^(\+?88)/, ''))
  .pipe(z.string().regex(/^01[3-9]\d{8}$/, 'Use an 11-digit Bangladeshi mobile number, for example 01712345678'));

export const email = z.string().trim().toLowerCase().email('Enter a valid email address');
export const optionalEmail = email.optional().or(z.literal('').transform(() => undefined));

export const password = z
  .string()
  .min(8, 'Use at least 8 characters')
  .max(72, 'Use at most 72 characters')
  .regex(/[A-Za-z]/, 'Include at least one letter')
  .regex(/\d/, 'Include at least one number');

export const otpCode = z.string().trim().regex(/^\d{6}$/, 'Enter the 6-digit code');
export const objectId = z.string().regex(/^[a-f\d]{24}$/i, 'Invalid id');

/** Bounding box of Bangladesh, so pins cannot be dropped in the sea or abroad. */
export const latLng = z.object({
  lat: z.number().min(20.5, 'Choose a place inside Bangladesh').max(26.7, 'Choose a place inside Bangladesh'),
  lng: z.number().min(88, 'Choose a place inside Bangladesh').max(92.7, 'Choose a place inside Bangladesh'),
});

export const address = z
  .object({
    division: z.string().trim().min(2),
    district: z.string().trim().min(2),
    upazila: z.string().trim().min(2, 'Choose an upazila or thana'),
    area: z.string().trim().min(2, 'Enter the area or neighbourhood').max(80),
    details: z.string().trim().max(200).optional(),
  })
  .refine(isValidAddress, { message: 'This upazila does not belong to the chosen district', path: ['upazila'] });

/** OTP can be delivered to a phone (SMS) or an email address. */
export const otpTarget = z.discriminatedUnion('channel', [
  z.object({ channel: z.literal('sms'), phone }),
  z.object({ channel: z.literal('email'), email }),
]);

export const food = z.object({
  title: z.string().trim().min(3, 'Describe the food in a few words').max(100),
  category: z.enum(CATEGORIES),
  servings: z.coerce.number().int().min(1, 'At least 1 serving').max(5000),
  foodType: z.enum(['veg', 'nonveg', 'mixed']).default('mixed'),
  notes: z.string().trim().max(500).optional(),
  cookedAt: z.coerce.date(),
  safeHours: z.coerce.number().min(0.5).max(72).optional(),
  checklist: z.array(z.enum(['covered', 'fresh', 'hygienic'])).default([]),
  onBehalf: z.object({ name: z.string().trim().min(2).max(80), phone }).optional(),
});

export const donationCreate = food.extend({ address, location: latLng });
export const donationUpdate = donationCreate.extend({ keepPhotos: z.array(z.string()).max(3).default([]) });

export const eventBody = z
  .object({
    name: z.string().trim().min(3, 'Give the event a name').max(100),
    type: z.enum(EVENT_TYPES),
    venue: z.string().trim().min(2, 'Enter the venue').max(120),
    address,
    location: latLng,
    startsAt: z.coerce.date(),
    expectedEnd: z.coerce.date(),
    guests: z.coerce.number().int().min(1).max(20000).optional(),
    expectedSurplus: z.coerce.number().int().min(1).max(5000).optional(),
    volunteerSlots: z.coerce.number().int().min(1).max(20).default(3),
    notes: z.string().trim().max(500).optional(),
  })
  .refine((v) => v.expectedEnd > v.startsAt, { path: ['expectedEnd'], message: 'End time must be after the start time' })
  .refine((v) => v.expectedEnd > new Date(), { path: ['expectedEnd'], message: 'The event must end in the future' })
  .refine((v) => v.expectedEnd - v.startsAt <= 24 * 3_600_000, { path: ['expectedEnd'], message: 'An event can last at most 24 hours' });
