import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import { DIRS } from './middleware/upload.js';
import { errorHandler, notFound } from './middleware/error.js';
import authRoutes from './routes/auth.routes.js';
import profileRoutes from './routes/profile.routes.js';
import adminRoutes from './routes/admin.routes.js';
import donationRoutes from './routes/donation.routes.js';
import eventRoutes from './routes/event.routes.js';

const app = express();

app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(
  helmet({
    crossOriginResourcePolicy: { policy: 'same-site' },
    contentSecurityPolicy: {
      directives: {
        // Map tiles from OpenStreetMap, photo previews (blob:) and Google Fonts are allowed; nothing else.
        'img-src': ["'self'", 'data:', 'blob:', 'https://*.tile.openstreetmap.org'],
        'style-src': ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
        'font-src': ["'self'", 'https://fonts.gstatic.com'],
        'frame-src': ["'self'", 'blob:'],
      },
    },
  }),
);
app.use(express.json({ limit: '100kb' }));
app.use(cookieParser());

app.get('/api/health', (_req, res) => res.json({ ok: true, module: 1 }));

app.use('/api/auth', authRoutes);
app.use('/api', profileRoutes); // /api/profile, /api/locations, /api/documents
app.use('/api/admin', adminRoutes);
app.use('/api/donations', donationRoutes);
app.use('/api/events', eventRoutes);
app.use('/api', notFound);

// Food photos are public. Identity documents are NOT served statically: see /api/documents.
app.use('/media/photos', express.static(DIRS.photos, { maxAge: '7d', fallthrough: false }));

// In production the Express server also serves the built React app.
const dist = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'client', 'dist');
app.use(express.static(dist));
app.get(/^\/(?!api|media).*/, (_req, res, next) => res.sendFile(path.join(dist, 'index.html'), (err) => err && next()));

app.use(errorHandler);

export default app;
