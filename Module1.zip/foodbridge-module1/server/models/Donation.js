/**
 * Feature 1.3 (Member 3)
 * A surplus food post. Module 1 handles available, cancelled and expired;
 * the other statuses are used by Module 2 (claim and delivery workflow).
 */
import mongoose, { Schema } from 'mongoose';
import { CATEGORIES, addressSchema, pointSchema } from './shared.js';

export const STATUSES = ['available', 'claimed', 'assigned', 'picked_up', 'delivered', 'expired', 'cancelled'];

const historySchema = new Schema(
  {
    action: { type: String, required: true }, // created, edited, cancelled, expired, ...
    by: { type: Schema.Types.ObjectId, ref: 'User' },
    note: String,
    at: { type: Date, default: Date.now },
  },
  { _id: false },
);

const donationSchema = new Schema(
  {
    donor: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    onBehalf: { name: String, phone: String }, // filled when a hotline operator posts for a caller
    event: { type: Schema.Types.ObjectId, ref: 'Event' },
    title: { type: String, required: true, trim: true, maxlength: 100 },
    category: { type: String, enum: CATEGORIES, required: true },
    servings: { type: Number, required: true, min: 1, max: 5000 },
    foodType: { type: String, enum: ['veg', 'nonveg', 'mixed'], default: 'mixed' },
    notes: { type: String, trim: true, maxlength: 500 },
    photos: [{ type: String }], // file names under /media/photos
    address: { type: addressSchema, required: true },
    location: { type: pointSchema, required: true },
    cookedAt: { type: Date, required: true },
    safeUntil: { type: Date, required: true },
    checklist: [String],
    status: { type: String, enum: STATUSES, default: 'available' },
    cancelReason: String,
    history: [historySchema],
  },
  { timestamps: true },
);

donationSchema.index({ location: '2dsphere' });
donationSchema.index({ status: 1, safeUntil: 1 });
donationSchema.index({ donor: 1, createdAt: -1 });

donationSchema.set('toJSON', { versionKey: false });

export default mongoose.models.Donation ?? mongoose.model('Donation', donationSchema);
