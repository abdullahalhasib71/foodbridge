/**
 * Feature 1.4 (Member 1)
 * An event (wedding, milad, iftar party...) registered before it ends,
 * so volunteers can sign up in advance and the host can post its food in one step.
 */
import mongoose, { Schema } from 'mongoose';
import { addressSchema, pointSchema } from './shared.js';

export const EVENT_TYPES = ['wedding', 'milad', 'iftar', 'corporate', 'other'];

const eventSchema = new Schema(
  {
    host: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    name: { type: String, required: true, trim: true, maxlength: 100 },
    type: { type: String, enum: EVENT_TYPES, default: 'wedding' },
    venue: { type: String, required: true, trim: true, maxlength: 120 },
    address: { type: addressSchema, required: true },
    location: { type: pointSchema, required: true },
    startsAt: { type: Date, required: true },
    expectedEnd: { type: Date, required: true },
    guests: { type: Number, min: 1, max: 20000 },
    expectedSurplus: { type: Number, min: 1, max: 5000 }, // servings the host expects to be left over
    volunteerSlots: { type: Number, min: 1, max: 20, default: 3 },
    volunteers: [{ type: Schema.Types.ObjectId, ref: 'User' }],
    notes: { type: String, trim: true, maxlength: 500 },
    status: { type: String, enum: ['upcoming', 'converted', 'cancelled', 'closed'], default: 'upcoming' },
    donation: { type: Schema.Types.ObjectId, ref: 'Donation' },
  },
  { timestamps: true },
);

eventSchema.index({ status: 1, expectedEnd: 1 });
eventSchema.index({ host: 1, startsAt: -1 });
eventSchema.set('toJSON', { versionKey: false });

export default mongoose.models.Event ?? mongoose.model('Event', eventSchema);
