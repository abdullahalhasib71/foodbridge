/**
 * Feature 1.1 (Member 1) and Feature 1.2 (Member 2)
 * A FoodBridge account. Holds login details, profile, address and identity verification.
 */
import mongoose, { Schema } from 'mongoose';
import { addressSchema, pointSchema } from './shared.js';

export const ROLES = ['donor', 'partner', 'volunteer', 'operator', 'admin'];
export const SELF_SERVICE_ROLES = ['donor', 'partner', 'volunteer'];
/** Roles that must upload documents and be approved by an admin before they can act. */
export const NEEDS_VERIFICATION = ['partner', 'volunteer'];

export const DOC_TYPES = {
  volunteer: ['nid', 'birth_certificate', 'student_id', 'passport'],
  partner: ['org_registration', 'trade_license', 'ngo_certificate', 'authorization_letter', 'nid'],
};

const documentSchema = new Schema(
  {
    type: { type: String, required: true },
    originalName: { type: String, required: true },
    storedName: { type: String, required: true }, // file name on disk, never sent to the browser
    mimeType: { type: String, required: true },
    size: { type: Number, required: true },
    uploadedAt: { type: Date, default: Date.now },
    purgedAt: Date, // set when the file is deleted from disk after approval
  },
  { _id: true },
);

const verificationSchema = new Schema(
  {
    status: { type: String, enum: ['not_required', 'not_submitted', 'pending', 'approved', 'rejected'], default: 'not_submitted' },
    documents: [documentSchema],
    submittedAt: Date,
    reviewedAt: Date,
    reviewedBy: { type: Schema.Types.ObjectId, ref: 'User' },
    note: { type: String, trim: true, maxlength: 500 }, // reason shown to the user on rejection
  },
  { _id: false },
);

const userSchema = new Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 80 },
    phone: { type: String, required: true, unique: true, trim: true },
    email: { type: String, trim: true, lowercase: true, unique: true, sparse: true },
    phoneVerified: { type: Boolean, default: false },
    emailVerified: { type: Boolean, default: false },
    password: { type: String, required: true, select: false },
    role: { type: String, enum: ROLES, required: true },
    status: { type: String, enum: ['active', 'suspended'], default: 'active' },
    orgName: { type: String, trim: true, maxlength: 120 },
    capacity: { type: Number, min: 1, max: 5000 }, // servings per day an organization can handle
    address: addressSchema,
    location: pointSchema,
    language: { type: String, enum: ['bn', 'en'], default: 'bn' },
    verification: { type: verificationSchema, default: () => ({}) },

    // Security bookkeeping
    tokenVersion: { type: Number, default: 0 }, // bump to invalidate every access token at once
    failedLogins: { type: Number, default: 0, select: false },
    lockedUntil: { type: Date, select: false },
    lastLoginAt: Date,
    createdBy: { type: Schema.Types.ObjectId, ref: 'User' }, // set when an admin creates the account
  },
  { timestamps: true },
);

userSchema.index({ location: '2dsphere' });
userSchema.index({ role: 1, 'verification.status': 1 });

userSchema.virtual('isVerified').get(function isVerified() {
  return this.status === 'active' && (!NEEDS_VERIFICATION.includes(this.role) || this.verification?.status === 'approved');
});

userSchema.set('toJSON', {
  virtuals: true,
  versionKey: false,
  transform: (_doc, ret) => {
    delete ret.id;
    if (ret.status === undefined) delete ret.isVerified; // partial (populated) user: the virtual would be misleading
    delete ret.password;
    delete ret.failedLogins;
    delete ret.lockedUntil;
    delete ret.tokenVersion;
    for (const d of ret.verification?.documents ?? []) delete d.storedName;
    return ret;
  },
});

export default mongoose.models.User ?? mongoose.model('User', userSchema);
