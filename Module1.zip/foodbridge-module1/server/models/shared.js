import { Schema } from 'mongoose';

export const pointSchema = new Schema(
  {
    type: { type: String, enum: ['Point'], default: 'Point' },
    coordinates: { type: [Number], required: true }, // [lng, lat]
  },
  { _id: false },
);

/** Bangladeshi address: Division > District > Upazila/Thana > Area, plus free-text details. */
export const addressSchema = new Schema(
  {
    division: { type: String, trim: true },
    district: { type: String, trim: true },
    upazila: { type: String, trim: true },
    area: { type: String, trim: true },
    details: { type: String, trim: true },
  },
  { _id: false },
);

export const CATEGORIES = ['rice_curry', 'biryani', 'bakery', 'sweets', 'fruits', 'dry', 'packaged'];

/**
 * Maximum hours food in each category may be offered after it was cooked or prepared.
 * Cooked meals get a short window because of Bangladesh's heat and humidity.
 */
export const SAFE_HOURS = { rice_curry: 4, biryani: 4, bakery: 12, sweets: 12, fruits: 24, dry: 48, packaged: 72 };
export const COOKED = ['rice_curry', 'biryani'];
export const CHECKLIST = ['covered', 'fresh', 'hygienic'];

export const toPoint = ({ lat, lng }) => ({ type: 'Point', coordinates: [lng, lat] });
