/**
 * Feature 1.1 (Member 1)
 * Long-lived refresh tokens, stored hashed. Every refresh rotates the token;
 * re-using an old one revokes the whole family (a sign the token was stolen).
 */
import mongoose, { Schema } from 'mongoose';

const refreshTokenSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    tokenHash: { type: String, required: true, unique: true },
    family: { type: String, required: true, index: true },
    expiresAt: { type: Date, required: true },
    replacedAt: Date,
    revokedAt: Date,
    userAgent: String,
  },
  { timestamps: true },
);

refreshTokenSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

export default mongoose.models.RefreshToken ?? mongoose.model('RefreshToken', refreshTokenSchema);
