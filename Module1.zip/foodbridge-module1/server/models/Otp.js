/**
 * Feature 1.1 (Member 1)
 * One-time codes for registration, passwordless login and password reset.
 * Only a hash of the code is stored; MongoDB removes expired codes automatically.
 */
import mongoose, { Schema } from 'mongoose';

const otpSchema = new Schema(
  {
    target: { type: String, required: true }, // phone number or email address
    channel: { type: String, enum: ['sms', 'email'], required: true },
    purpose: { type: String, enum: ['register', 'login', 'reset'], required: true },
    codeHash: { type: String, required: true },
    attempts: { type: Number, default: 0 },
    expiresAt: { type: Date, required: true },
  },
  { timestamps: true },
);

otpSchema.index({ target: 1, purpose: 1, createdAt: -1 });
otpSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 3600 }); // kept 1 h after expiry for rate limiting

export default mongoose.models.Otp ?? mongoose.model('Otp', otpSchema);
