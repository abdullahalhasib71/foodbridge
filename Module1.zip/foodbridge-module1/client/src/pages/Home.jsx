import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { api } from '../lib/api.js';
import { useAuth } from '../lib/auth.jsx';
import { useLang } from '../lib/i18n.jsx';
import { POSTERS } from '../lib/constants.js';
import CategoryChips from '../components/CategoryChips.jsx';
import DonationRow from '../components/DonationRow.jsx';
import Tiffin from '../components/Tiffin.jsx';

const Svg = ({ children }) => (
  <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{children}</svg>
);

function LiveBoard() {
  const { L, num } = useLang();
  const { data, isLoading } = useQuery({ queryKey: ['donations', 'board'], queryFn: () => api('/donations'), refetchInterval: 60_000 });
  const items = data?.items?.slice(0, 4) ?? [];
  return (
    <section aria-labelledby="board" className="glass relative rounded-[2rem] p-5 shadow-lift sm:p-7">
      <Tiffin className="absolute -top-[6.25rem] right-8 hidden w-[5.5rem] sm:block" />
      <div className="flex items-center justify-between gap-3">
        <h2 id="board" className="flex items-center gap-2 font-display text-lg font-semibold">
          <span className="relative flex h-2.5 w-2.5"><span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#2FB38A] opacity-60" /><span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-brand" /></span>
          {L('Waiting for pickup now', 'এখন সংগ্রহের অপেক্ষায়')}
        </h2>
        {data?.total > 0 && <span className="rounded-full bg-gradient-to-r from-brand to-teal px-3 py-1 text-xs font-semibold text-white">{L(`${num(data.total)} posts`, `${num(data.total)}টি পোস্ট`)}</span>}
      </div>
      {isLoading ? (
        <ul className="mt-4 space-y-3" aria-hidden="true">{[0, 1, 2].map((i) => <li key={i} className="h-20 animate-pulse rounded-2xl bg-paper" />)}</ul>
      ) : items.length ? (
        <ul className="mt-2 divide-y divide-line/70">{items.map((d, i) => <DonationRow key={d._id} d={d} index={i} animate />)}</ul>
      ) : (
        <p className="py-10 text-center text-muted">{L('No food is waiting right now.', 'এই মুহূর্তে কোনো খাবার অপেক্ষায় নেই।')}</p>
      )}
      <Link to="/food" className="mt-3 flex items-center justify-center rounded-2xl bg-paper py-2.5 text-sm font-semibold text-leaf-dark hover:bg-leaf-soft">{L('See all food', 'সব খাবার দেখুন')}</Link>
    </section>
  );
}

export default function Home() {
  const { L } = useLang();
  const { user } = useAuth();
  const shareTo = user ? (POSTERS.includes(user.role) ? '/food/new' : '/dashboard') : '/register?role=donor';

  const features = [
    ['from-ember to-berry', <><circle cx="12" cy="8" r="3.5" /><path d="M5 21a7 7 0 0 1 14 0" /></>, L('Accounts for every role', 'প্রত্যেক ভূমিকার জন্য অ্যাকাউন্ট'), L('Donors, organizations and volunteers sign up with a phone code. Passwords, code sign-in and password reset are built in.', 'দাতা, সংগঠন ও স্বেচ্ছাসেবক ফোন কোড দিয়ে যোগ দেন।'), user ? '/profile' : '/register'],
    ['from-sea to-indigo', <><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z" /><path d="M9 12l2 2 4-4" /></>, L('Verified helpers', 'যাচাইকৃত সাহায্যকারী'), L('Organizations and volunteers upload an ID or registration. An admin reviews it, and documents are deleted after approval.', 'সংগঠন ও স্বেচ্ছাসেবকরা পরিচয়পত্র আপলোড করেন, অ্যাডমিন যাচাই করেন।'), user ? '/profile' : '/register?role=volunteer'],
    ['from-brand to-teal', <><path d="M4 11h16v2a8 8 0 0 1-16 0z" /><path d="M9 7c0-1.5 1.5-2 1.5-3.5M14 7c0-1.5 1.5-2 1.5-3.5" /></>, L('Safe food posts', 'নিরাপদ খাবারের পোস্ট'), L('Photos, servings and a safety checklist. Cooked food can be offered for at most 4 hours, then the post closes on its own.', 'রান্না করা খাবার সর্বোচ্চ ৪ ঘণ্টা, তারপর পোস্ট নিজে বন্ধ হয়।'), shareTo],
    ['from-amber to-ember', <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M3 10h18M8 3v4M16 3v4" /></>, L('Events registered early', 'আগাম নিবন্ধিত অনুষ্ঠান'), L('Weddings and milads are registered before they end. Volunteers sign up, and the host posts the food in one step.', 'বিয়ে ও মিলাদ আগেই নিবন্ধিত, স্বেচ্ছাসেবকরা প্রস্তুত থাকেন।'), user ? '/events' : '/register?role=donor'],
  ];

  return (
    <>
      <section className="mesh">
        <div className="wrap grid items-center gap-12 pb-16 pt-14 lg:grid-cols-[1.1fr_1fr] lg:pb-24 lg:pt-20">
          <div>
            <h1 className="font-display text-4xl font-extrabold leading-[1.04] sm:text-6xl">{L('Tonight’s extra food can still be someone’s dinner.', 'আজ রাতের বাড়তি খাবার হতে পারে কারও রাতের খাবার।')}</h1>
            <p className="mt-6 max-w-xl text-lg text-muted">
              {L('FoodBridge connects community centers, restaurants and families who have surplus food with verified organizations and volunteers nearby, so it is delivered while it is still safe to eat.', 'খাদ্যসেতু বাড়তি খাবার থাকা কমিউনিটি সেন্টার, রেস্তোরাঁ ও পরিবারকে কাছের যাচাইকৃত সংগঠন ও স্বেচ্ছাসেবকদের সাথে যুক্ত করে।')}
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to={shareTo} className="btn-primary px-6 py-3 text-base">{L('Share extra food', 'বাড়তি খাবার দিন')}</Link>
              <Link to={user ? '/dashboard' : '/register?role=volunteer'} className="btn-secondary px-6 py-3 text-base">{user ? L('Go to dashboard', 'ড্যাশবোর্ডে যান') : L('Become a volunteer', 'স্বেচ্ছাসেবক হোন')}</Link>
            </div>
            <div className="mt-10">
              <p className="mb-3 text-sm font-medium text-muted">{L('Food people share on FoodBridge', 'যে খাবার ভাগ করা যায়')}</p>
              <CategoryChips />
            </div>
          </div>
          <LiveBoard />
        </div>
      </section>

      <section className="wrap relative -mt-6">
        <div className="rounded-[2rem] bg-surface px-6 py-12 shadow-soft sm:px-10">
          <h2 className="font-display text-2xl font-bold sm:text-3xl">{L('What this module does', 'এই মডিউলে যা আছে')}</h2>
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {features.map(([g, icon, title, body, to]) => (
              <Link key={title} to={to} className="group rounded-3xl p-1">
                <span className={`grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br text-white shadow-soft ${g}`}><Svg>{icon}</Svg></span>
                <h3 className="mt-4 font-display text-xl font-semibold group-hover:text-leaf">{title}</h3>
                <p className="mt-1 text-muted">{body}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="wrap pt-16">
        <div className="relative flex flex-col gap-6 overflow-hidden rounded-[2rem] bg-gradient-to-r from-saffron-soft via-rose-soft to-lilac-soft px-6 py-10 sm:px-10 md:flex-row md:items-center md:justify-between">
          <div className="max-w-2xl">
            <h2 className="font-display text-2xl font-bold sm:text-3xl">{L('Hosting a wedding or a milad?', 'বিয়ে বা মিলাদের আয়োজন করছেন?')}</h2>
            <p className="mt-2 text-muted">{L('Register the event before it starts. Volunteers sign up in advance, and when the guests leave you post the food with one tap.', 'অনুষ্ঠানের আগেই নিবন্ধন করুন। শেষে এক চাপে খাবার পোস্ট করুন।')}</p>
          </div>
          <Link to={user ? '/events/new' : '/register?role=donor'} className="btn-primary shrink-0 px-6 py-3">{L('Register an event', 'অনুষ্ঠান নিবন্ধন করুন')}</Link>
        </div>
      </section>
    </>
  );
}
