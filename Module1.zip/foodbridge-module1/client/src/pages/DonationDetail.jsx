/** Feature 1.3 (Member 3): one food post, with edit and cancel for the person who posted it. */
import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { api } from '../lib/api.js';
import { useLang } from '../lib/i18n.jsx';
import { useAction } from '../lib/hooks.js';
import { CATEGORIES, CHECKLIST, FOOD_TYPES, HUE, toLatLng } from '../lib/constants.js';
import FoodIcon from '../components/FoodIcon.jsx';
import FreshnessBar from '../components/FreshnessBar.jsx';
import Map from '../components/Map.jsx';
import { BackLink, ErrorState, Notice, Section, Spinner, StatusPill } from '../components/ui.jsx';

const ACTIONS = {
  created: ['Posted', 'পোস্ট করা হয়েছে'],
  edited: ['Edited', 'সম্পাদিত'],
  cancelled: ['Cancelled', 'বাতিল'],
  expired: ['Expired', 'মেয়াদ শেষ'],
  claimed: ['Claimed', 'দাবি করা হয়েছে'],
};

export default function DonationDetail() {
  const { id } = useParams();
  const { L, num, dateTime, time } = useLang();
  const [cancelling, setCancelling] = useState(false);
  const [reason, setReason] = useState('');
  const [photo, setPhoto] = useState(0);
  const { data, isLoading, error } = useQuery({ queryKey: ['donation', id], queryFn: () => api(`/donations/${id}`), refetchInterval: 60_000 });
  const cancel = useAction(`/donations/${id}/cancel`, { invalidate: [['donation', id], ['donations']], success: L('The post was cancelled.', 'পোস্ট বাতিল হয়েছে।'), onSuccess: () => setCancelling(false) });

  if (isLoading) return <div className="wrap"><Spinner /></div>;
  if (error) return <div className="wrap py-10"><ErrorState error={error} /></div>;
  const d = data.donation;
  const cat = CATEGORIES[d.category];
  const point = toLatLng(d.location);
  const open = d.status === 'available';

  return (
    <div className="wrap py-8">
      <BackLink to="/food">{L('All food', 'সব খাবার')}</BackLink>
      <div className="grid gap-8 lg:grid-cols-[1fr_22rem] lg:gap-x-10">
        <article className="space-y-8">
          <header>
            <div className="flex flex-wrap items-center gap-2">
              <StatusPill status={d.status} />
              <span className={`inline-flex items-center gap-1.5 rounded-full py-0.5 pl-1 pr-3 text-xs font-semibold ${HUE[cat.hue].tile}`}>
                <FoodIcon category={d.category} className="h-4 w-5" />{L(cat.en, cat.bn)}
              </span>
              <span className="text-sm text-muted">{L(FOOD_TYPES[d.foodType].en, FOOD_TYPES[d.foodType].bn)}</span>
              {d.event && <span className="text-sm text-muted">{L('from a registered event', 'নিবন্ধিত অনুষ্ঠান থেকে')}</span>}
            </div>
            <h1 className="mt-3 font-display text-3xl font-bold sm:text-5xl">{d.title}</h1>
            <p className="mt-3 text-lg">
              <span className="bg-gradient-to-r from-brand to-teal bg-clip-text font-display text-3xl font-bold text-transparent">{num(d.servings)}</span>{' '}
              {L('servings', 'জনের খাবার')} <span className="text-muted">{L('from', 'দাতা:')} {d.onBehalf?.name ?? d.donor?.orgName ?? d.donor?.name}</span>
            </p>
            {open && (
              <div className="mt-5 max-w-xl">
                <FreshnessBar cookedAt={d.cookedAt} safeUntil={d.safeUntil} size="lg" />
                <p className="hint">{L(`Cooked or prepared at ${time(d.cookedAt)}.`, `${time(d.cookedAt)} এ রান্না বা প্রস্তুত।`)}</p>
              </div>
            )}
            {d.status === 'expired' && <Notice tone="warn" className="mt-5">{L('The safe time window ended, so this post closed automatically.', 'নিরাপদ সময় শেষ হওয়ায় পোস্টটি স্বয়ংক্রিয়ভাবে বন্ধ হয়েছে।')}</Notice>}
            {d.status === 'cancelled' && <Notice tone="warn" className="mt-5">{L('This post was cancelled.', 'পোস্টটি বাতিল করা হয়েছে।')}{d.cancelReason ? ` ${d.cancelReason}` : ''}</Notice>}
          </header>

          {d.photoUrls.length > 0 && (
            <div>
              <img src={d.photoUrls[photo]} alt={d.title} className="max-h-[28rem] w-full rounded-3xl object-cover shadow-soft" />
              {d.photoUrls.length > 1 && (
                <div className="mt-3 flex gap-2">
                  {d.photoUrls.map((u, i) => (
                    <button key={u} onClick={() => setPhoto(i)} className={`h-16 w-16 overflow-hidden rounded-xl ring-2 ${i === photo ? 'ring-leaf' : 'ring-transparent'}`}><img src={u} alt="" className="h-full w-full object-cover" /></button>
                  ))}
                </div>
              )}
            </div>
          )}

          {d.notes && <p className="max-w-2xl whitespace-pre-line text-lg">{d.notes}</p>}

          {d.checklist?.length > 0 && (
            <div>
              <h2 className="font-display text-xl font-semibold">{L('Food safety check by the donor', 'দাতার খাদ্য নিরাপত্তা যাচাই')}</h2>
              <ul className="mt-2 space-y-1">
                {CHECKLIST.filter((c) => d.checklist.includes(c.id)).map((c) => <li key={c.id} className="flex gap-2"><span className="text-leaf">✓</span>{L(c.en, c.bn)}</li>)}
              </ul>
            </div>
          )}

          <div>
            <h2 className="font-display text-xl font-semibold">{L('Pickup point', 'সংগ্রহের স্থান')}</h2>
            <p className="mt-1">{[d.address?.details, d.address?.area, d.address?.upazila, d.address?.district].filter(Boolean).join(', ')}</p>
            {d.approximate && <p className="hint">{L('Shown within about 1 km. The exact point is shared with whoever collects the food.', 'প্রায় ১ কিমির মধ্যে দেখানো হচ্ছে।')}</p>}
            {point && <Map center={point} zoom={d.approximate ? 13 : 16} markers={[{ id: 'd', ...point, radius: d.approximate ? 30 : 12, color: cat.hex, tone: 'leaf' }]} className="mt-3 h-64" />}
          </div>

          <div>
            <h2 className="font-display text-xl font-semibold">{L('History', 'ইতিহাস')}</h2>
            <ol className="mt-3 space-y-3 border-l-2 border-line pl-5">
              {d.history.map((h, i) => (
                <li key={i} className="relative">
                  <span className="absolute -left-[1.62rem] top-1.5 h-3 w-3 rounded-full border-2 border-paper bg-leaf/80" />
                  <p className="font-medium">{L(...(ACTIONS[h.action] ?? [h.action, h.action]))}</p>
                  <p className="text-sm text-muted">{dateTime(h.at)}{h.note ? `. ${h.note}` : ''}</p>
                </li>
              ))}
            </ol>
          </div>
        </article>

        <aside className="lg:sticky lg:top-20 lg:self-start">
          <Section>
            <dl className="space-y-3 text-sm">
              <div className="flex justify-between gap-3"><dt className="text-muted">{L('Posted', 'পোস্ট')}</dt><dd className="text-right font-medium">{dateTime(d.createdAt)}</dd></div>
              <div className="flex justify-between gap-3"><dt className="text-muted">{L('Safe until', 'নিরাপদ পর্যন্ত')}</dt><dd className="text-right font-medium">{dateTime(d.safeUntil)}</dd></div>
              {d.onBehalf?.name && <div className="flex justify-between gap-3"><dt className="text-muted">{L('Posted by hotline for', 'হটলাইনের মাধ্যমে')}</dt><dd className="text-right font-medium">{d.onBehalf.name}{d.onBehalf.phone && <a className="block text-leaf" href={`tel:${d.onBehalf.phone}`}>{d.onBehalf.phone}</a>}</dd></div>}
            </dl>
            {d.canManage && open && (
              <div className="mt-5 space-y-3 border-t border-line pt-5">
                <Link to={`/food/${d._id}/edit`} className="btn-primary w-full">{L('Edit post', 'পোস্ট সম্পাদনা')}</Link>
                {!cancelling ? (
                  <button className="btn-danger w-full" onClick={() => setCancelling(true)}>{L('Cancel post', 'পোস্ট বাতিল')}</button>
                ) : (
                  <form className="space-y-2" onSubmit={(e) => { e.preventDefault(); cancel.mutate({ reason: reason || undefined }); }}>
                    <input className="input" value={reason} onChange={(e) => setReason(e.target.value)} placeholder={L('Reason (optional)', 'কারণ (ঐচ্ছিক)')} maxLength={200} />
                    <div className="flex gap-2">
                      <button className="btn-danger flex-1" disabled={cancel.isPending}>{L('Confirm cancel', 'বাতিল নিশ্চিত')}</button>
                      <button type="button" className="btn-ghost" onClick={() => setCancelling(false)}>{L('Keep', 'রাখুন')}</button>
                    </div>
                  </form>
                )}
              </div>
            )}
            {!d.canManage && open && <Notice className="mt-5">{L('Claiming and delivery are part of Module 2. Verified organizations and volunteers will collect food from here.', 'দাবি ও বিতরণ মডিউল ২ এর অংশ।')}</Notice>}
          </Section>
        </aside>
      </div>
    </div>
  );
}
