import { Link } from 'react-router-dom';
import { useLang } from '../lib/i18n.jsx';

export default function NotFound() {
  const { L } = useLang();
  return (
    <div className="wrap py-24">
      <h1 className="page-title">{L('This page does not exist.', 'এই পাতাটি নেই।')}</h1>
      <p className="mt-2 text-muted">{L('The link may be old or mistyped.', 'লিংকটি পুরনো বা ভুল হতে পারে।')}</p>
      <Link to="/" className="btn-primary mt-6">{L('Go to the home page', 'প্রথম পাতায় যান')}</Link>
    </div>
  );
}
