/**
 * Feature 1.1 (Member 1): sign up with OTP, sign in with password or OTP, reset password.
 */
import { useState } from 'react';
import { Link, useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { api } from '../lib/api.js';
import { useAuth } from '../lib/auth.jsx';
import { useLang } from '../lib/i18n.jsx';
import { useOtp } from '../lib/useOtp.js';
import OtpStep from '../components/OtpStep.jsx';
import PasswordField from '../components/PasswordField.jsx';
import Tiffin from '../components/Tiffin.jsx';
import { Field, Notice } from '../components/ui.jsx';

function AuthShell({ title, sub, children, wide = false }) {
  return (
    <div className="mesh">
      <div className={`wrap ${wide ? 'max-w-2xl' : 'max-w-xl'} py-12 sm:py-16`}>
        <div className="glass relative rounded-[2rem] p-6 shadow-lift sm:p-10">
          <Tiffin className="absolute -top-14 right-8 hidden w-16 sm:block" />
          <h1 className="page-title">{title}</h1>
          {sub && <p className="mt-2 text-muted">{sub}</p>}
          <div className="mt-8">{children}</div>
        </div>
      </div>
    </div>
  );
}

function useSubmit(fn) {
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e?.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await fn();
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  };
  return { submit, error, setError, busy, fe: (k) => error?.details?.[k]?.[0] };
}

function Tabs({ value, onChange, items }) {
  return (
    <div className="mb-6 inline-flex rounded-full bg-paper p-1 text-sm" role="tablist">
      {items.map(([v, label]) => (
        <button key={v} type="button" role="tab" aria-selected={value === v} onClick={() => onChange(v)} className={`rounded-full px-4 py-1.5 font-medium ${value === v ? 'bg-surface text-ink shadow-soft' : 'text-muted hover:text-ink'}`}>
          {label}
        </button>
      ))}
    </div>
  );
}

/** Phone or email input used by OTP sign-in and password reset. */
function Destination({ channel, setChannel, value, setValue, error }) {
  const { L } = useLang();
  return (
    <>
      <Tabs value={channel} onChange={(c) => { setChannel(c); setValue(''); }} items={[['sms', L('Mobile number', 'মোবাইল নম্বর')], ['email', L('Email', 'ইমেইল')]]} />
      <Field label={channel === 'sms' ? L('Mobile number', 'মোবাইল নম্বর') : L('Email address', 'ইমেইল ঠিকানা')} error={error}>
        <input className="input" inputMode={channel === 'sms' ? 'numeric' : 'email'} type={channel === 'sms' ? 'tel' : 'email'} autoComplete={channel === 'sms' ? 'tel' : 'email'} placeholder={channel === 'sms' ? '01712345678' : 'you@example.com'} value={value} onChange={(e) => setValue(e.target.value)} required />
      </Field>
    </>
  );
}

export function Login() {
  const { login, loginWithOtp } = useAuth();
  const { L } = useLang();
  const nav = useNavigate();
  const from = useLocation().state?.from ?? '/dashboard';
  const [mode, setMode] = useState('password');
  const [form, setForm] = useState({ identifier: '', password: '' });
  const [channel, setChannel] = useState('sms');
  const [dest, setDest] = useState('');
  const [code, setCode] = useState('');
  const otp = useOtp('login');
  const target = channel === 'sms' ? { channel, phone: dest } : { channel, email: dest };

  const pw = useSubmit(async () => {
    await login(form);
    nav(from, { replace: true });
  });
  const viaCode = useSubmit(async () => {
    await loginWithOtp({ ...target, code });
    nav(from, { replace: true });
  });
  const err = (mode === 'password' ? pw.error : viaCode.error ?? otp.error);

  return (
    <AuthShell title={L('Welcome back', 'আবার স্বাগতম')} sub={L('Sign in with your password or a one-time code.', 'পাসওয়ার্ড বা এককালীন কোড দিয়ে প্রবেশ করুন।')}>
      <Tabs value={mode} onChange={(m) => { setMode(m); otp.reset(); setCode(''); }} items={[['password', L('Password', 'পাসওয়ার্ড')], ['code', L('One-time code', 'এককালীন কোড')]]} />
      {err && !err.details?.code && <Notice tone="error" className="mb-5">{err.message}</Notice>}

      {mode === 'password' ? (
        <form onSubmit={pw.submit} className="space-y-5" noValidate>
          <Field label={L('Mobile number or email', 'মোবাইল নম্বর বা ইমেইল')} error={pw.fe('identifier')}>
            <input className="input" autoComplete="username" placeholder="01712345678" value={form.identifier} onChange={(e) => setForm({ ...form, identifier: e.target.value })} required />
          </Field>
          <PasswordField label={L('Password', 'পাসওয়ার্ড')} value={form.password} onChange={(password) => setForm({ ...form, password })} error={pw.fe('password')} />
          <div className="flex justify-end">
            <Link to="/forgot-password" className="text-sm font-medium text-leaf hover:underline">{L('Forgot password?', 'পাসওয়ার্ড ভুলে গেছেন?')}</Link>
          </div>
          <button className="btn-primary w-full py-3" disabled={pw.busy}>{pw.busy ? L('Signing in…', 'প্রবেশ করা হচ্ছে…') : L('Sign in', 'সাইন ইন')}</button>
        </form>
      ) : !otp.sent ? (
        <form onSubmit={(e) => { e.preventDefault(); otp.send(target); }} className="space-y-5" noValidate>
          <Destination channel={channel} setChannel={setChannel} value={dest} setValue={setDest} error={otp.error?.details?.phone?.[0] ?? otp.error?.details?.email?.[0]} />
          <button className="btn-primary w-full py-3" disabled={otp.busy || !dest}>{otp.busy ? L('Sending…', 'পাঠানো হচ্ছে…') : L('Send me a code', 'কোড পাঠান')}</button>
        </form>
      ) : (
        <form onSubmit={viaCode.submit} className="space-y-5">
          <OtpStep otp={otp} code={code} setCode={setCode} onResend={() => otp.send(target)} onBack={() => { otp.reset(); setCode(''); }} />
          {viaCode.fe('code') && <p className="error">{viaCode.error.message}</p>}
          <button className="btn-primary w-full py-3" disabled={viaCode.busy || code.length !== 6}>{L('Sign in', 'সাইন ইন')}</button>
        </form>
      )}

      <p className="mt-6 text-center text-sm text-muted">
        {L('New to FoodBridge?', 'নতুন?')} <Link to="/register" className="font-medium text-leaf hover:underline">{L('Create an account', 'অ্যাকাউন্ট খুলুন')}</Link>
      </p>
    </AuthShell>
  );
}

const ROLE_CARDS = [
  ['donor', 'from-ember to-berry', ['I have extra food', 'আমার বাড়তি খাবার আছে'], ['Community center, restaurant, caterer, family', 'কমিউনিটি সেন্টার, রেস্তোরাঁ, বাবুর্চি, পরিবার']],
  ['partner', 'from-sea to-indigo', ['We distribute food', 'আমরা খাবার বিতরণ করি'], ['NGO, orphanage, madrasa, shelter, club', 'এনজিও, এতিমখানা, মাদ্রাসা, আশ্রয়কেন্দ্র, ক্লাব']],
  ['volunteer', 'from-brand to-teal', ['I can carry food', 'আমি খাবার পৌঁছে দিতে পারি'], ['Students and anyone with a little time', 'ছাত্র ও যাদের একটু সময় আছে']],
];

export function Register() {
  const { register } = useAuth();
  const { L, lang } = useLang();
  const nav = useNavigate();
  const [params] = useSearchParams();
  const [form, setForm] = useState({
    role: ['donor', 'partner', 'volunteer'].includes(params.get('role')) ? params.get('role') : 'donor',
    name: '', orgName: '', phone: '', email: '', password: '', channel: 'sms',
  });
  const [code, setCode] = useState('');
  const otp = useOtp('register');
  const set = (k) => (e) => setForm({ ...form, [k]: e.target?.value ?? e });
  const target = form.channel === 'sms' ? { channel: 'sms', phone: form.phone } : { channel: 'email', email: form.email };

  const details = useSubmit(async () => {
    const problems = {};
    if (form.name.trim().length < 2) problems.name = [L('Enter your full name', 'পুরো নাম লিখুন')];
    if (form.role === 'partner' && form.orgName.trim().length < 2) problems.orgName = [L('Enter your organization’s name', 'সংগঠনের নাম লিখুন')];
    if (form.password.length < 8 || !/[A-Za-z]/.test(form.password) || !/\d/.test(form.password)) problems.password = [L('At least 8 characters, with a letter and a number', 'কমপক্ষে ৮ অক্ষর, বর্ণ ও সংখ্যাসহ')];
    if (form.channel === 'email' && !form.email) problems.email = [L('Enter an email to receive the code', 'কোড পেতে ইমেইল দিন')];
    if (Object.keys(problems).length) throw Object.assign(new Error(L('Please check the highlighted fields.', 'চিহ্নিত ঘরগুলো দেখুন।')), { details: problems });
    const failed = await otp.send(target);
    if (failed) throw failed;
  });
  const finish = useSubmit(async () => {
    const { orgName, email, ...rest } = form;
    await register({ ...rest, ...(email && { email }), ...(form.role === 'partner' && { orgName }), code, language: lang });
    nav('/profile?welcome=1', { replace: true });
  });
  const fe = (k) => details.fe(k) ?? finish.fe(k) ?? otp.error?.details?.[k]?.[0];
  const VISIBLE = ['name', 'orgName', 'phone', 'email', 'password', 'code'];
  const general = (e) => e && !Object.keys(e.details ?? {}).some((k) => VISIBLE.includes(k));
  const topError = general(finish.error) ? finish.error : general(details.error) ? details.error : null;

  return (
    <AuthShell wide title={otp.sent ? L('Check your phone', 'আপনার ফোন দেখুন') : L('Join FoodBridge', 'খাদ্যসেতুতে যোগ দিন')} sub={otp.sent ? null : L('Organizations and volunteers are checked by an administrator before they can collect food.', 'খাবার সংগ্রহের আগে সংগঠন ও স্বেচ্ছাসেবকদের অ্যাডমিন যাচাই করেন।')}>
      {topError && <Notice tone="error" className="mb-5">{topError.message}</Notice>}
      {!otp.sent ? (
        <form onSubmit={details.submit} className="space-y-5" noValidate>
          <fieldset>
            <legend className="label">{L('How will you use FoodBridge?', 'আপনি কীভাবে যুক্ত হবেন?')}</legend>
            <div className="grid gap-3 sm:grid-cols-3">
              {ROLE_CARDS.map(([value, grad, title, sub]) => (
                <label key={value} className={`relative cursor-pointer rounded-3xl border p-4 transition ${form.role === value ? 'border-transparent bg-gradient-to-br text-white shadow-lift ' + grad : 'border-line bg-surface hover:border-leaf/30'}`}>
                  <input type="radio" name="role" value={value} checked={form.role === value} onChange={set('role')} className="sr-only" />
                  <span className="block font-display text-lg font-semibold leading-tight">{L(...title)}</span>
                  <span className={`mt-1 block text-sm ${form.role === value ? 'text-white/85' : 'text-muted'}`}>{L(...sub)}</span>
                </label>
              ))}
            </div>
          </fieldset>
          {form.role === 'partner' && (
            <Field label={L('Organization name', 'সংগঠনের নাম')} error={fe('orgName')}>
              <input className="input" value={form.orgName} onChange={set('orgName')} required />
            </Field>
          )}
          <Field label={form.role === 'partner' ? L('Contact person', 'যোগাযোগকারী') : L('Your name or business name', 'আপনার নাম বা প্রতিষ্ঠানের নাম')} error={fe('name')}>
            <input className="input" autoComplete="name" value={form.name} onChange={set('name')} required />
          </Field>
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label={L('Mobile number', 'মোবাইল নম্বর')} error={fe('phone')}>
              <input className="input" type="tel" inputMode="numeric" autoComplete="tel" placeholder="01712345678" value={form.phone} onChange={set('phone')} required />
            </Field>
            <Field label={L('Email (optional)', 'ইমেইল (ঐচ্ছিক)')} error={fe('email')}>
              <input className="input" type="email" autoComplete="email" value={form.email} onChange={set('email')} />
            </Field>
          </div>
          <PasswordField label={L('Create a password', 'পাসওয়ার্ড তৈরি করুন')} value={form.password} onChange={set('password')} error={fe('password')} meter autoComplete="new-password" />
          <fieldset>
            <legend className="label">{L('Send my verification code by', 'যাচাই কোড পাঠান')}</legend>
            <div className="flex flex-wrap gap-4">
              {[['sms', L('SMS to my phone', 'ফোনে SMS')], ['email', L('Email', 'ইমেইলে')]].map(([v, label]) => (
                <label key={v} className="flex items-center gap-2">
                  <input type="radio" name="channel" value={v} checked={form.channel === v} onChange={set('channel')} className="accent-leaf" />
                  {label}
                </label>
              ))}
            </div>
          </fieldset>
          <button className="btn-primary w-full py-3" disabled={details.busy || otp.busy}>{details.busy ? L('Sending code…', 'কোড পাঠানো হচ্ছে…') : L('Continue', 'এগিয়ে যান')}</button>
        </form>
      ) : (
        <form onSubmit={finish.submit} className="space-y-5">
          <OtpStep otp={otp} code={code} setCode={setCode} onResend={() => otp.send(target)} onBack={() => { otp.reset(); setCode(''); finish.setError(null); }} />
          {finish.fe('code') && <p className="error">{finish.error.message}</p>}
          <button className="btn-primary w-full py-3" disabled={finish.busy || code.length !== 6}>{finish.busy ? L('Creating account…', 'অ্যাকাউন্ট তৈরি হচ্ছে…') : L('Verify and create account', 'যাচাই করে অ্যাকাউন্ট খুলুন')}</button>
        </form>
      )}
      <p className="mt-6 text-center text-sm text-muted">
        {L('Already registered?', 'আগেই নিবন্ধিত?')} <Link to="/login" className="font-medium text-leaf hover:underline">{L('Sign in', 'সাইন ইন')}</Link>
      </p>
    </AuthShell>
  );
}

export function ForgotPassword() {
  const { L } = useLang();
  const nav = useNavigate();
  const [channel, setChannel] = useState('sms');
  const [dest, setDest] = useState('');
  const [code, setCode] = useState('');
  const [password, setPassword] = useState('');
  const [done, setDone] = useState(false);
  const otp = useOtp('reset');
  const target = channel === 'sms' ? { channel, phone: dest } : { channel, email: dest };
  const reset = useSubmit(async () => {
    await api('/auth/password/reset', { method: 'POST', body: { ...target, code, password } });
    setDone(true);
  });

  return (
    <AuthShell title={L('Reset your password', 'পাসওয়ার্ড রিসেট')} sub={L('We will send a code to the phone or email on your account.', 'আপনার অ্যাকাউন্টের ফোন বা ইমেইলে কোড পাঠানো হবে।')}>
      {done ? (
        <div className="space-y-5">
          <Notice>{L('Your password was changed and you were signed out on other devices.', 'পাসওয়ার্ড পরিবর্তন হয়েছে, অন্যান্য ডিভাইস থেকে সাইন আউট করা হয়েছে।')}</Notice>
          <button className="btn-primary w-full py-3" onClick={() => nav('/login')}>{L('Sign in', 'সাইন ইন')}</button>
        </div>
      ) : !otp.sent ? (
        <form onSubmit={(e) => { e.preventDefault(); otp.send(target); }} className="space-y-5" noValidate>
          {otp.error && !otp.error.details?.phone && !otp.error.details?.email && <Notice tone="error">{otp.error.message}</Notice>}
          <Destination channel={channel} setChannel={setChannel} value={dest} setValue={setDest} error={otp.error?.details?.phone?.[0] ?? otp.error?.details?.email?.[0]} />
          <button className="btn-primary w-full py-3" disabled={otp.busy || !dest}>{L('Send code', 'কোড পাঠান')}</button>
        </form>
      ) : (
        <form onSubmit={reset.submit} className="space-y-5">
          {reset.error && !reset.fe('code') && !reset.fe('password') && <Notice tone="error">{reset.error.message}</Notice>}
          <OtpStep otp={otp} code={code} setCode={setCode} onResend={() => otp.send(target)} onBack={() => { otp.reset(); setCode(''); }} />
          {reset.fe('code') && <p className="error">{reset.error.message}</p>}
          <PasswordField label={L('New password', 'নতুন পাসওয়ার্ড')} value={password} onChange={setPassword} error={reset.fe('password')} meter autoComplete="new-password" />
          <button className="btn-primary w-full py-3" disabled={reset.busy || code.length !== 6 || !password}>{L('Change password', 'পাসওয়ার্ড পরিবর্তন')}</button>
        </form>
      )}
    </AuthShell>
  );
}
