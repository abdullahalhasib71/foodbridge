/**
 * Feature 1.3 (Member 3): create or edit a surplus food post.
 */
import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api, formData } from '../lib/api.js';
import { useAuth } from '../lib/auth.jsx';
import { useLang } from '../lib/i18n.jsx';
import { toLatLng } from '../lib/constants.js';
import AddressFields, { addressErrors, emptyAddress } from '../components/AddressFields.jsx';
import FoodFields, { foodFromDonation, foodPayload, newFood } from '../components/FoodFields.jsx';
import LocationPicker from '../components/LocationPicker.jsx';
import PhotoPicker from '../components/PhotoPicker.jsx';
import { useToast } from '../components/Toast.jsx';
import { BackLink, ErrorState, Field, Notice, Section, Spinner, fieldError } from '../components/ui.jsx';

function Editor({ existing }) {
  const { user } = useAuth();
  const { L } = useLang();
  const nav = useNavigate();
  const qc = useQueryClient();
  const toast = useToast();
  const operator = (existing?.donor?.role ?? user.role) === 'operator';
  const [form, setForm] = useState(() => ({
    ...(existing ? foodFromDonation(existing) : newFood()),
    address: existing ? { ...emptyAddress, ...existing.address } : user.address?.upazila ? { ...emptyAddress, ...user.address } : emptyAddress,
    location: existing ? toLatLng(existing.location) : toLatLng(user.location),
    onBehalf: existing?.onBehalf?.name ? existing.onBehalf : { name: '', phone: '' },
  }));
  const [files, setFiles] = useState([]);
  const [keep, setKeep] = useState(existing?.photos ?? []);
  const set = (patch) => setForm((f) => ({ ...f, ...patch }));

  const save = useMutation({
    mutationFn: () => {
      const payload = {
        ...foodPayload(form),
        address: form.address,
        location: form.location,
        ...(operator && { onBehalf: form.onBehalf }),
        ...(existing && { keepPhotos: keep }),
      };
      return api(existing ? `/donations/${existing._id}` : '/donations', { method: existing ? 'PATCH' : 'POST', body: formData(payload, files) });
    },
    onSuccess: ({ donation }) => {
      qc.invalidateQueries({ queryKey: ['donations'] });
      qc.setQueryData(['donation', donation._id], { donation });
      toast(existing ? L('Changes saved.', 'পরিবর্তন সংরক্ষিত।') : L('Your food is posted. Thank you!', 'খাবার পোস্ট হয়েছে। ধন্যবাদ!'));
      nav(`/food/${donation._id}`);
    },
  });

  return (
    <form className="space-y-6" onSubmit={(e) => { e.preventDefault(); save.mutate(); }}>
      {save.error && <Notice tone="error">{save.error.message}</Notice>}

      {operator && (
        <Section title={L('Caller', 'ফোনকারী')} sub={L('You are posting on behalf of someone who phoned the hotline.', 'আপনি হটলাইনে ফোনকারীর পক্ষে পোস্ট করছেন।')} className="bg-turmeric-soft/60">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label={L('Caller’s name or business', 'ফোনকারীর নাম')} error={fieldError(save, 'onBehalf')}>
              <input className="input" value={form.onBehalf.name} onChange={(e) => set({ onBehalf: { ...form.onBehalf, name: e.target.value } })} required />
            </Field>
            <Field label={L('Caller’s mobile number', 'ফোনকারীর মোবাইল')}>
              <input className="input" inputMode="numeric" value={form.onBehalf.phone} onChange={(e) => set({ onBehalf: { ...form.onBehalf, phone: e.target.value } })} required />
            </Field>
          </div>
        </Section>
      )}

      <Section title={L('The food', 'খাবার')}>
        <FoodFields form={form} set={set} mutation={save} />
        <div className="mt-6">
          <PhotoPicker
            existing={(existing?.photos ?? []).map((name, i) => ({ name, url: existing.photoUrls[i] }))}
            keep={keep}
            onKeepChange={setKeep}
            files={files}
            onFilesChange={setFiles}
            onError={(m) => toast(m, 'error')}
          />
        </div>
      </Section>

      <Section title={L('Where to collect it', 'কোথা থেকে নিতে হবে')} sub={L('Exact details are only shown to you until someone collects the food.', 'সঠিক ঠিকানা শুধু আপনি দেখবেন।')}>
        <div className="space-y-5">
          <AddressFields value={form.address} onChange={(address) => set({ address })} errors={addressErrors(save.error)} />
          <LocationPicker value={form.location} onChange={(location) => set({ location })} error={fieldError(save, 'location')} />
        </div>
      </Section>

      <div className="flex flex-wrap items-center gap-3">
        <button className="btn-primary px-10 py-3 text-base" disabled={save.isPending || !form.location}>
          {save.isPending ? L('Saving…', 'সংরক্ষণ হচ্ছে…') : existing ? L('Save changes', 'পরিবর্তন সংরক্ষণ') : L('Post food', 'খাবার পোস্ট করুন')}
        </button>
        {!form.location && <span className="hint">{L('Set the pickup point on the map to continue.', 'চালিয়ে যেতে মানচিত্রে স্থান দিন।')}</span>}
      </div>
    </form>
  );
}

export function NewDonation() {
  const { L } = useLang();
  const { user } = useAuth();
  return (
    <div className="pb-6">
      <div className="mesh"><div className="wrap max-w-3xl pb-8 pt-10">
        <BackLink to="/dashboard">{L('Dashboard', 'ড্যাশবোর্ড')}</BackLink>
        <h1 className="page-title">{user.role === 'operator' ? L('Post food for a caller', 'ফোনকারীর পক্ষে খাবার পোস্ট') : L('Share extra food', 'বাড়তি খাবার দিন')}</h1>
        <p className="mt-2 text-muted">{L('Cooked meals can be offered for at most 4 hours after cooking, so post as soon as you know food is left over.', 'রান্না করা খাবার রান্নার পর সর্বোচ্চ ৪ ঘণ্টা দেওয়া যায়, তাই দ্রুত পোস্ট করুন।')}</p>
      </div></div>
      <div className="wrap max-w-3xl"><Editor /></div>
    </div>
  );
}

export function EditDonation() {
  const { id } = useParams();
  const { L } = useLang();
  const { data, isLoading, error } = useQuery({ queryKey: ['donation', id], queryFn: () => api(`/donations/${id}`) });
  if (isLoading) return <div className="wrap"><Spinner /></div>;
  if (error) return <div className="wrap py-10"><ErrorState error={error} /></div>;
  const d = data.donation;
  return (
    <div className="pb-6">
      <div className="mesh"><div className="wrap max-w-3xl pb-8 pt-10">
        <BackLink to={`/food/${id}`}>{L('Back to the post', 'পোস্টে ফিরুন')}</BackLink>
        <h1 className="page-title">{L('Edit food post', 'খাবারের পোস্ট সম্পাদনা')}</h1>
      </div></div>
      <div className="wrap max-w-3xl">
        {!d.canManage ? <ErrorState error={{ message: L('Only the person who posted this food can edit it.', 'শুধু পোস্টকারী সম্পাদনা করতে পারেন।') }} />
          : d.status !== 'available' ? <Notice tone="warn">{L('This post can no longer be edited because it is not open any more.', 'পোস্টটি আর খোলা নেই, তাই সম্পাদনা করা যাবে না।')}</Notice>
          : <Editor existing={d} />}
      </div>
    </div>
  );
}
