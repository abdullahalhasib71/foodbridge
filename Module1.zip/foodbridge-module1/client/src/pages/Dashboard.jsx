/** Role-based home for signed-in users: verification status, quick actions, their posts and events. */
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { api } from '../lib/api.js';
import { useAuth } from '../lib/auth.jsx';
import { useLang } from '../lib/i18n.jsx';
import { NEEDS_VERIFICATION, POSTERS, ROLES, VERIFICATION } from '../lib/constants.js';
import DonationRow from '../components/DonationRow.jsx';
import { Badge, Empty, ErrorState, Notice, Section, Spinner } from '../components/ui.jsx';

function VerificationBanner({ user }) {
  const { L } = useLang();
  const v = user.verification.status;
  if (v === 'approved') return null;
  const msg = {
    not_submitted: L('Upload an identity document so an administrator can verify you. Until then you can browse, but not collect food or join events.', 'যাচাইয়ের জন্য পরিচয়পত্র আপলোড করুন।'),
    pending: L('Your documents are with an administrator. You will be able to act as soon as they approve.', 'আপনার কাগজপত্র পর্যালোচনায় আছে।'),
    rejected: L(`The reviewer asked for changes: ${user.verification.note ?? ''}`, `পর্যালোচকের মন্তব্য: ${user.verification.note ?? ''}`),
  }[v];
  return (
    <Notice tone={v === 'rejected' ? 'error' : 'warn'} className="flex flex-wrap items-center justify-between gap-3">
      <span>{msg}</span>
      {v !== 'pending' && <Link to="/profile" className="btn-secondary py-1.5 text-sm">{L('Go to verification', 'যাচাইয়ে যান')}</Link>}
    </Notice>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const { L, num, date } = useLang();
  const poster = POSTERS.includes(user.role);
  const mine = useQuery({ queryKey: ['donations', 'mine'], queryFn: () => api('/donations/mine'), enabled: poster });
  const events = useQuery({ queryKey: ['events', user.role === 'volunteer' ? 'joined' : 'mine'], queryFn: () => api(`/events?scope=${user.role === 'volunteer' ? 'joined' : 'mine'}`), enabled: poster || user.role === 'volunteer' });
  const r = ROLES[user.role];
  const v = VERIFICATION[user.verification?.status ?? 'not_required'];

  const items = mine.data?.items ?? [];
  const open = items.filter((d) => d.status === 'available');
  const past = items.filter((d) => d.status !== 'available');
  const servings = items.reduce((n, d) => n + d.servings, 0);

  const actions = {
    donor: [['/food/new', L('Share extra food', 'বাড়তি খাবার দিন'), true], ['/events/new', L('Register an event', 'অনুষ্ঠান নিবন্ধন')]],
    operator: [['/food/new', L('Post for a caller', 'ফোনকারীর পক্ষে পোস্ট'), true], ['/events/new', L('Register an event', 'অনুষ্ঠান নিবন্ধন')]],
    partner: [['/food', L('See food waiting', 'অপেক্ষমাণ খাবার দেখুন'), true], ['/profile', L('Profile and verification', 'প্রোফাইল ও যাচাই')]],
    volunteer: [['/events', L('Find an event to help', 'সাহায্যের জন্য অনুষ্ঠান খুঁজুন'), true], ['/food', L('See food waiting', 'অপেক্ষমাণ খাবার')]],
    admin: [['/admin', L('Review accounts', 'অ্যাকাউন্ট যাচাই'), true], ['/food/new', L('Post food', 'খাবার পোস্ট')]],
  }[user.role];

  const tiles = poster
    ? [[open.length, L('posts open now', 'খোলা পোস্ট'), 'from-brand to-teal'], [items.length, L('posts in total', 'মোট পোস্ট'), 'from-ember to-berry'], [servings, L('servings shared', 'জনের খাবার দেওয়া হয়েছে'), 'from-sea to-indigo']]
    : null;

  return (
    <div className="pb-6">
      <div className="mesh">
        <div className="wrap pb-8 pt-10">
          <div className="flex flex-wrap items-center gap-2 text-sm text-muted">
            <span>{L(r.en, r.bn)}{user.orgName ? `, ${user.orgName}` : ''}</span>
            {NEEDS_VERIFICATION.includes(user.role) && <Badge tone={v.tone}>{L(v.en, v.bn)}</Badge>}
          </div>
          <h1 className="page-title mt-1">{L(`Hi, ${user.name.split(' ')[0]}`, `স্বাগতম, ${user.name.split(' ')[0]}`)}</h1>
          <div className="mt-5 space-y-3">
            {NEEDS_VERIFICATION.includes(user.role) && <VerificationBanner user={user} />}
            {!user.location && user.role !== 'admin' && (
              <Notice>{L('Add your usual location so pickup points are filled in for you.', 'আপনার অবস্থান যোগ করুন।')} <Link to="/profile" className="font-semibold underline">{L('Set location', 'অবস্থান দিন')}</Link></Notice>
            )}
          </div>
          <div className="mt-6 flex flex-wrap gap-3">
            {actions.map(([to, label, primary]) => <Link key={to} to={to} className={primary ? 'btn-primary' : 'btn-secondary'}>{label}</Link>)}
          </div>
          {tiles && (
            <dl className="mt-8 grid grid-cols-3 gap-3 sm:gap-5">
              {tiles.map(([n, label, g]) => (
                <div key={label} className={`relative overflow-hidden rounded-3xl bg-gradient-to-br px-4 py-5 text-white shadow-soft sm:px-6 ${g}`}>
                  <span className="absolute -right-6 -top-6 h-20 w-20 rounded-full bg-white/15" aria-hidden="true" />
                  <dd className="font-display text-3xl font-bold sm:text-4xl">{num(n)}</dd>
                  <dt className="text-sm text-white/90">{label}</dt>
                </div>
              ))}
            </dl>
          )}
        </div>
      </div>

      <div className="wrap grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        {poster && (
          <Section title={L('Your food posts', 'আপনার খাবারের পোস্ট')}>
            {mine.isLoading ? <Spinner /> : mine.error ? <ErrorState error={mine.error} /> : items.length ? (
              <>
                {open.length > 0 && <ul className="divide-y divide-line/70">{open.map((d) => <DonationRow key={d._id} d={d} showStatus />)}</ul>}
                {past.length > 0 && (
                  <>
                    <h3 className="mb-1 mt-6 text-sm font-semibold uppercase tracking-wide text-muted">{L('Earlier', 'আগের')}</h3>
                    <ul className="divide-y divide-line/70">{past.slice(0, 10).map((d) => <DonationRow key={d._id} d={d} showStatus />)}</ul>
                  </>
                )}
              </>
            ) : (
              <Empty title={L('No posts yet', 'এখনো কোনো পোস্ট নেই')} action={<Link to="/food/new" className="btn-primary">{L('Share extra food', 'বাড়তি খাবার দিন')}</Link>}>
                {L('When food is left over, post it here and nearby helpers can collect it.', 'বাড়তি খাবার থাকলে এখানে পোস্ট করুন।')}
              </Empty>
            )}
          </Section>
        )}

        {(poster || user.role === 'volunteer') && (
          <Section title={user.role === 'volunteer' ? L('Events you are helping at', 'যে অনুষ্ঠানে সাহায্য করছেন') : L('Your events', 'আপনার অনুষ্ঠান')}>
            {events.isLoading ? <Spinner /> : events.data?.items.length ? (
              <ul className="space-y-3">
                {events.data.items.slice(0, 6).map((e) => (
                  <li key={e._id}>
                    <Link to={`/events/${e._id}`} className="block rounded-2xl bg-paper px-4 py-3 hover:bg-leaf-soft/50">
                      <span className="block font-medium">{e.name}</span>
                      <span className="block text-sm text-muted">{date(e.startsAt, { weekday: 'short', day: 'numeric', month: 'short' })}, {e.venue}</span>
                      <span className="block text-xs text-muted">{L(`${e.volunteerCount}/${e.volunteerSlots} volunteers`, `${num(e.volunteerCount)}/${num(e.volunteerSlots)} স্বেচ্ছাসেবক`)}</span>
                    </Link>
                  </li>
                ))}
              </ul>
            ) : <p className="text-muted">{user.role === 'volunteer' ? L('You have not signed up for any event yet.', 'এখনো কোনো অনুষ্ঠানে যুক্ত হননি।') : L('Register weddings and milads in advance so volunteers are ready.', 'বিয়ে ও মিলাদ আগেই নিবন্ধন করুন।')}</p>}
          </Section>
        )}
      </div>
    </div>
  );
}
