/**
 * Feature 1.4 (Member 1): Event Pre-Registration
 * Hosts register weddings, milads and iftar parties before they end; verified
 * volunteers sign up for a slot; the host posts the leftover food in one step.
 */
import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api, formData } from '../lib/api.js';
import { useAuth } from '../lib/auth.jsx';
import { useLang } from '../lib/i18n.jsx';
import { useAction } from '../lib/hooks.js';
import { EVENT_TYPES, POSTERS, toLatLng } from '../lib/constants.js';
import AddressFields, { addressErrors, emptyAddress } from '../components/AddressFields.jsx';
import FoodFields, { foodPayload, localInput, newFood } from '../components/FoodFields.jsx';
import LocationPicker from '../components/LocationPicker.jsx';
import PhotoPicker from '../components/PhotoPicker.jsx';
import { useToast } from '../components/Toast.jsx';
import { Badge, BackLink, Empty, ErrorState, Field, Notice, Section, Spinner, fieldError } from '../components/ui.jsx';

const TYPE_TONES = { wedding: 'from-ember to-berry', milad: 'from-brand to-teal', iftar: 'from-indigo to-sea', corporate: 'from-sea to-teal', other: 'from-amber to-ember' };
const STATUS = {
  upcoming: ['Upcoming', 'আসন্ন', 'ocean'],
  converted: ['Food posted', 'খাবার পোস্ট হয়েছে', 'leaf'],
  cancelled: ['Cancelled', 'বাতিল', 'muted'],
  closed: ['Closed', 'বন্ধ', 'muted'],
};

function DateTile({ e }) {
  const { L, date, time } = useLang();
  return (
    <div className={`rounded-2xl bg-gradient-to-br px-3 py-3 text-center text-white shadow-soft ${TYPE_TONES[e.type]}`}>
      <p className="font-display text-lg font-bold leading-tight">{date(e.startsAt, { weekday: 'short', day: 'numeric', month: 'short' })}</p>
      <p className="text-sm text-white/90">{time(e.startsAt)} - {time(e.expectedEnd)}</p>
    </div>
  );
}

function EventCard({ e }) {
  const { L, num } = useLang();
  const t = EVENT_TYPES[e.type];
  const s = STATUS[e.status];
  const free = e.volunteerSlots - e.volunteerCount;
  return (
    <li>
      <Link to={`/events/${e._id}`} className="grid gap-4 rounded-3xl p-3 transition-colors hover:bg-surface sm:grid-cols-[9rem_1fr_auto] sm:items-center">
        <DateTile e={e} />
        <div>
          <h3 className="font-display text-xl font-semibold">{e.name}</h3>
          <p className="text-muted">{L(t.en, t.bn)}, {e.venue}, {e.address?.area}</p>
          <p className="mt-1 text-sm text-muted">
            {e.guests ? L(`${e.guests} guests. `, `${num(e.guests)} অতিথি। `) : ''}
            {e.expectedSurplus ? L(`About ${e.expectedSurplus} servings expected to be left over.`, `প্রায় ${num(e.expectedSurplus)} জনের খাবার বাড়তি হতে পারে।`) : ''}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2 sm:flex-col sm:items-end">
          {e.status !== 'upcoming' ? <Badge tone={s[2]}>{L(s[0], s[1])}</Badge> : e.joined ? <Badge tone="leaf">{L('You are helping', 'আপনি যুক্ত')}</Badge> : (
            <Badge tone={free > 0 ? 'turmeric' : 'muted'}>{free > 0 ? L(`${free} volunteer slot${free === 1 ? '' : 's'} open`, `${num(free)}টি জায়গা খালি`) : L('Slots full', 'জায়গা পূর্ণ')}</Badge>
          )}
          {e.isHost && <Badge tone="lilac">{L('Your event', 'আপনার অনুষ্ঠান')}</Badge>}
        </div>
      </Link>
    </li>
  );
}

export function Events() {
  const { user } = useAuth();
  const { L } = useLang();
  const canHost = POSTERS.includes(user.role) && user.isVerified;
  const scopes = [['upcoming', L('Upcoming', 'আসন্ন')], ...(canHost ? [['mine', L('My events', 'আমার অনুষ্ঠান')]] : []), ...(user.role === 'volunteer' ? [['joined', L('Signed up', 'যুক্ত হয়েছি')]] : [])];
  const [scope, setScope] = useState('upcoming');
  const { data, isLoading, error } = useQuery({ queryKey: ['events', scope], queryFn: () => api(`/events?scope=${scope}`) });

  return (
    <div className="pb-6">
      <div className="mesh">
        <div className="wrap max-w-4xl pb-6 pt-10">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h1 className="page-title">{L('Events', 'অনুষ্ঠান')}</h1>
              <p className="mt-1 max-w-2xl text-muted">{L('Weddings, milads and iftar parties registered before they end, so volunteers are ready when the guests leave.', 'বিয়ে, মিলাদ ও ইফতার আগেই নিবন্ধিত, যাতে অতিথিরা গেলেই স্বেচ্ছাসেবকরা প্রস্তুত থাকেন।')}</p>
            </div>
            {canHost && <Link to="/events/new" className="btn-primary">{L('Register an event', 'অনুষ্ঠান নিবন্ধন')}</Link>}
          </div>
          {scopes.length > 1 && (
            <div className="mt-6 inline-flex rounded-full bg-surface p-1 text-sm shadow-soft" role="tablist">
              {scopes.map(([v, label]) => (
                <button key={v} role="tab" aria-selected={scope === v} onClick={() => setScope(v)} className={`rounded-full px-4 py-1.5 font-medium ${scope === v ? 'bg-gradient-to-r from-brand to-teal text-white' : 'text-muted hover:text-ink'}`}>{label}</button>
              ))}
            </div>
          )}
        </div>
      </div>
      <div className="wrap max-w-4xl">
        {user.role === 'volunteer' && !user.isVerified && <Notice tone="warn" className="mb-4">{L('You can sign up for events once your account is verified.', 'অ্যাকাউন্ট যাচাই হলে অনুষ্ঠানে যুক্ত হতে পারবেন।')} <Link to="/profile" className="font-semibold underline">{L('Verify now', 'এখন যাচাই করুন')}</Link></Notice>}
        {isLoading ? <Spinner /> : error ? <ErrorState error={error} /> : data.items.length ? (
          <ul className="space-y-2">{data.items.map((e) => <EventCard key={e._id} e={e} />)}</ul>
        ) : (
          <Empty title={L('No events here yet', 'এখনো কোনো অনুষ্ঠান নেই')}>{canHost ? L('Hosting a wedding or milad? Register it before it starts.', 'বিয়ে বা মিলাদ? শুরুর আগেই নিবন্ধন করুন।') : L('Registered events near you will appear here.', 'নিবন্ধিত অনুষ্ঠান এখানে দেখা যাবে।')}</Empty>
        )}
      </div>
    </div>
  );
}

const toForm = (e, user) => {
  const start = new Date(Date.now() + 86_400_000);
  start.setHours(19, 0, 0, 0);
  return e
    ? { name: e.name, type: e.type, venue: e.venue, guests: e.guests ?? '', expectedSurplus: e.expectedSurplus ?? '', volunteerSlots: e.volunteerSlots, notes: e.notes ?? '', startsAt: localInput(e.startsAt), expectedEnd: localInput(e.expectedEnd), address: { ...emptyAddress, ...e.address }, location: toLatLng(e.location) }
    : { name: '', type: 'wedding', venue: '', guests: '', expectedSurplus: '', volunteerSlots: 3, notes: '', startsAt: localInput(start), expectedEnd: localInput(new Date(start.getTime() + 4 * 3_600_000)), address: user.address?.upazila ? { ...emptyAddress, ...user.address } : emptyAddress, location: toLatLng(user.location) };
};

export function EventEditor() {
  const { id } = useParams();
  const { user } = useAuth();
  const { L } = useLang();
  const nav = useNavigate();
  const qc = useQueryClient();
  const existing = useQuery({ queryKey: ['event', id], queryFn: () => api(`/events/${id}`), enabled: Boolean(id) });
  if (id && existing.isLoading) return <div className="wrap"><Spinner /></div>;
  if (id && existing.error) return <div className="wrap py-10"><ErrorState error={existing.error} /></div>;
  return <EventForm key={id ?? 'new'} initial={toForm(existing.data?.event, user)} id={id} onSaved={(e) => { qc.invalidateQueries({ queryKey: ['events'] }); qc.setQueryData(['event', e._id], { event: e }); nav(`/events/${e._id}`); }} L={L} />;
}

function EventForm({ initial, id, onSaved, L }) {
  const [form, setForm] = useState(initial);
  const set = (patch) => setForm((f) => ({ ...f, ...patch }));
  const save = useMutation({
    mutationFn: () => {
      const { guests, expectedSurplus, notes, ...rest } = form;
      const body = { ...rest, startsAt: new Date(form.startsAt).toISOString(), expectedEnd: new Date(form.expectedEnd).toISOString(), volunteerSlots: Number(form.volunteerSlots), ...(guests && { guests: Number(guests) }), ...(expectedSurplus && { expectedSurplus: Number(expectedSurplus) }), ...(notes && { notes }) };
      return api(id ? `/events/${id}` : '/events', { method: id ? 'PUT' : 'POST', body });
    },
    onSuccess: ({ event }) => onSaved(event),
  });
  const fe = (k) => fieldError(save, k);

  return (
    <div className="pb-6">
      <div className="mesh"><div className="wrap max-w-3xl pb-8 pt-10">
        <BackLink to={id ? `/events/${id}` : '/events'}>{L('Events', 'অনুষ্ঠান')}</BackLink>
        <h1 className="page-title">{id ? L('Edit event', 'অনুষ্ঠান সম্পাদনা') : L('Register an upcoming event', 'আসন্ন অনুষ্ঠান নিবন্ধন')}</h1>
        <p className="mt-2 text-muted">{L('Volunteers can sign up in advance. When the guests leave, you post the leftover food in one step.', 'স্বেচ্ছাসেবকরা আগে থেকে যুক্ত হতে পারবেন। অতিথিরা গেলে এক ধাপে খাবার পোস্ট করুন।')}</p>
      </div></div>
      <form className="wrap max-w-3xl space-y-6" onSubmit={(e) => { e.preventDefault(); save.mutate(); }}>
        {save.error && <Notice tone="error">{save.error.message}</Notice>}
        <Section title={L('About the event', 'অনুষ্ঠানের তথ্য')}>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label={L('Event name', 'অনুষ্ঠানের নাম')} error={fe('name')}><input className="input" value={form.name} onChange={(e) => set({ name: e.target.value })} placeholder={L('e.g. Rahman family wedding reception', 'যেমন: রহমান পরিবারের বিয়ে')} required /></Field>
            <Field label={L('Type', 'ধরন')}>
              <select className="input" value={form.type} onChange={(e) => set({ type: e.target.value })}>{Object.entries(EVENT_TYPES).map(([k, t]) => <option key={k} value={k}>{L(t.en, t.bn)}</option>)}</select>
            </Field>
            <Field label={L('Venue', 'ভেন্যু')} error={fe('venue')}><input className="input" value={form.venue} onChange={(e) => set({ venue: e.target.value })} placeholder={L('e.g. Shapla Community Center', 'যেমন: শাপলা কমিউনিটি সেন্টার')} required /></Field>
            <Field label={L('Expected guests', 'আনুমানিক অতিথি')} error={fe('guests')}><input className="input" type="number" min="1" value={form.guests} onChange={(e) => set({ guests: e.target.value })} /></Field>
            <Field label={L('Starts', 'শুরু')} error={fe('startsAt')}><input className="input" type="datetime-local" value={form.startsAt} onChange={(e) => set({ startsAt: e.target.value })} required /></Field>
            <Field label={L('Expected to end', 'আনুমানিক শেষ')} error={fe('expectedEnd')}><input className="input" type="datetime-local" value={form.expectedEnd} onChange={(e) => set({ expectedEnd: e.target.value })} required /></Field>
            <Field label={L('Servings likely left over', 'আনুমানিক বাড়তি খাবার (জন)')} hint={L('A rough guess helps volunteers plan.', 'আনুমানিক সংখ্যা দিন।')}><input className="input" type="number" min="1" value={form.expectedSurplus} onChange={(e) => set({ expectedSurplus: e.target.value })} /></Field>
            <Field label={L('Volunteers needed', 'কতজন স্বেচ্ছাসেবক দরকার')} error={fe('volunteerSlots')}><input className="input" type="number" min="1" max="20" value={form.volunteerSlots} onChange={(e) => set({ volunteerSlots: e.target.value })} required /></Field>
            <Field label={L('Notes for volunteers (optional)', 'স্বেচ্ছাসেবকদের জন্য নোট (ঐচ্ছিক)')} className="sm:col-span-2"><textarea className="input min-h-20" maxLength={500} value={form.notes} onChange={(e) => set({ notes: e.target.value })} placeholder={L('e.g. Come to the kitchen gate behind the hall.', 'যেমন: হলের পেছনের রান্নাঘরের গেটে আসবেন।')} /></Field>
          </div>
        </Section>
        <Section title={L('Where', 'কোথায়')}>
          <div className="space-y-5">
            <AddressFields value={form.address} onChange={(address) => set({ address })} errors={addressErrors(save.error)} />
            <LocationPicker value={form.location} onChange={(location) => set({ location })} error={fe('location')} />
          </div>
        </Section>
        <button className="btn-primary px-10 py-3 text-base" disabled={save.isPending || !form.location}>{id ? L('Save changes', 'পরিবর্তন সংরক্ষণ') : L('Register event', 'নিবন্ধন করুন')}</button>
      </form>
    </div>
  );
}

function FoodIsReady({ e, onClose }) {
  const { L } = useLang();
  const nav = useNavigate();
  const qc = useQueryClient();
  const toast = useToast();
  const [form, setForm] = useState(() => ({ ...newFood(), title: `${e.name}: `, servings: e.expectedSurplus ?? '' }));
  const [files, setFiles] = useState([]);
  const set = (patch) => setForm((f) => ({ ...f, ...patch }));
  const post = useMutation({
    mutationFn: () => api(`/events/${e._id}/convert`, { method: 'POST', body: formData(foodPayload(form), files) }),
    onSuccess: ({ donation }) => {
      qc.invalidateQueries({ queryKey: ['events'] });
      qc.invalidateQueries({ queryKey: ['event', e._id] });
      qc.invalidateQueries({ queryKey: ['donations'] });
      toast(L('The food is posted from your event. Thank you!', 'অনুষ্ঠানের খাবার পোস্ট হয়েছে। ধন্যবাদ!'));
      nav(`/food/${donation._id}`);
    },
  });
  return (
    <form className="space-y-5" onSubmit={(ev) => { ev.preventDefault(); post.mutate(); }}>
      {post.error && <Notice tone="error">{post.error.message}</Notice>}
      <p className="text-muted">{L(`The pickup point is filled in from ${e.venue}.`, `সংগ্রহের স্থান ${e.venue} থেকে নেওয়া হয়েছে।`)}</p>
      <FoodFields form={form} set={set} mutation={post} />
      <PhotoPicker keep={[]} onKeepChange={() => {}} files={files} onFilesChange={setFiles} onError={(m) => toast(m, 'error')} />
      <div className="flex gap-3">
        <button className="btn-primary" disabled={post.isPending}>{L('Post the food', 'খাবার পোস্ট করুন')}</button>
        <button type="button" className="btn-ghost" onClick={onClose}>{L('Not yet', 'এখন না')}</button>
      </div>
    </form>
  );
}

export function EventDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const { L, num, dateTime } = useLang();
  const nav = useNavigate();
  const [posting, setPosting] = useState(false);
  const { data, isLoading, error } = useQuery({ queryKey: ['event', id], queryFn: () => api(`/events/${id}`) });
  const inv = [['event', id], ['events']];
  const join = useAction(`/events/${id}/volunteers`, { invalidate: inv, success: L('You are signed up. The host can now see your name and number.', 'আপনি যুক্ত হয়েছেন।') });
  const leave = useAction(`/events/${id}/volunteers`, { method: 'DELETE', invalidate: inv, success: L('You left this event.', 'আপনি অনুষ্ঠান থেকে সরে গেছেন।') });
  const cancel = useAction(`/events/${id}/cancel`, { invalidate: inv, success: L('Event cancelled.', 'অনুষ্ঠান বাতিল হয়েছে।'), onSuccess: () => nav('/events') });

  if (isLoading) return <div className="wrap"><Spinner /></div>;
  if (error) return <div className="wrap py-10"><ErrorState error={error} /></div>;
  const e = data.event;
  const t = EVENT_TYPES[e.type];
  const s = STATUS[e.status];
  const started = Date.now() >= new Date(e.startsAt).getTime();
  const free = e.volunteerSlots - e.volunteerCount;
  const upcoming = e.status === 'upcoming';

  return (
    <div className="wrap max-w-4xl py-8">
      <BackLink to="/events">{L('Events', 'অনুষ্ঠান')}</BackLink>
      <div className="grid gap-6 sm:grid-cols-[10rem_1fr]">
        <DateTile e={e} />
        <div>
          <div className="flex flex-wrap gap-2"><Badge tone={s[2]}>{L(s[0], s[1])}</Badge><span className="text-sm text-muted">{L(t.en, t.bn)}</span></div>
          <h1 className="mt-2 font-display text-3xl font-bold sm:text-4xl">{e.name}</h1>
          <p className="mt-1 text-muted">{L('Hosted by', 'আয়োজক:')} {e.host?.orgName ?? e.host?.name}</p>
        </div>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_20rem]">
        <Section>
          <dl className="grid gap-4 sm:grid-cols-2">
            <div><dt className="text-sm text-muted">{L('Venue', 'ভেন্যু')}</dt><dd className="font-medium">{e.venue}</dd><dd className="text-sm text-muted">{[e.address?.details, e.address?.area, e.address?.upazila, e.address?.district].filter(Boolean).join(', ')}</dd></div>
            <div><dt className="text-sm text-muted">{L('Time', 'সময়')}</dt><dd className="font-medium">{dateTime(e.startsAt)}</dd><dd className="text-sm text-muted">{L('ends around', 'শেষ প্রায়')} {dateTime(e.expectedEnd)}</dd></div>
            {e.guests && <div><dt className="text-sm text-muted">{L('Guests', 'অতিথি')}</dt><dd className="font-medium">{num(e.guests)}</dd></div>}
            {e.expectedSurplus && <div><dt className="text-sm text-muted">{L('Likely left over', 'আনুমানিক বাড়তি')}</dt><dd className="font-medium">{L(`about ${e.expectedSurplus} servings`, `প্রায় ${num(e.expectedSurplus)} জনের`)}</dd></div>}
          </dl>
          {e.notes && <p className="mt-5 rounded-2xl bg-paper p-4">{e.notes}</p>}
          {e.status === 'converted' && e.donation && <Link to={`/food/${e.donation}`} className="btn-secondary mt-5">{L('See the food post', 'খাবারের পোস্ট দেখুন')}</Link>}
        </Section>

        <Section title={L('Volunteers', 'স্বেচ্ছাসেবক')} sub={L(`${e.volunteerCount} of ${e.volunteerSlots} slots taken`, `${num(e.volunteerSlots)}টির মধ্যে ${num(e.volunteerCount)}টি পূর্ণ`)}>
          <div className="mb-4 flex gap-1.5" aria-hidden="true">
            {Array.from({ length: e.volunteerSlots }, (_, i) => <span key={i} className={`h-2.5 flex-1 rounded-full ${i < e.volunteerCount ? 'bg-gradient-to-r from-brand to-teal' : 'bg-line'}`} />)}
          </div>
          {e.isHost && (e.volunteers?.length ? (
            <ul className="space-y-2">{e.volunteers.map((v) => <li key={v._id} className="flex justify-between text-sm"><span className="font-medium">{v.name}</span><a className="text-leaf" href={`tel:${v.phone}`}>{v.phone}</a></li>)}</ul>
          ) : <p className="text-sm text-muted">{L('No one has signed up yet.', 'এখনো কেউ যুক্ত হননি।')}</p>)}
          {user.role === 'volunteer' && upcoming && (
            !user.isVerified ? <Notice tone="warn">{L('Verify your account to sign up.', 'যুক্ত হতে অ্যাকাউন্ট যাচাই করুন।')}</Notice>
              : e.joined ? <button className="btn-secondary w-full" onClick={() => leave.mutate()} disabled={leave.isPending}>{L('Leave this event', 'অনুষ্ঠান থেকে সরে যান')}</button>
              : <button className="btn-primary w-full" onClick={() => join.mutate()} disabled={join.isPending || free <= 0}>{free > 0 ? L('I will help', 'আমি সাহায্য করব') : L('All slots are taken', 'সব জায়গা পূর্ণ')}</button>
          )}
        </Section>
      </div>

      {e.isHost && upcoming && (
        <Section className="mt-6" title={L('When the guests leave', 'অতিথিরা চলে গেলে')} sub={started ? L('Post the leftover food. The venue and address are filled in for you.', 'বাড়তি খাবার পোস্ট করুন। ঠিকানা আগেই বসানো আছে।') : L('The "Food is ready" button unlocks once the event starts.', 'অনুষ্ঠান শুরু হলে বোতামটি চালু হবে।')}
          action={!posting && (
            <div className="flex flex-wrap gap-2">
              <Link to={`/events/${e._id}/edit`} className="btn-secondary py-2 text-sm">{L('Edit', 'সম্পাদনা')}</Link>
              <button className="btn-ghost py-2 text-sm text-chili-dark" onClick={() => confirm(L('Cancel this event?', 'অনুষ্ঠান বাতিল করবেন?')) && cancel.mutate()}>{L('Cancel event', 'বাতিল')}</button>
            </div>
          )}>
          {posting ? <FoodIsReady e={e} onClose={() => setPosting(false)} /> : <button className="btn-primary px-8 py-3" disabled={!started} onClick={() => setPosting(true)}>{L('Food is ready', 'খাবার প্রস্তুত')}</button>}
        </Section>
      )}
    </div>
  );
}
