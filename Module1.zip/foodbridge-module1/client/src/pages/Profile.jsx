/**
 * Feature 1.2 (Member 2): Profile and Identity Verification Management
 */
import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useMutation } from '@tanstack/react-query';
import { api, openDocument } from '../lib/api.js';
import { useAuth } from '../lib/auth.jsx';
import { useLang } from '../lib/i18n.jsx';
import { DOC_TYPES, DOCS_FOR_ROLE, NEEDS_VERIFICATION, ROLES, VERIFICATION, toLatLng } from '../lib/constants.js';
import AddressFields, { addressErrors, emptyAddress } from '../components/AddressFields.jsx';
import LocationPicker from '../components/LocationPicker.jsx';
import PasswordField from '../components/PasswordField.jsx';
import { useToast } from '../components/Toast.jsx';
import { Badge, Field, Notice, Section, fieldError } from '../components/ui.jsx';

const fmtSize = (b) => (b > 1_048_576 ? `${(b / 1_048_576).toFixed(1)} MB` : `${Math.ceil(b / 1024)} KB`);

function Stepper({ user }) {
  const { L } = useLang();
  const v = user.verification;
  const steps = [
    [L('Profile and location', 'প্রোফাইল ও অবস্থান'), Boolean(user.address?.upazila && user.location)],
    [L('Upload documents', 'কাগজপত্র আপলোড'), v.documents.length > 0],
    [L('Admin review', 'অ্যাডমিন পর্যালোচনা'), ['pending', 'approved'].includes(v.status)],
    [L('Verified', 'যাচাইকৃত'), v.status === 'approved'],
  ];
  return (
    <ol className="grid grid-cols-2 gap-3 sm:grid-cols-4">
      {steps.map(([label, done], i) => (
        <li key={label} className={`rounded-2xl px-4 py-3 ${done ? 'bg-leaf-soft text-leaf-dark' : 'bg-paper text-muted'}`}>
          <span className={`mb-1 grid h-7 w-7 place-items-center rounded-full text-sm font-bold ${done ? 'bg-gradient-to-br from-brand to-teal text-white' : 'bg-surface'}`}>{done ? '✓' : i + 1}</span>
          <span className="text-sm font-medium">{label}</span>
        </li>
      ))}
    </ol>
  );
}

function Verification() {
  const { user, setUser } = useAuth();
  const { L, date } = useLang();
  const toast = useToast();
  const v = user.verification;
  const types = DOCS_FOR_ROLE[user.role];
  const [type, setType] = useState(types[0]);
  const [files, setFiles] = useState([]);
  const [inputKey, setInputKey] = useState(0);
  const editable = ['not_submitted', 'rejected'].includes(v.status);
  const onDone = ({ user: u }) => setUser(u);

  const upload = useMutation({
    mutationFn: () => {
      const fd = new FormData();
      fd.append('type', type);
      files.forEach((f) => fd.append('documents', f));
      return api('/profile/documents', { method: 'POST', body: fd });
    },
    onSuccess: (r) => { onDone(r); setFiles([]); setInputKey((k) => k + 1); toast(L('Document uploaded.', 'কাগজ আপলোড হয়েছে।')); },
    onError: (e) => toast(e.message, 'error'),
  });
  const remove = useMutation({ mutationFn: (id) => api(`/profile/documents/${id}`, { method: 'DELETE' }), onSuccess: onDone, onError: (e) => toast(e.message, 'error') });
  const submit = useMutation({
    mutationFn: () => api('/profile/verification/submit', { method: 'POST' }),
    onSuccess: (r) => { onDone(r); toast(L('Sent for review. An administrator will check your documents.', 'পর্যালোচনার জন্য পাঠানো হয়েছে।')); },
    onError: (e) => toast(e.message, 'error'),
  });
  const s = VERIFICATION[v.status];

  return (
    <Section
      title={L('Identity verification', 'পরিচয় যাচাই')}
      sub={user.role === 'partner'
        ? L('Upload your organization’s registration or an NGO certificate. An admin checks it before you can claim food.', 'সংগঠনের নিবন্ধন বা এনজিও সনদ আপলোড করুন।')
        : L('Upload a photo or scan of your NID, birth certificate or student ID. An admin checks it before you can carry food.', 'জাতীয় পরিচয়পত্র, জন্ম নিবন্ধন বা ছাত্র পরিচয়পত্রের ছবি আপলোড করুন।')}
      action={<Badge tone={s.tone}>{L(s.en, s.bn)}</Badge>}
    >
      <Stepper user={user} />

      <div className="mt-5 space-y-3">
        {v.status === 'rejected' && v.note && <Notice tone="error"><strong>{L('The reviewer asked for changes:', 'পর্যালোচকের মন্তব্য:')}</strong> {v.note}</Notice>}
        {v.status === 'pending' && <Notice tone="warn">{L(`Submitted on ${date(v.submittedAt, { day: 'numeric', month: 'long' })}. You will be able to act as soon as an admin approves your account.`, 'জমা দেওয়া হয়েছে। অনুমোদনের অপেক্ষায়।')}</Notice>}
        {v.status === 'approved' && <Notice>{L('Your account is verified. For your privacy, uploaded documents were deleted after the review.', 'আপনার অ্যাকাউন্ট যাচাইকৃত। গোপনীয়তার জন্য কাগজপত্র মুছে ফেলা হয়েছে।')}</Notice>}
      </div>

      {v.documents.length > 0 && (
        <ul className="mt-5 divide-y divide-line/70 rounded-2xl border border-line/70">
          {v.documents.map((d) => (
            <li key={d._id} className="flex flex-wrap items-center justify-between gap-3 px-4 py-3">
              <span className="flex items-center gap-3">
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-ocean-soft text-xs font-bold text-ocean-dark">{d.mimeType === 'application/pdf' ? 'PDF' : 'IMG'}</span>
                <span>
                  <span className="block font-medium">{L(DOC_TYPES[d.type]?.en ?? d.type, DOC_TYPES[d.type]?.bn)}</span>
                  <span className="block text-xs text-muted">{d.originalName}, {fmtSize(d.size)}{d.purgedAt ? L(', deleted after approval', ', অনুমোদনের পর মুছে ফেলা') : ''}</span>
                </span>
              </span>
              {!d.purgedAt && (
                <span className="flex gap-2">
                  <button type="button" className="btn-ghost py-1 text-sm" onClick={() => openDocument(user._id, d._id).catch((e) => toast(e.message, 'error'))}>{L('View', 'দেখুন')}</button>
                  {editable && <button type="button" className="btn-ghost py-1 text-sm text-chili-dark" onClick={() => remove.mutate(d._id)}>{L('Remove', 'সরান')}</button>}
                </span>
              )}
            </li>
          ))}
        </ul>
      )}

      {editable && (
        <form className="mt-5 grid gap-4 rounded-2xl bg-paper p-4 sm:grid-cols-[1fr_1fr_auto] sm:items-end" onSubmit={(e) => { e.preventDefault(); upload.mutate(); }}>
          <Field label={L('Document type', 'কাগজের ধরন')}>
            <select className="input" value={type} onChange={(e) => setType(e.target.value)}>
              {types.map((t) => <option key={t} value={t}>{L(DOC_TYPES[t].en, DOC_TYPES[t].bn)}</option>)}
            </select>
          </Field>
          <Field label={L('File (JPG, PNG or PDF, up to 5 MB)', 'ফাইল (JPG, PNG বা PDF, সর্বোচ্চ ৫ MB)')}>
            <input key={inputKey} className="input py-2 text-sm file:mr-3 file:rounded-full file:border-0 file:bg-leaf-soft file:px-3 file:py-1 file:text-leaf-dark" type="file" accept="image/jpeg,image/png,application/pdf" multiple onChange={(e) => setFiles([...e.target.files].slice(0, 3))} />
          </Field>
          <button className="btn-secondary" disabled={!files.length || upload.isPending}>{upload.isPending ? L('Uploading…', 'আপলোড হচ্ছে…') : L('Upload', 'আপলোড')}</button>
        </form>
      )}

      {editable && (
        <button className="btn-primary mt-5" disabled={submit.isPending || !v.documents.length} onClick={() => submit.mutate()}>
          {v.status === 'rejected' ? L('Send again for review', 'আবার পর্যালোচনায় পাঠান') : L('Submit for verification', 'যাচাইয়ের জন্য জমা দিন')}
        </button>
      )}
    </Section>
  );
}

function Details() {
  const { user, setUser } = useAuth();
  const { L } = useLang();
  const toast = useToast();
  const [form, setForm] = useState({
    name: user.name,
    email: user.email ?? '',
    orgName: user.orgName ?? '',
    capacity: user.capacity ?? '',
    address: { ...emptyAddress, ...user.address },
    location: toLatLng(user.location),
  });
  const set = (patch) => setForm((f) => ({ ...f, ...patch }));
  const partner = user.role === 'partner';
  const save = useMutation({
    mutationFn: () =>
      api('/profile', {
        method: 'PATCH',
        body: {
          name: form.name,
          email: form.email,
          ...(partner && { orgName: form.orgName, ...(form.capacity && { capacity: Number(form.capacity) }) }),
          ...(form.address.upazila && form.address.area && { address: form.address }),
          ...(form.location && { location: form.location }),
        },
      }),
    onSuccess: ({ user: u }) => { setUser(u); toast(L('Profile saved.', 'প্রোফাইল সংরক্ষিত।')); },
    onError: (e) => toast(e.message, 'error'),
  });

  return (
    <Section title={L('Details and location', 'তথ্য ও অবস্থান')} sub={user.role === 'donor' ? L('Your location pre-fills the pickup point when you share food.', 'খাবার দেওয়ার সময় সংগ্রহের স্থান আগেই বসে যাবে।') : L('Your usual location helps match you with food nearby.', 'আপনার অবস্থান কাছের খাবারের সাথে মেলাতে সাহায্য করে।')}>
      <form className="space-y-5" onSubmit={(e) => { e.preventDefault(); save.mutate(); }}>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label={L('Name', 'নাম')} error={fieldError(save, 'name')}>
            <input className="input" value={form.name} onChange={(e) => set({ name: e.target.value })} required />
          </Field>
          <Field label={L('Email (optional)', 'ইমেইল (ঐচ্ছিক)')} error={fieldError(save, 'email')} hint={user.email && !user.emailVerified ? L('Not verified yet. Sign in once with an email code to verify it.', 'এখনো যাচাই হয়নি।') : undefined}>
            <input className="input" type="email" value={form.email} onChange={(e) => set({ email: e.target.value })} />
          </Field>
          {partner && (
            <>
              <Field label={L('Organization name', 'সংগঠনের নাম')} error={fieldError(save, 'orgName')}>
                <input className="input" value={form.orgName} onChange={(e) => set({ orgName: e.target.value })} />
              </Field>
              <Field label={L('Servings you can handle per day', 'দিনে কতজনের খাবার নিতে পারেন')}>
                <input className="input" type="number" min="1" max="5000" value={form.capacity} onChange={(e) => set({ capacity: e.target.value })} />
              </Field>
            </>
          )}
        </div>
        <AddressFields value={form.address} onChange={(address) => set({ address })} errors={addressErrors(save.error)} />
        <LocationPicker value={form.location} onChange={(location) => set({ location })} error={fieldError(save, 'location')} />
        <button className="btn-primary px-8" disabled={save.isPending}>{save.isPending ? L('Saving…', 'সংরক্ষণ হচ্ছে…') : L('Save profile', 'প্রোফাইল সংরক্ষণ')}</button>
      </form>
    </Section>
  );
}

function Security() {
  const { start } = useAuth();
  const { L } = useLang();
  const toast = useToast();
  const [form, setForm] = useState({ currentPassword: '', newPassword: '' });
  const change = useMutation({
    mutationFn: () => api('/auth/password', { method: 'PATCH', body: form }),
    onSuccess: (r) => { start(r); setForm({ currentPassword: '', newPassword: '' }); toast(L('Password changed. Other devices were signed out.', 'পাসওয়ার্ড পরিবর্তন হয়েছে।')); },
    onError: (e) => !Object.keys(e.details ?? {}).length && toast(e.message, 'error'),
  });
  return (
    <Section title={L('Password', 'পাসওয়ার্ড')} sub={L('Changing it signs you out on every other device.', 'পরিবর্তন করলে অন্যান্য ডিভাইস থেকে সাইন আউট হবে।')}>
      <form className="grid gap-4 sm:grid-cols-[1fr_1fr_auto] sm:items-start" onSubmit={(e) => { e.preventDefault(); change.mutate(); }}>
        <PasswordField label={L('Current password', 'বর্তমান পাসওয়ার্ড')} value={form.currentPassword} onChange={(currentPassword) => setForm({ ...form, currentPassword })} error={fieldError(change, 'currentPassword')} />
        <PasswordField label={L('New password', 'নতুন পাসওয়ার্ড')} value={form.newPassword} onChange={(newPassword) => setForm({ ...form, newPassword })} error={fieldError(change, 'newPassword')} meter autoComplete="new-password" />
        <button className="btn-secondary sm:mt-7" disabled={change.isPending || !form.currentPassword || !form.newPassword}>{L('Change', 'পরিবর্তন')}</button>
      </form>
    </Section>
  );
}

export default function Profile() {
  const { user } = useAuth();
  const { L } = useLang();
  const welcome = useSearchParams()[0].get('welcome');
  const r = ROLES[user.role];
  const needs = NEEDS_VERIFICATION.includes(user.role);

  return (
    <div className="pb-6">
      <div className="mesh">
        <div className="wrap max-w-4xl pb-8 pt-10">
          <p className="text-sm text-muted">{L(r.en, r.bn)}, {user.phone}{user.phoneVerified ? ' ✓' : ''}</p>
          <h1 className="page-title mt-1">{L('Your profile', 'আপনার প্রোফাইল')}</h1>
          {welcome && (
            <Notice className="mt-5">
              {needs
                ? L('Welcome to FoodBridge! Add your location, then upload a document so an administrator can verify you.', 'স্বাগতম! অবস্থান দিন, তারপর যাচাইয়ের জন্য কাগজ আপলোড করুন।')
                : L('Welcome to FoodBridge! Add your usual location so your pickup point is filled in for you.', 'স্বাগতম! আপনার অবস্থান দিন।')}
            </Notice>
          )}
        </div>
      </div>
      <div className="wrap max-w-4xl space-y-6">
        {needs && <Verification />}
        <Details />
        <Security />
      </div>
    </div>
  );
}
