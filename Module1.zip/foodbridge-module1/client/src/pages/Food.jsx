/** Feature 1.3 (Member 3): list of open food posts, filterable by food type, district and text. */
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { keepPreviousData, useQuery } from '@tanstack/react-query';
import { api } from '../lib/api.js';
import { useAuth } from '../lib/auth.jsx';
import { useLang } from '../lib/i18n.jsx';
import { useLocations } from '../lib/locations.js';
import { POSTERS } from '../lib/constants.js';
import CategoryChips from '../components/CategoryChips.jsx';
import DonationRow from '../components/DonationRow.jsx';
import { Empty, ErrorState, Spinner } from '../components/ui.jsx';

export default function Food() {
  const { user } = useAuth();
  const { L, num, lang } = useLang();
  const divisions = useLocations();
  const [category, setCategory] = useState('');
  const [district, setDistrict] = useState('');
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const qs = new URLSearchParams({ page, ...(category && { category }), ...(district && { district }), ...(q.trim() && { q: q.trim() }) });
  const { data, isLoading, error, isFetching } = useQuery({ queryKey: ['donations', 'list', qs.toString()], queryFn: () => api(`/donations?${qs}`), placeholderData: keepPreviousData, refetchInterval: 60_000 });
  const reset = (fn) => (v) => { fn(v); setPage(1); };

  return (
    <div className="pb-6">
      <div className="mesh">
        <div className="wrap pb-6 pt-10">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h1 className="page-title">{L('Food waiting for pickup', 'সংগ্রহের অপেক্ষায় খাবার')}</h1>
              <p className="mt-1 text-muted">{data ? L(`${data.total} open post${data.total === 1 ? '' : 's'}, soonest to expire first`, `${num(data.total)}টি খোলা পোস্ট`) : ' '}</p>
            </div>
            {user && POSTERS.includes(user.role) && <Link to="/food/new" className="btn-primary">{L('Share extra food', 'বাড়তি খাবার দিন')}</Link>}
          </div>
          <CategoryChips value={category} onChange={reset(setCategory)} className="mt-6" />
          <div className="mt-4 flex flex-wrap gap-3">
            <input className="input max-w-xs" placeholder={L('Search food', 'খাবার খুঁজুন')} value={q} onChange={(e) => reset(setQ)(e.target.value)} />
            <select className="input w-auto" value={district} onChange={(e) => reset(setDistrict)(e.target.value)} aria-label={L('District', 'জেলা')}>
              <option value="">{L('All districts', 'সব জেলা')}</option>
              {divisions.map((dv) => (
                <optgroup key={dv.name} label={lang === 'bn' ? dv.bn : dv.name}>
                  {dv.districts.map((d) => <option key={d.name} value={d.name}>{lang === 'bn' ? d.bn : d.name}</option>)}
                </optgroup>
              ))}
            </select>
          </div>
        </div>
      </div>
      <div className={`wrap max-w-4xl transition-opacity ${isFetching ? 'opacity-70' : ''}`}>
        {isLoading ? <Spinner /> : error ? <ErrorState error={error} /> : data.items.length ? (
          <>
            <ul className="divide-y divide-line/70">{data.items.map((d, i) => <DonationRow key={d._id} d={d} index={i} animate />)}</ul>
            {data.pages > 1 && (
              <div className="mt-6 flex items-center justify-center gap-3">
                <button className="btn-secondary py-2 text-sm" disabled={page <= 1} onClick={() => setPage(page - 1)}>{L('Previous', 'আগের')}</button>
                <span className="text-sm text-muted">{L(`Page ${page} of ${data.pages}`, `পৃষ্ঠা ${num(page)} / ${num(data.pages)}`)}</span>
                <button className="btn-secondary py-2 text-sm" disabled={page >= data.pages} onClick={() => setPage(page + 1)}>{L('Next', 'পরের')}</button>
              </div>
            )}
          </>
        ) : (
          <Empty title={L('Nothing matches right now', 'এই মুহূর্তে কিছু নেই')}>{L('Try another food type or district, or check back soon.', 'অন্য ধরন বা জেলা দেখুন, বা একটু পরে আসুন।')}</Empty>
        )}
      </div>
    </div>
  );
}
