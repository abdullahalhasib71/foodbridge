/**
 * Feature 1.2 (Member 2): admin review of identity documents and account management.
 */
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { api, openDocument } from '../lib/api.js';
import { useLang } from '../lib/i18n.jsx';
import { useAction } from '../lib/hooks.js';
import { DOC_TYPES, ROLES, VERIFICATION } from '../lib/constants.js';
import PasswordField from '../components/PasswordField.jsx';
import { useToast } from '../components/Toast.jsx';
import { Badge, Empty, ErrorState, Field, Section, Spinner, fieldError } from '../components/ui.jsx';

function ReviewCard({ u }) {
  const { L, dateTime } = useLang();
  const toast = useToast();
  const [rejecting, setRejecting] = useState(false);
  const [reason, setReason] = useState('');
  const inv = [['admin']];
  const approve = useAction(`/admin/verifications/${u._id}/approve`, { invalidate: inv, success: L(`${u.name} is verified.`, `${u.name} যাচাইকৃত।`) });
  const reject = useAction(`/admin/verifications/${u._id}/reject`, { invalidate: inv, success: L('Changes requested.', 'সংশোধন চাওয়া হয়েছে।') });
  const r = ROLES[u.role];
  const a = u.address;

  return (
    <li className="panel p-5 sm:p-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone={u.role === 'partner' ? 'ocean' : 'lilac'}>{L(r.en, r.bn)}</Badge>
            {u.verification.submittedAt && <span className="text-xs text-muted">{L('Submitted', 'জমা')} {dateTime(u.verification.submittedAt)}</span>}
          </div>
          <h3 className="mt-2 font-display text-xl font-bold">{u.orgName ?? u.name}</h3>
          <p className="text-sm text-muted">
            {u.orgName && `${u.name}, `}{u.phone}{u.phoneVerified ? ' ✓' : ''}{u.email ? `, ${u.email}` : ''}
          </p>
          {a && <p className="text-sm text-muted">{[a.details, a.area, a.upazila, a.district].filter(Boolean).join(', ')}</p>}
          {u.capacity && <p className="text-sm text-muted">{L(`Can handle ${u.capacity} servings a day`, `দিনে ${u.capacity} জনের খাবার`)}</p>}
        </div>
        {!rejecting && (
          <div className="flex gap-2">
            <button className="btn-primary py-2 text-sm" onClick={() => approve.mutate({})} disabled={approve.isPending}>{L('Approve', 'অনুমোদন')}</button>
            <button className="btn-danger py-2 text-sm" onClick={() => setRejecting(true)}>{L('Request changes', 'সংশোধন চান')}</button>
          </div>
        )}
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {u.verification.documents.filter((d) => !d.purgedAt).map((d) => (
          <button key={d._id} type="button" onClick={() => openDocument(u._id, d._id).catch((e) => toast(e.message, 'error'))} className="flex items-center gap-2 rounded-2xl border border-line bg-paper px-3 py-2 text-left text-sm hover:border-leaf/40">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-ocean-soft text-[10px] font-bold text-ocean-dark">{d.mimeType === 'application/pdf' ? 'PDF' : 'IMG'}</span>
            <span>
              <span className="block font-medium">{L(DOC_TYPES[d.type]?.en ?? d.type, DOC_TYPES[d.type]?.bn)}</span>
              <span className="block text-xs text-muted">{d.originalName}</span>
            </span>
          </button>
        ))}
      </div>

      {rejecting && (
        <form className="mt-4 space-y-3" onSubmit={(e) => { e.preventDefault(); reject.mutate({ reason }); }}>
          <Field label={L('What should the applicant fix?', 'আবেদনকারীকে কী ঠিক করতে হবে?')} error={fieldError(reject, 'reason')}>
            <textarea className="input min-h-20" value={reason} onChange={(e) => setReason(e.target.value)} placeholder={L('e.g. The NID photo is blurry. Please upload a clearer photo of both sides.', 'যেমন: ছবিটি অস্পষ্ট, আবার আপলোড করুন।')} />
          </Field>
          <div className="flex gap-2">
            <button className="btn-danger py-2 text-sm" disabled={reject.isPending}>{L('Send back', 'ফেরত পাঠান')}</button>
            <button type="button" className="btn-ghost text-sm" onClick={() => setRejecting(false)}>{L('Cancel', 'বাতিল')}</button>
          </div>
        </form>
      )}
    </li>
  );
}

function Queue() {
  const { L } = useLang();
  const { data, isLoading, error } = useQuery({ queryKey: ['admin', 'verifications'], queryFn: () => api('/admin/verifications?status=pending') });
  if (isLoading) return <Spinner />;
  if (error) return <ErrorState error={error} />;
  if (!data.items.length) return <Empty title={L('All caught up', 'সব পর্যালোচনা শেষ')}>{L('New organizations and volunteers appear here when they submit their documents.', 'নতুন আবেদন এখানে দেখা যাবে।')}</Empty>;
  return <ul className="space-y-4">{data.items.map((u) => <ReviewCard key={u._id} u={u} />)}</ul>;
}

function Users() {
  const { L, date } = useLang();
  const [role, setRole] = useState('');
  const [q, setQ] = useState('');
  const qs = new URLSearchParams({ ...(role && { role }), ...(q && { q }) });
  const { data, isLoading, error } = useQuery({ queryKey: ['admin', 'users', qs.toString()], queryFn: () => api(`/admin/users?${qs}`) });
  const setStatus = useAction((v) => `/admin/users/${v.id}/status`, { method: 'PATCH', invalidate: [['admin']], success: (r) => L(`${r.user.name} is now ${r.user.status}.`, `${r.user.name} এর অবস্থা পরিবর্তিত।`) });

  return (
    <>
      <div className="mb-4 flex flex-wrap gap-3">
        <input className="input max-w-xs" placeholder={L('Search name, phone, email', 'নাম, ফোন, ইমেইল খুঁজুন')} value={q} onChange={(e) => setQ(e.target.value)} />
        <select className="input w-auto" value={role} onChange={(e) => setRole(e.target.value)}>
          <option value="">{L('All roles', 'সব ভূমিকা')}</option>
          {Object.entries(ROLES).map(([k, r]) => <option key={k} value={k}>{L(r.en, r.bn)}</option>)}
        </select>
      </div>
      {isLoading ? <Spinner /> : error ? <ErrorState error={error} /> : (
        <div className="panel overflow-x-auto">
          <table className="w-full min-w-[40rem] text-left text-sm">
            <thead className="border-b border-line text-xs uppercase tracking-wide text-muted">
              <tr><th className="px-4 py-3">{L('Name', 'নাম')}</th><th className="px-4 py-3">{L('Role', 'ভূমিকা')}</th><th className="px-4 py-3">{L('Verification', 'যাচাই')}</th><th className="px-4 py-3">{L('Joined', 'যোগদান')}</th><th className="px-4 py-3" /></tr>
            </thead>
            <tbody className="divide-y divide-line/70">
              {data.items.map((u) => {
                const v = VERIFICATION[u.verification?.status ?? 'not_required'];
                return (
                  <tr key={u._id} className={u.status === 'suspended' ? 'opacity-60' : ''}>
                    <td className="px-4 py-3"><span className="font-medium">{u.orgName ?? u.name}</span><span className="block text-xs text-muted">{u.phone}</span></td>
                    <td className="px-4 py-3">{L(ROLES[u.role].en, ROLES[u.role].bn)}</td>
                    <td className="px-4 py-3"><Badge tone={v.tone}>{L(v.en, v.bn)}</Badge></td>
                    <td className="px-4 py-3 text-muted">{date(u.createdAt)}</td>
                    <td className="px-4 py-3 text-right">
                      {u.role !== 'admin' && (u.status === 'active'
                        ? <button className="btn-ghost py-1 text-sm text-chili-dark" onClick={() => setStatus.mutate({ id: u._id, status: 'suspended' })}>{L('Suspend', 'স্থগিত')}</button>
                        : <button className="btn-ghost py-1 text-sm text-leaf" onClick={() => setStatus.mutate({ id: u._id, status: 'active' })}>{L('Restore', 'ফিরিয়ে দিন')}</button>)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {!data.items.length && <p className="px-4 py-8 text-center text-muted">{L('No accounts match.', 'কোনো অ্যাকাউন্ট নেই।')}</p>}
        </div>
      )}
    </>
  );
}

function Operators() {
  const { L } = useLang();
  const [form, setForm] = useState({ name: '', phone: '', email: '', password: '' });
  const create = useAction('/admin/operators', { invalidate: [['admin']], success: L('Hotline operator account created.', 'হটলাইন অপারেটর অ্যাকাউন্ট তৈরি হয়েছে।'), onSuccess: () => setForm({ name: '', phone: '', email: '', password: '' }) });
  return (
    <Section title={L('Create a hotline operator', 'হটলাইন অপারেটর তৈরি')} sub={L('Operators post food on behalf of donors who phone in instead of using the app. They cannot sign up themselves.', 'অপারেটররা ফোনকারী দাতাদের পক্ষে খাবার পোস্ট করেন।')}>
      <form className="grid gap-4 sm:grid-cols-2" onSubmit={(e) => { e.preventDefault(); create.mutate(form); }}>
        <Field label={L('Name', 'নাম')} error={fieldError(create, 'name')}><input className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></Field>
        <Field label={L('Mobile number', 'মোবাইল নম্বর')} error={fieldError(create, 'phone')}><input className="input" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} required /></Field>
        <Field label={L('Email (optional)', 'ইমেইল (ঐচ্ছিক)')} error={fieldError(create, 'email')}><input className="input" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
        <PasswordField label={L('Temporary password', 'অস্থায়ী পাসওয়ার্ড')} value={form.password} onChange={(password) => setForm({ ...form, password })} error={fieldError(create, 'password')} meter autoComplete="new-password" />
        <button className="btn-primary sm:col-span-2 sm:justify-self-start" disabled={create.isPending}>{L('Create account', 'অ্যাকাউন্ট তৈরি')}</button>
      </form>
    </Section>
  );
}

export default function Admin() {
  const { L, num } = useLang();
  const [tab, setTab] = useState('queue');
  const { data: s } = useQuery({ queryKey: ['admin', 'stats'], queryFn: () => api('/admin/stats') });
  const tiles = s ? [
    [s.pendingVerifications, L('waiting for review', 'পর্যালোচনার অপেক্ষায়'), 'from-amber to-ember'],
    [(s.roles.partner ?? 0) + (s.roles.volunteer ?? 0), L('organizations and volunteers', 'সংগঠন ও স্বেচ্ছাসেবক'), 'from-sea to-indigo'],
    [s.donations.available ?? 0, L('food posts open now', 'এখন খোলা পোস্ট'), 'from-brand to-teal'],
    [s.upcomingEvents, L('upcoming events', 'আসন্ন অনুষ্ঠান'), 'from-ember to-berry'],
  ] : [];
  const tabs = [['queue', L('Verification queue', 'যাচাইয়ের তালিকা')], ['users', L('Accounts', 'অ্যাকাউন্ট')], ['operators', L('Hotline operators', 'হটলাইন অপারেটর')]];

  return (
    <div className="pb-6">
      <div className="mesh">
        <div className="wrap pb-8 pt-10">
          <h1 className="page-title">{L('Administration', 'প্রশাসন')}</h1>
          <dl className="mt-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
            {tiles.map(([n, label, g]) => (
              <div key={label} className={`relative overflow-hidden rounded-3xl bg-gradient-to-br px-5 py-4 text-white shadow-soft ${g}`}>
                <span className="absolute -right-6 -top-6 h-20 w-20 rounded-full bg-white/15" aria-hidden="true" />
                <dd className="font-display text-3xl font-bold">{num(n)}</dd>
                <dt className="text-sm text-white/90">{label}</dt>
              </div>
            ))}
          </dl>
        </div>
      </div>
      <div className="wrap">
        <div className="mb-6 inline-flex flex-wrap rounded-full bg-surface p-1 text-sm shadow-soft" role="tablist">
          {tabs.map(([v, label]) => (
            <button key={v} role="tab" aria-selected={tab === v} onClick={() => setTab(v)} className={`rounded-full px-4 py-1.5 font-medium ${tab === v ? 'bg-gradient-to-r from-brand to-teal text-white' : 'text-muted hover:text-ink'}`}>
              {label}{v === 'queue' && s?.pendingVerifications ? ` (${num(s.pendingVerifications)})` : ''}
            </button>
          ))}
        </div>
        {tab === 'queue' ? <Queue /> : tab === 'users' ? <Users /> : <Operators />}
      </div>
    </div>
  );
}
