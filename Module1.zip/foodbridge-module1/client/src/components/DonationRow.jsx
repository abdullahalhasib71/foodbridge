import { Link } from 'react-router-dom';
import { useLang } from '../lib/i18n.jsx';
import { CATEGORIES, HUE } from '../lib/constants.js';
import FreshnessBar from './FreshnessBar.jsx';
import FoodIcon from './FoodIcon.jsx';
import { StatusPill } from './ui.jsx';

export default function DonationRow({ d, showStatus = false, index = 0, animate = false }) {
  const { L, num } = useLang();
  const cat = CATEGORIES[d.category];
  const hue = HUE[cat.hue];
  const donorName = d.onBehalf?.name ?? d.donor?.orgName ?? d.donor?.name;
  const active = d.status === 'available';

  return (
    <li className={animate ? 'rise' : undefined} style={animate ? { animationDelay: `${index * 80}ms` } : undefined}>
      <Link to={`/food/${d._id}`} className="group -mx-3 grid grid-cols-[4.5rem_1fr] gap-4 rounded-2xl px-3 py-4 transition-colors hover:bg-leaf-soft/40 sm:grid-cols-[5.5rem_1fr]">
        {d.photoUrls?.[0] ? (
          <div className="relative overflow-hidden rounded-2xl">
            <img src={d.photoUrls[0]} alt="" className="h-full min-h-20 w-full object-cover" />
            <span className={`absolute bottom-1 left-1 rounded-full px-2 text-xs font-bold ${hue.tile}`}>{num(d.servings)}</span>
          </div>
        ) : (
          <div className={`flex flex-col items-center justify-center rounded-2xl py-2 ${hue.tile}`}>
            <FoodIcon category={d.category} className="mb-0.5 h-6 w-7" />
            <span className="font-display text-xl font-bold leading-none sm:text-2xl">{num(d.servings)}</span>
            <span className="text-[11px] opacity-80">{L('servings', 'জনের')}</span>
          </div>
        )}
        <div className="min-w-0">
          <div className="flex items-start justify-between gap-3">
            <h3 className="line-clamp-2 font-display text-lg font-semibold group-hover:text-leaf sm:truncate">{d.title}</h3>
            {showStatus && <StatusPill status={d.status} />}
          </div>
          <p className="truncate text-sm text-muted">
            {L(cat.en, cat.bn)}, {d.address?.area}, {d.address?.district}
          </p>
          {donorName && <p className="truncate text-xs text-muted">{L('From', 'দাতা:')} {donorName}</p>}
          {active && (
            <div className="mt-2 max-w-md">
              <FreshnessBar cookedAt={d.cookedAt} safeUntil={d.safeUntil} />
            </div>
          )}
        </div>
      </Link>
    </li>
  );
}
