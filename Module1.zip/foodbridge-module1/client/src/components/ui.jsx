import { cloneElement, isValidElement, useId } from 'react';
import { Link } from 'react-router-dom';
import { useLang } from '../lib/i18n.jsx';
import { STATUSES } from '../lib/constants.js';

export function Logo({ className = '' }) {
  const { lang } = useLang();
  return (
    <span className={`inline-flex items-center gap-2 ${className}`}>
      <svg viewBox="0 0 32 32" className="h-8 w-8" aria-hidden="true">
        <defs><linearGradient id="fbg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#16795C" /><stop offset="1" stopColor="#0E7490" /></linearGradient></defs>
        <rect width="32" height="32" rx="9" fill="url(#fbg)" />
        <path d="M6 22c3-8 17-8 20 0" fill="none" stroke="#F4F8F5" strokeWidth="3" strokeLinecap="round" />
        <circle cx="16" cy="11" r="3" fill="#F2B95C" />
      </svg>
      <span className="font-display text-xl font-bold tracking-tight">{lang === 'bn' ? 'খাদ্যসেতু' : 'FoodBridge'}</span>
    </span>
  );
}

/**
 * Form field with an accessible label, hint and error. A single input/select/textarea child
 * is linked automatically; for composite children pass `id` and put it on the control.
 */
export function Field({ label, hint, error, children, className = '', id }) {
  const auto = useId();
  const single = isValidElement(children) && ['input', 'select', 'textarea'].includes(children.type);
  const controlId = id ?? (single ? children.props.id ?? auto : undefined);
  const descId = `${controlId ?? auto}-desc`;
  const note = error ? <span id={descId} className="error">{error}</span> : hint ? <span id={descId} className="hint">{hint}</span> : null;

  if (!controlId) {
    return (
      <label className={`block ${className}`}>
        {label && <span className="label">{label}</span>}
        {children}
        {note}
      </label>
    );
  }
  return (
    <div className={`block ${className}`}>
      {label && <label htmlFor={controlId} className="label">{label}</label>}
      {single ? cloneElement(children, { id: controlId, 'aria-describedby': note ? descId : undefined, 'aria-invalid': error ? true : undefined }) : children}
      {note}
    </div>
  );
}

export const fieldError = (mutation, name) => (mutation?.error ?? mutation)?.details?.[name]?.[0];

export function Spinner({ label }) {
  const { L } = useLang();
  return (
    <div className="flex items-center gap-3 py-10 text-muted" role="status">
      <span className="h-5 w-5 animate-spin rounded-full border-2 border-line border-t-leaf" />
      {label ?? L('Loading…', 'লোড হচ্ছে…')}
    </div>
  );
}

const tones = {
  info: 'bg-leaf-soft text-leaf-dark',
  warn: 'bg-haldi-soft text-haldi-dark',
  error: 'bg-chili-soft text-chili-dark',
};
export function Notice({ tone = 'info', children, className = '' }) {
  return <div className={`rounded-2xl px-4 py-3 text-sm leading-relaxed ${tones[tone]} ${className}`}>{children}</div>;
}

const pill = {
  leaf: ['bg-leaf-soft text-leaf-dark', 'bg-leaf'],
  turmeric: ['bg-turmeric-soft text-turmeric-dark', 'bg-turmeric'],
  ocean: ['bg-ocean-soft text-ocean-dark', 'bg-ocean'],
  lilac: ['bg-lilac-soft text-lilac-dark', 'bg-lilac'],
  brand: ['bg-gradient-to-r from-brand to-teal text-white', 'bg-white'],
  muted: ['bg-line/70 text-muted', 'bg-muted/60'],
};
export function StatusPill({ status }) {
  const { L } = useLang();
  const s = STATUSES[status];
  const [cls, dot] = pill[s.tone];
  return (
    <span className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold ${cls}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${dot}`} aria-hidden="true" />
      {L(s.en, s.bn)}
    </span>
  );
}

export function Empty({ title, children, action }) {
  return (
    <div className="rounded-3xl border border-dashed border-leaf/25 bg-surface/60 px-6 py-12 text-center">
      <p className="font-display text-lg font-semibold">{title}</p>
      {children && <p className="mx-auto mt-1 max-w-md text-muted">{children}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function ErrorState({ error }) {
  return <Notice tone="error">{error?.message ?? 'Something went wrong.'}</Notice>;
}

export function BackLink({ to, children }) {
  return (
    <Link to={to} className="mb-4 inline-block text-sm text-muted hover:text-ink">
      ← {children}
    </Link>
  );
}

const badgeTones = {
  leaf: 'bg-leaf-soft text-leaf-dark',
  turmeric: 'bg-turmeric-soft text-turmeric-dark',
  rose: 'bg-rose-soft text-rose-dark',
  ocean: 'bg-ocean-soft text-ocean-dark',
  lilac: 'bg-lilac-soft text-lilac-dark',
  muted: 'bg-line/70 text-muted',
};
export function Badge({ tone = 'muted', children, className = '' }) {
  return <span className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold ${badgeTones[tone]} ${className}`}>{children}</span>;
}

/** A titled white card used to group form sections. */
export function Section({ title, sub, children, action, className = '' }) {
  return (
    <section className={`panel p-5 sm:p-7 ${className}`}>
      {(title || action) && (
        <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
          <div>
            {title && <h2 className="font-display text-xl font-bold">{title}</h2>}
            {sub && <p className="mt-1 text-sm text-muted">{sub}</p>}
          </div>
          {action}
        </div>
      )}
      {children}
    </section>
  );
}
