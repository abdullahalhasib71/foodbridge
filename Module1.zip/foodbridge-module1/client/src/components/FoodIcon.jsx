import { CATEGORIES } from '../lib/constants.js';

/** Small two-tone food glyphs, one per category. currentColor = category hue. */
const PATHS = {
  rice_curry: (
    <>
      <path d="M6 17h28a14 12 0 0 1-28 0z" fill="currentColor" />
      <path d="M10 17c1-5 5-8 10-8s9 3 10 8" fill="#fff" opacity=".9" />
      <circle cx="15" cy="13" r="1.4" fill="currentColor" opacity=".5" /><circle cx="22" cy="11.5" r="1.4" fill="currentColor" opacity=".5" />
    </>
  ),
  biryani: (
    <>
      <path d="M8 16h24v8a8 8 0 0 1-8 8h-8a8 8 0 0 1-8-8z" fill="currentColor" />
      <rect x="5" y="13" width="30" height="5" rx="2.5" fill="currentColor" opacity=".7" />
      <path d="M14 8c-2-2 2-3 0-5M20 9c-2-2 2-3 0-5M26 8c-2-2 2-3 0-5" stroke="currentColor" strokeWidth="1.8" fill="none" strokeLinecap="round" opacity=".6" />
    </>
  ),
  bakery: (
    <>
      <path d="M7 20c0-7 6-11 13-11s13 4 13 11v6a3 3 0 0 1-3 3H10a3 3 0 0 1-3-3z" fill="currentColor" />
      <path d="M14 14l2 5M20 13v6M26 14l-2 5" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" opacity=".85" />
    </>
  ),
  sweets: (
    <>
      <circle cx="14" cy="21" r="7" fill="currentColor" /><circle cx="26" cy="21" r="7" fill="currentColor" opacity=".75" />
      <circle cx="20" cy="13" r="6" fill="currentColor" opacity=".55" />
      <circle cx="12" cy="18.5" r="1.6" fill="#fff" opacity=".8" />
    </>
  ),
  fruits: (
    <>
      <circle cx="20" cy="22" r="10" fill="currentColor" />
      <path d="M20 12c0-3 2-5 5-6" stroke="currentColor" strokeWidth="2.2" fill="none" strokeLinecap="round" opacity=".7" />
      <path d="M21 11c3-3 7-2 8 0-3 2-6 2-8 0z" fill="currentColor" opacity=".55" />
      <circle cx="16" cy="19" r="2" fill="#fff" opacity=".7" />
    </>
  ),
  dry: (
    <>
      <path d="M11 12h18l3 16a4 4 0 0 1-4 4H12a4 4 0 0 1-4-4z" fill="currentColor" />
      <path d="M12 12c1-3 3-5 8-5s7 2 8 5" stroke="currentColor" strokeWidth="2.2" fill="none" opacity=".6" />
      <rect x="14" y="18" width="12" height="6" rx="2" fill="#fff" opacity=".8" />
    </>
  ),
  packaged: (
    <>
      <path d="M6 13l14-6 14 6v14l-14 6-14-6z" fill="currentColor" />
      <path d="M6 13l14 6 14-6M20 19v14" stroke="#fff" strokeWidth="1.8" fill="none" opacity=".75" />
    </>
  ),
};

export default function FoodIcon({ category, className = 'h-7 w-7' }) {
  return (
    <svg viewBox="0 0 40 36" className={className} style={{ color: CATEGORIES[category]?.hex }} aria-hidden="true">
      {PATHS[category] ?? PATHS.packaged}
    </svg>
  );
}
