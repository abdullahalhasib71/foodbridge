import { useDuration, useLang } from '../lib/i18n.jsx';
import { useNow } from '../lib/hooks.js';

/**
 * The signature element: how much of the safe-to-eat window is left.
 * Green while more than half remains, turmeric under half, chili red in the last fifth.
 */
export function freshness(cookedAt, safeUntil, now = Date.now()) {
  const total = new Date(safeUntil) - new Date(cookedAt);
  const left = new Date(safeUntil) - now;
  const ratio = total > 0 ? Math.max(0, Math.min(1, left / total)) : 0;
  const tone = ratio > 0.5 ? 'leaf' : ratio > 0.2 ? 'haldi' : 'chili';
  return { left, ratio, tone };
}

const fill = {
  leaf: 'bg-gradient-to-r from-brand to-[#2FB38A]',
  haldi: 'bg-gradient-to-r from-turmeric to-saffron',
  chili: 'bg-gradient-to-r from-saffron to-chili',
};
const text = { leaf: 'text-leaf-dark', haldi: 'text-haldi-dark', chili: 'text-chili-dark' };

export default function FreshnessBar({ cookedAt, safeUntil, size = 'sm' }) {
  const { L, time } = useLang();
  const duration = useDuration();
  const now = useNow();
  const { left, ratio, tone } = freshness(cookedAt, safeUntil, now);
  const expired = left <= 0;

  return (
    <div className="w-full">
      <div
        className={`overflow-hidden rounded-full bg-line ${size === 'lg' ? 'h-3' : 'h-2'}`}
        role="meter"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={Math.round(ratio * 100)}
        aria-label={L('Safe time remaining', 'নিরাপদ সময় বাকি')}
      >
        <div className={`h-full rounded-full transition-[width] duration-700 ${fill[tone]}`} style={{ width: `${ratio * 100}%` }} />
      </div>
      <div className={`mt-1 flex justify-between gap-2 ${size === 'lg' ? 'text-sm' : 'text-xs'}`}>
        <span className={`font-semibold ${text[tone]}`}>
          {expired ? L('Safe window ended', 'নিরাপদ সময় শেষ') : L(`${duration(left)} left`, `${duration(left)} বাকি`)}
        </span>
        <span className="text-muted">{L(`safe until ${time(safeUntil)}`, `${time(safeUntil)} পর্যন্ত নিরাপদ`)}</span>
      </div>
    </div>
  );
}
