import { useLang } from '../lib/i18n.jsx';
import { CATEGORIES, HUE } from '../lib/constants.js';
import FoodIcon from './FoodIcon.jsx';

/** Colourful category chips. With onChange they act as a single-select filter. */
export default function CategoryChips({ value, onChange, className = '', hideAll = false }) {
  const { L } = useLang();
  const Tag = onChange ? 'button' : 'span';
  return (
    <div className={`flex flex-wrap gap-2 ${className}`}>
      {onChange && !hideAll && (
        <button
          type="button"
          onClick={() => onChange('')}
          aria-pressed={!value}
          className={`rounded-full px-3.5 py-1.5 text-sm font-medium ring-1 transition ${!value ? 'bg-ink text-white ring-ink' : 'bg-surface text-muted ring-line hover:text-ink'}`}
        >
          {L('All food', 'সব খাবার')}
        </button>
      )}
      {Object.entries(CATEGORIES).map(([k, c]) => {
        const selected = value === k;
        return (
          <Tag
            key={k}
            {...(onChange ? { type: 'button', onClick: () => onChange(selected ? '' : k), 'aria-pressed': selected } : {})}
            className={`inline-flex items-center gap-1.5 rounded-full py-1 pl-1.5 pr-3.5 text-sm font-medium ring-1 transition ${HUE[c.hue].chip} ${
              onChange && value && !selected ? 'opacity-45 hover:opacity-100' : ''
            } ${selected ? 'ring-2 shadow-soft' : ''}`}
          >
            <span className="grid h-7 w-7 place-items-center rounded-full bg-white/80">
              <FoodIcon category={k} className="h-4.5 w-5" />
            </span>
            {L(c.en, c.bn)}
          </Tag>
        );
      })}
    </div>
  );
}
