/** Feature 1.1 (Member 1): "enter the code we sent" panel, with the dev-mode code shown when enabled. */
import { useLang } from '../lib/i18n.jsx';
import OtpInput from './OtpInput.jsx';
import { Notice } from './ui.jsx';

export default function OtpStep({ otp, code, setCode, onResend, onBack }) {
  const { L, num } = useLang();
  const { sent, wait, busy } = otp;
  return (
    <div className="space-y-4">
      <p className="text-muted">
        {sent.channel === 'sms'
          ? L(`We sent a 6-digit code by SMS to ${sent.target}.`, `${sent.target} নম্বরে SMS এ ৬ অঙ্কের কোড পাঠানো হয়েছে।`)
          : L(`We sent a 6-digit code to ${sent.target}.`, `${sent.target} ঠিকানায় ৬ অঙ্কের কোড পাঠানো হয়েছে।`)}{' '}
        {onBack && <button type="button" className="font-medium text-leaf hover:underline" onClick={onBack}>{L('Change', 'পরিবর্তন')}</button>}
      </p>
      {sent.devCode && (
        <Notice tone="warn">
          {L('Development mode: your code is ', 'ডেভেলপমেন্ট মোড: আপনার কোড ')}
          <button type="button" className="font-display text-base font-bold tracking-widest underline" onClick={() => setCode(sent.devCode)}>{sent.devCode}</button>
          {L(' (tap to fill). It is also printed in the API terminal.', ' (পূরণ করতে চাপুন)।')}
        </Notice>
      )}
      <OtpInput value={code} onChange={setCode} />
      <p className="text-sm text-muted">
        {wait > 0 ? (
          L(`You can ask for a new code in ${wait} s.`, `${num(wait)} সেকেন্ড পর নতুন কোড চাইতে পারবেন।`)
        ) : (
          <button type="button" className="font-medium text-leaf hover:underline disabled:opacity-50" onClick={onResend} disabled={busy}>
            {L('Send a new code', 'নতুন কোড পাঠান')}
          </button>
        )}
      </p>
    </div>
  );
}
