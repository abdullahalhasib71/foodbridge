/** Feature 1.3 (Member 3): pick up to 3 food photos, keep or remove existing ones. */
import { useEffect, useMemo } from 'react';
import { useLang } from '../lib/i18n.jsx';

const MAX = 3;
const MAX_MB = 3;

export default function PhotoPicker({ existing = [], keep, onKeepChange, files, onFilesChange, onError }) {
  const { L } = useLang();
  const previews = useMemo(() => files.map((f) => ({ f, url: URL.createObjectURL(f) })), [files]);
  useEffect(() => () => previews.forEach((p) => URL.revokeObjectURL(p.url)), [previews]);
  const count = keep.length + files.length;

  const add = (list) => {
    const chosen = [...list];
    const tooBig = chosen.find((f) => f.size > MAX_MB * 1024 * 1024);
    if (tooBig) return onError?.(L(`"${tooBig.name}" is larger than ${MAX_MB} MB.`, `"${tooBig.name}" ${MAX_MB} মেগাবাইটের বেশি।`));
    const room = MAX - count;
    if (chosen.length > room) onError?.(L(`Only ${MAX} photos are allowed.`, `সর্বোচ্চ ${MAX}টি ছবি।`));
    onFilesChange([...files, ...chosen.slice(0, room)]);
  };

  const tile = 'relative h-24 w-24 overflow-hidden rounded-2xl border border-line';
  const remove = 'absolute right-1 top-1 grid h-6 w-6 place-items-center rounded-full bg-ink/70 text-xs text-white hover:bg-ink';

  return (
    <div>
      <span className="label">{L('Photos (optional, up to 3)', 'ছবি (ঐচ্ছিক, সর্বোচ্চ ৩টি)')}</span>
      <div className="flex flex-wrap gap-3">
        {existing.filter((p) => keep.includes(p.name)).map((p) => (
          <div key={p.name} className={tile}>
            <img src={p.url} alt="" className="h-full w-full object-cover" />
            <button type="button" className={remove} onClick={() => onKeepChange(keep.filter((k) => k !== p.name))} aria-label={L('Remove photo', 'ছবি সরান')}>✕</button>
          </div>
        ))}
        {previews.map(({ f, url }) => (
          <div key={url} className={tile}>
            <img src={url} alt="" className="h-full w-full object-cover" />
            <button type="button" className={remove} onClick={() => onFilesChange(files.filter((x) => x !== f))} aria-label={L('Remove photo', 'ছবি সরান')}>✕</button>
          </div>
        ))}
        {count < MAX && (
          <label className="grid h-24 w-24 cursor-pointer place-items-center rounded-2xl border-2 border-dashed border-leaf/30 bg-leaf-soft/40 text-center text-xs font-medium text-leaf-dark hover:bg-leaf-soft">
            <span>
              <svg viewBox="0 0 24 24" className="mx-auto mb-1 h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><path d="M4 7h3l2-3h6l2 3h3v12H4z" /><circle cx="12" cy="13" r="3.5" /></svg>
              {L('Add photo', 'ছবি যোগ')}
            </span>
            <input type="file" accept="image/jpeg,image/png,image/webp" multiple className="sr-only" onChange={(e) => { add(e.target.files); e.target.value = ''; }} />
          </label>
        )}
      </div>
      <p className="hint">{L(`JPG, PNG or WebP, up to ${MAX_MB} MB each.`, `JPG, PNG বা WebP, প্রতিটি সর্বোচ্চ ${MAX_MB} মেগাবাইট।`)}</p>
    </div>
  );
}
