import { useEffect } from 'react';
import { CircleMarker, MapContainer, Popup, TileLayer, useMap, useMapEvents } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { DHAKA } from '../lib/constants.js';

const TILE = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
const ATTR = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';

function Recenter({ center, zoom }) {
  const map = useMap();
  useEffect(() => {
    if (center) map.setView([center.lat, center.lng], zoom ?? map.getZoom(), { animate: true });
  }, [center?.lat, center?.lng]); // eslint-disable-line react-hooks/exhaustive-deps
  return null;
}

function ClickToPick({ onPick }) {
  useMapEvents({ click: (e) => onPick({ lat: +e.latlng.lat.toFixed(6), lng: +e.latlng.lng.toFixed(6) }) });
  return null;
}

const COLORS = { leaf: '#16795C', haldi: '#F4B740', chili: '#E06A5C', ink: '#23362F', muted: '#8A9A91' };

/**
 * markers: [{ id, lat, lng, tone, radius, popup }]
 */
export default function Map({ center, zoom = 12, markers = [], onPick, picked, className = 'h-80', you }) {
  const start = center ?? picked ?? DHAKA;
  return (
    <div className={`overflow-hidden rounded-3xl border border-line/70 shadow-soft ${className}`}>
      <MapContainer center={[start.lat, start.lng]} zoom={zoom} scrollWheelZoom={false} className="h-full w-full">
        <TileLayer url={TILE} attribution={ATTR} />
        <Recenter center={center ?? picked} />
        {onPick && <ClickToPick onPick={onPick} />}
        {you && <CircleMarker center={[you.lat, you.lng]} radius={7} pathOptions={{ color: '#fff', weight: 3, fillColor: '#2563eb', fillOpacity: 1 }} />}
        {markers.map((m) => (
          <CircleMarker
            key={m.id}
            center={[m.lat, m.lng]}
            radius={m.radius ?? 10}
            pathOptions={{ color: m.color ? COLORS[m.tone ?? 'leaf'] : '#fff', weight: m.color ? 3 : 2, fillColor: m.color ?? COLORS[m.tone ?? 'leaf'], fillOpacity: 0.95 }}
          >
            {m.popup && <Popup>{m.popup}</Popup>}
          </CircleMarker>
        ))}
        {picked && (
          <CircleMarker center={[picked.lat, picked.lng]} radius={11} pathOptions={{ color: '#fff', weight: 3, fillColor: COLORS.haldi, fillOpacity: 1 }} />
        )}
      </MapContainer>
    </div>
  );
}
