import { useEffect, useRef, useState } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../lib/auth.jsx';
import { useLang } from '../lib/i18n.jsx';
import { ROLES } from '../lib/constants.js';
import { Logo } from './ui.jsx';

function useOutside(ref, onOutside) {
  useEffect(() => {
    const h = (e) => ref.current && !ref.current.contains(e.target) && onOutside();
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, [ref, onOutside]);
}

function UserMenu() {
  const { user, logout } = useAuth();
  const { L } = useLang();
  const nav = useNavigate();
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useOutside(ref, () => setOpen(false));
  const r = ROLES[user.role];
  const item = 'block px-4 py-2 text-sm hover:bg-paper';

  return (
    <div className="relative" ref={ref}>
      <button onClick={() => setOpen(!open)} className="flex items-center gap-2 rounded-full py-1 pl-1 pr-3 hover:bg-line/50" aria-expanded={open} aria-haspopup="menu">
        <span className="grid h-8 w-8 place-items-center rounded-full bg-gradient-to-br from-ember to-berry font-display font-bold text-white">{user.name[0]}</span>
        <span className="hidden text-sm font-medium sm:inline">{user.name.split(' ')[0]}</span>
      </button>
      {open && (
        <div role="menu" className="absolute right-0 z-30 mt-2 w-60 overflow-hidden rounded-3xl border border-line/70 bg-surface py-2 shadow-lift" onClick={() => setOpen(false)}>
          <p className="px-4 pb-2 text-xs text-muted">{L(r.en, r.bn)}{user.orgName ? `, ${user.orgName}` : ''}</p>
          <Link className={item} to="/dashboard">{L('Dashboard', 'ড্যাশবোর্ড')}</Link>
          <Link className={item} to="/profile">{L('Profile and verification', 'প্রোফাইল ও যাচাই')}</Link>
          {user.role === 'admin' && <Link className={item} to="/admin">{L('Administration', 'প্রশাসন')}</Link>}
          <button
            className={`${item} w-full text-left text-chili-dark`}
            onClick={async () => {
              await logout();
              nav('/');
            }}
          >
            {L('Sign out', 'সাইন আউট')}
          </button>
        </div>
      )}
    </div>
  );
}

export default function Layout() {
  const { user } = useAuth();
  const { L, toggle, lang } = useLang();
  const [menu, setMenu] = useState(false);
  const { pathname } = useLocation();
  useEffect(() => {
    setMenu(false);
    window.scrollTo(0, 0);
  }, [pathname]);

  const links = [
    ['/food', L('Food', 'খাবার')],
    ['/events', L('Events', 'অনুষ্ঠান')],
    ...(user ? [['/dashboard', L('Dashboard', 'ড্যাশবোর্ড')]] : []),
    ...(user?.role === 'admin' ? [['/admin', L('Admin', 'অ্যাডমিন')]] : []),
  ];
  const linkCls = ({ isActive }) =>
    `rounded-full px-3.5 py-1.5 text-sm font-medium transition-colors ${isActive ? 'bg-gradient-to-r from-brand to-teal text-white shadow-glow' : 'text-muted hover:bg-paper hover:text-ink'}`;

  return (
    <div className="flex min-h-screen flex-col overflow-x-clip">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded focus:bg-surface focus:px-3 focus:py-2">
        {L('Skip to content', 'মূল অংশে যান')}
      </a>
      <header className="sticky top-0 z-20 border-b border-line/70 bg-surface/80 backdrop-blur-md">
        <div className="wrap flex h-16 items-center justify-between gap-4">
          <div className="flex items-center gap-6">
            <Link to="/" aria-label="FoodBridge home"><Logo /></Link>
            <nav className="hidden items-center gap-1 md:flex">
              {links.map(([to, label]) => <NavLink key={to} to={to} className={linkCls}>{label}</NavLink>)}
            </nav>
          </div>
          <div className="flex items-center gap-1 sm:gap-2">
            <button onClick={toggle} className="rounded-full bg-leaf-soft px-3 py-1 text-sm font-medium text-leaf-dark hover:bg-leaf-soft/70" aria-label="Switch language">
              {lang === 'bn' ? 'English' : 'বাংলা'}
            </button>
            {user ? (
              <UserMenu />
            ) : (
              <>
                <Link to="/login" className="btn-ghost hidden text-sm sm:inline-flex">{L('Sign in', 'সাইন ইন')}</Link>
                <Link to="/register" className="btn-primary px-4 py-2 text-sm">{L('Join', 'যোগ দিন')}</Link>
              </>
            )}
            <button className="rounded-full p-2 md:hidden" onClick={() => setMenu(!menu)} aria-label="Menu" aria-expanded={menu}>
              <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                {menu ? <path d="M6 6l12 12M18 6L6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
              </svg>
            </button>
          </div>
        </div>
        {menu && (
          <nav className="wrap flex flex-col gap-1 pb-4 md:hidden">
            {links.map(([to, label]) => <NavLink key={to} to={to} className={linkCls}>{label}</NavLink>)}
            {!user && <NavLink to="/login" className={linkCls}>{L('Sign in', 'সাইন ইন')}</NavLink>}
          </nav>
        )}
      </header>

      <main id="main" className="flex-1">
        <Outlet />
      </main>

      <footer className="mt-24 border-t border-line/70 bg-surface/60">
        <div className="wrap flex flex-col gap-3 py-8 text-sm text-muted sm:flex-row sm:items-center sm:justify-between">
          <Logo />
          <p>{L('Module 1: users, verification, food posts and events.', 'মডিউল ১: ব্যবহারকারী, যাচাই, খাবার পোস্ট ও অনুষ্ঠান।')}</p>
        </div>
      </footer>
    </div>
  );
}
