/**
 * Feature 1.2 (Member 2)
 * Division > District > Upazila/Thana dropdowns (from /api/locations) plus area and details.
 */
import { useLang } from '../lib/i18n.jsx';
import { useLocations } from '../lib/locations.js';
import { Field } from './ui.jsx';

export const emptyAddress = { division: 'Dhaka', district: 'Dhaka', upazila: '', area: '', details: '' };

export default function AddressFields({ value, onChange, withDetails = true, errors = {} }) {
  const { L, lang } = useLang();
  const divisions = useLocations();
  const set = (patch) => onChange({ ...value, ...patch });
  const division = divisions.find((d) => d.name === value.division);
  const district = division?.districts.find((d) => d.name === value.district);
  const label = (x) => (lang === 'bn' && x.bn ? x.bn : x.name);

  return (
    <div className="grid gap-4 sm:grid-cols-3">
      <Field label={L('Division', 'বিভাগ')}>
        <select className="input" value={value.division} onChange={(e) => { const d = divisions.find((x) => x.name === e.target.value); set({ division: e.target.value, district: d?.districts[0]?.name ?? '', upazila: '' }); }}>
          {divisions.map((d) => <option key={d.name} value={d.name}>{label(d)}</option>)}
        </select>
      </Field>
      <Field label={L('District', 'জেলা')}>
        <select className="input" value={value.district} onChange={(e) => set({ district: e.target.value, upazila: '' })}>
          {division?.districts.map((d) => <option key={d.name} value={d.name}>{label(d)}</option>)}
        </select>
      </Field>
      <Field label={L('Upazila or thana', 'উপজেলা বা থানা')} error={errors.upazila}>
        <select className="input" value={value.upazila} onChange={(e) => set({ upazila: e.target.value })} required>
          <option value="">{L('Choose…', 'বাছাই করুন…')}</option>
          {district?.upazilas.map((u) => <option key={u.name} value={u.name}>{label(u)}</option>)}
        </select>
      </Field>
      <Field label={L('Area or neighbourhood', 'এলাকা')} error={errors.area} className={withDetails ? 'sm:col-span-1' : 'sm:col-span-3'}>
        <input className="input" value={value.area} onChange={(e) => set({ area: e.target.value })} placeholder={L('e.g. Mirpur 10', 'যেমন: মিরপুর ১০')} required />
      </Field>
      {withDetails && (
        <Field label={L('Road, building, landmark', 'রাস্তা, ভবন, চিহ্ন')} hint={L('Shown only to people you choose to share it with.', 'শুধু প্রয়োজনীয় ব্যক্তিরা দেখবেন।')} className="sm:col-span-2">
          <input className="input" value={value.details ?? ''} onChange={(e) => set({ details: e.target.value })} placeholder={L('e.g. Road 5, Block C, gate 2', 'যেমন: রোড ৫, ব্লক সি, গেট ২')} />
        </Field>
      )}
    </div>
  );
}

/** Pull field errors for nested address keys out of a server error. */
export const addressErrors = (err) => {
  const d = err?.details ?? {};
  const msg = d.address?.[0];
  return { upazila: d.upazila?.[0] ?? (msg?.includes('upazila') ? msg : undefined), area: d.area?.[0] };
};
