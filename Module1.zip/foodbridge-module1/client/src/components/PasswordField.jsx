import { useId, useState } from 'react';
import { useLang } from '../lib/i18n.jsx';
import { Field } from './ui.jsx';

/** Password input with show/hide and a simple strength meter. */
export function strength(p) {
  let s = 0;
  if (p.length >= 8) s++;
  if (p.length >= 12) s++;
  if (/[A-Za-z]/.test(p) && /\d/.test(p)) s++;
  if (/[^A-Za-z0-9]/.test(p) || (/[a-z]/.test(p) && /[A-Z]/.test(p))) s++;
  return s;
}

export default function PasswordField({ label, value, onChange, error, meter = false, autoComplete = 'current-password' }) {
  const { L } = useLang();
  const [show, setShow] = useState(false);
  const id = useId();
  const s = strength(value);
  const bars = ['bg-chili', 'bg-saffron', 'bg-turmeric', 'bg-[#2FB38A]'];
  return (
    <Field id={id} label={label} error={error} hint={meter ? L('At least 8 characters, with a letter and a number.', 'কমপক্ষে ৮ অক্ষর, একটি বর্ণ ও একটি সংখ্যা।') : undefined}>
      <div className="relative">
        <input id={id} aria-invalid={error ? true : undefined} className="input pr-20" type={show ? 'text' : 'password'} autoComplete={autoComplete} value={value} onChange={(e) => onChange(e.target.value)} required />
        <button type="button" aria-label={show ? L('Hide password', 'পাসওয়ার্ড লুকান') : L('Show password', 'পাসওয়ার্ড দেখান')} onClick={() => setShow(!show)} className="absolute inset-y-0 right-2 my-auto h-8 rounded-full px-3 text-sm text-muted hover:bg-paper">
          {show ? L('Hide', 'লুকান') : L('Show', 'দেখান')}
        </button>
      </div>
      {meter && value && (
        <span className="mt-2 flex gap-1" aria-hidden="true">
          {[0, 1, 2, 3].map((i) => <span key={i} className={`h-1.5 flex-1 rounded-full ${i < s ? bars[s - 1] : 'bg-line'}`} />)}
        </span>
      )}
    </Field>
  );
}
