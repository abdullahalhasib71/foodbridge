/**
 * Feature 1.3 (Member 3)
 * The food part of a donation form, shared by "Share food", "Edit" and "Food is ready" (events).
 */
import { useLang } from '../lib/i18n.jsx';
import { CATEGORIES, CHECKLIST, COOKED, FOOD_TYPES } from '../lib/constants.js';
import CategoryChips from './CategoryChips.jsx';
import FreshnessBar from './FreshnessBar.jsx';
import { Field, fieldError } from './ui.jsx';

const HOUR_STEPS = [1, 2, 3, 4, 6, 8, 12, 24, 48, 72];

/** Value for <input type="datetime-local"> in the browser's own timezone. */
export const localInput = (d = new Date()) => {
  const x = new Date(d);
  x.setMinutes(x.getMinutes() - x.getTimezoneOffset());
  return x.toISOString().slice(0, 16);
};

export const newFood = () => ({ title: '', category: 'biryani', servings: '', foodType: 'mixed', cookedAt: localInput(), safeHours: 4, notes: '', checklist: [] });

export const foodFromDonation = (d) => ({
  title: d.title,
  category: d.category,
  servings: d.servings,
  foodType: d.foodType,
  cookedAt: localInput(d.cookedAt),
  safeHours: Math.round(((new Date(d.safeUntil) - new Date(d.cookedAt)) / 3_600_000) * 2) / 2,
  notes: d.notes ?? '',
  checklist: d.checklist ?? [],
});

export const foodPayload = (form) => ({
  title: form.title,
  category: form.category,
  servings: Number(form.servings),
  foodType: form.foodType,
  cookedAt: new Date(form.cookedAt).toISOString(),
  safeHours: Number(form.safeHours),
  notes: form.notes || undefined,
  checklist: form.checklist,
});

export default function FoodFields({ form, set, mutation }) {
  const { L, num } = useLang();
  const max = CATEGORIES[form.category].hours;
  const cooked = COOKED.includes(form.category);
  const cookedAt = new Date(form.cookedAt);
  const safeUntil = new Date(cookedAt.getTime() + Math.min(form.safeHours, max) * 3_600_000);
  const toggleCheck = (id) => set({ checklist: form.checklist.includes(id) ? form.checklist.filter((c) => c !== id) : [...form.checklist, id] });
  const steps = HOUR_STEPS.filter((h) => h <= max);
  if (!steps.includes(Number(form.safeHours)) && form.safeHours <= max) steps.push(Number(form.safeHours));

  return (
    <div className="space-y-5">
      <Field label={L('What food is it?', 'কী খাবার?')} error={fieldError(mutation, 'title')}>
        <input className="input" value={form.title} onChange={(e) => set({ title: e.target.value })} placeholder={L('e.g. Kacchi biryani and borhani from a wedding', 'যেমন: বিয়ের কাচ্চি বিরিয়ানি ও বোরহানি')} required maxLength={100} />
      </Field>

      <div>
        <span className="label">{L('Type of food', 'খাবারের ধরন')}</span>
        <CategoryChips value={form.category} onChange={(c) => c && set({ category: c, safeHours: Math.min(form.safeHours, CATEGORIES[c].hours) || CATEGORIES[c].hours })} hideAll />
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <Field label={L('How many people can it feed?', 'কতজনের খাবার?')} error={fieldError(mutation, 'servings')}>
          <input className="input" type="number" min="1" max="5000" value={form.servings} onChange={(e) => set({ servings: e.target.value })} required />
        </Field>
        <Field label={L('Meat or vegetarian', 'আমিষ না নিরামিষ')}>
          <select className="input" value={form.foodType} onChange={(e) => set({ foodType: e.target.value })}>
            {Object.entries(FOOD_TYPES).map(([k, f]) => <option key={k} value={k}>{L(f.en, f.bn)}</option>)}
          </select>
        </Field>
        <Field label={L('Cooked or prepared at', 'রান্না বা প্রস্তুতের সময়')} error={fieldError(mutation, 'cookedAt')}>
          <input className="input" type="datetime-local" max={localInput(new Date(Date.now() + 600_000))} value={form.cookedAt} onChange={(e) => set({ cookedAt: e.target.value })} required />
        </Field>
        <Field label={L('Safe to eat for', 'কতক্ষণ খাওয়া নিরাপদ')} hint={L(`At most ${max} hours for this type of food.`, `এই ধরনের জন্য সর্বোচ্চ ${num(max)} ঘণ্টা।`)}>
          <select className="input" value={form.safeHours} onChange={(e) => set({ safeHours: +e.target.value })}>
            {steps.sort((a, b) => a - b).map((h) => <option key={h} value={h}>{L(`${h} hours after cooking`, `রান্নার ${num(h)} ঘণ্টা পর পর্যন্ত`)}</option>)}
          </select>
        </Field>
      </div>

      {!Number.isNaN(cookedAt.getTime()) && (
        <div className="rounded-2xl bg-paper p-4">
          <p className="mb-2 text-sm font-medium">{L('Collectors will see this freshness window', 'সংগ্রহকারীরা এই সময়সীমা দেখবেন')}</p>
          <FreshnessBar cookedAt={cookedAt} safeUntil={safeUntil} />
        </div>
      )}

      <Field label={L('Anything collectors should know? (optional)', 'সংগ্রহকারীদের জন্য কিছু? (ঐচ্ছিক)')}>
        <textarea className="input min-h-24" maxLength={500} value={form.notes} onChange={(e) => set({ notes: e.target.value })} placeholder={L('e.g. Packed in foil trays, bring bags. Ask for Rahim at the gate.', 'যেমন: ফয়েল ট্রেতে প্যাক করা, ব্যাগ আনবেন।')} />
      </Field>

      <fieldset className={`rounded-2xl border p-4 ${fieldError(mutation, 'checklist') ? 'border-chili/60 bg-chili-soft/40' : 'border-line bg-surface'}`}>
        <legend className="px-1 font-medium">{L('Food safety check', 'খাদ্য নিরাপত্তা যাচাই')}{cooked && <span className="text-chili-dark"> *</span>}</legend>
        <div className="space-y-2">
          {CHECKLIST.map((c) => (
            <label key={c.id} className="flex cursor-pointer items-start gap-3">
              <input type="checkbox" className="mt-1.5 h-4 w-4 accent-leaf" checked={form.checklist.includes(c.id)} onChange={() => toggleCheck(c.id)} />
              <span>{L(c.en, c.bn)}</span>
            </label>
          ))}
        </div>
        {cooked && <p className={fieldError(mutation, 'checklist') ? 'error' : 'hint'}>{L('All three are required for cooked food.', 'রান্না করা খাবারের জন্য তিনটিই আবশ্যক।')}</p>}
      </fieldset>
    </div>
  );
}
