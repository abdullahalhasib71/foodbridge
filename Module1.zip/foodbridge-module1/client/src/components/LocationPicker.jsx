import { useState } from 'react';
import { useLang } from '../lib/i18n.jsx';
import { locate } from '../lib/hooks.js';
import Map from './Map.jsx';

export default function LocationPicker({ value, onChange, error }) {
  const { L } = useLang();
  const [busy, setBusy] = useState(false);
  const [geoError, setGeoError] = useState('');

  const useMine = async () => {
    setBusy(true);
    setGeoError('');
    try {
      onChange(await locate());
    } catch (err) {
      setGeoError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
        <span className="label mb-0">{L('Exact pickup point', 'সঠিক সংগ্রহের স্থান')}</span>
        <button type="button" className="btn-secondary px-3 py-1.5 text-sm" onClick={useMine} disabled={busy}>
          {busy ? L('Finding you…', 'খুঁজছি…') : L('Use my location', 'আমার অবস্থান ব্যবহার করুন')}
        </button>
      </div>
      <Map picked={value} onPick={onChange} zoom={value ? 15 : 12} className="h-64" />
      <p className={error || geoError ? 'error' : 'hint'}>
        {error ?? (geoError || (value ? L('Pin set. Tap the map to move it.', 'পিন বসানো হয়েছে। সরাতে মানচিত্রে চাপুন।') : L('Tap the map to drop a pin.', 'পিন বসাতে মানচিত্রে চাপুন।')))}
      </p>
    </div>
  );
}
