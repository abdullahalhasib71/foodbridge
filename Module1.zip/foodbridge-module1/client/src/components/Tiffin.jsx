/** A stacked tiffin carrier, the steel lunch box used across Bangladesh. Decorative. */
export default function Tiffin({ className = '' }) {
  return (
    <svg viewBox="0 0 120 150" className={className} aria-hidden="true">
      <g fill="none" stroke="#B9D7C9" strokeWidth="3" strokeLinecap="round">
        <path d="M44 14c-4-5 4-8 0-13" />
        <path d="M60 16c-4-5 4-8 0-13" />
        <path d="M76 14c-4-5 4-8 0-13" />
      </g>
      <path d="M32 46V30a28 14 0 0 1 56 0v16" fill="none" stroke="#8FB3A3" strokeWidth="5" strokeLinecap="round" />
      <rect x="22" y="40" width="76" height="12" rx="6" fill="#7DB8A0" />
      <rect x="18" y="52" width="84" height="30" rx="10" fill="#F6CF8A" />
      <rect x="18" y="84" width="84" height="30" rx="10" fill="#B5DCCB" />
      <rect x="18" y="116" width="84" height="30" rx="10" fill="#F3B9AF" />
      <g fill="#FFFFFF" opacity="0.55">
        <rect x="26" y="58" width="22" height="5" rx="2.5" />
        <rect x="26" y="90" width="22" height="5" rx="2.5" />
        <rect x="26" y="122" width="22" height="5" rx="2.5" />
      </g>
      <g fill="#8FB3A3">
        <rect x="12" y="60" width="6" height="78" rx="3" />
        <rect x="102" y="60" width="6" height="78" rx="3" />
      </g>
    </svg>
  );
}
